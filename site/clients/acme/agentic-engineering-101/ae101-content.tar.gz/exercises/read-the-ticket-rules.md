# Read the rules *hiding in a ticket*

**Time:** about 15 minutes, on your own.

**What you do:** paste one real ticket from your tracker into Claude and have it infer how your team uses the fields, then propose a few backlog-refinement rules you can fold into your task-shaping file.

**What you build:** a short set of field-use rules, read off one ticket, added to the rules file you started in Module 2.

**The point:** your tracker already encodes how your team works. Status, labels, priority, estimate: each field carries a convention nobody wrote down. One ticket is enough for Claude to start reading those conventions back to you.

Module 2 gave you a rules file for shaping tasks. Your tracker holds a different layer: how your team sizes, labels, and routes work. One ticket is enough for a first read.

## Read one real ticket

- One ticket is enough for a first read. Open one real ticket from Jira, Linear, GitHub Issues, Azure Boards, or whatever your team uses. Copy the ticket into Claude with the visible fields: title, description, comments, and links.

Ask Claude to infer how your team uses its tracker from that one ticket, and to propose a few backlog-refinement rules.

{{prompt:extract-the-task-shaping-rule-4}}

## Fold the field-use rules into your file

- One ticket gives basic rules, not policy. Which fields matter, which labels carry meaning, which wording signals "too big," which status changes imply ownership.
- The rules fold back into the file, one call each: tell Claude which to keep, which to change, and which to drop. These field-use rules become the first add-on to the task-shaping `.md` file you saved in Module 2, or a small companion file beside it.
- Depth comes from more tickets. Paste in a second ticket from a different kind of work and ask Claude which rules still hold. Three to five tickets from different work types surface stronger rules than one ticket, and Claude should keep separating strong signals from guesses as the sample grows.

## What happened

You pasted one real ticket, and Claude inferred how your team uses fields like status, labels, priority, component, estimate, owner, and epic. It separated strong signals from guesses, and proposed a few backlog-refinement rules. You folded the ones that held into your task-shaping file.

