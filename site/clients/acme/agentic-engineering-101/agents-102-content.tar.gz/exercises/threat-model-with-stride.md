# Exercise: Threat-model with STRIDE

**What you do:** Invoke the curated STRIDE skill on the access-surface map you built in the previous exercise. The skill will walk the six STRIDE categories against every surface on your map and produce a threat list. You pick one threat worth hardening against, write the decision as an ADR in your repo's convention, and move on.

**What happened:** STRIDE does the breadth: Spoofing, Tampering, Repudiation, Information disclosure, Denial of service, Elevation of privilege, across every surface. That's a lot of threat entries. You're not going to harden against all of them in one exercise window and shouldn't try. You make one call, write the ADR, and the decision ships to the repo.

**The point:** Threat modeling is only useful if it produces a decision. STRIDE's value is that it gives you a structured surface to reject most threats against (acceptable risk, out of scope, already mitigated) so the one you decide to harden is defensible. The ADR is the artifact your CISO would actually read.

**Time:** 20 minutes.

---

## Phase 1: invoke the skill on the mapped surface

Ask Claude to invoke the STRIDE skill as a subagent on the access-surface map from Exercise 1.

{{prompt:threat-model-with-stride-1}}


Let it run. The output will have more entries than you want to deal with. That's expected.

## Phase 2: pick the one

You're going to pick one threat worth hardening against. Not five. One. The move is: name the worst realistic case, then the hardening decision is usually obvious.

Ask Claude to propose the most plausible incident story and walk you through the STRIDE pick from there.

{{prompt:threat-model-with-stride-2}}


Read what Claude proposes. The "most plausible incident story" is the move that makes STRIDE useful rather than performative, push back if the story doesn't fit your codebase's reality.

## Phase 3: write the ADR

Ask Claude to draft the ADR in your repo's convention and show it before saving.

{{prompt:threat-model-with-stride-3}}


Read it. If the Decision section reads like it was written for a compliance reviewer rather than a future engineer, push back. The ADR should read like one engineer explaining a call to another. Ship & Save.

If STRIDE's six categories feel like the wrong lens for your feature (some features are really abuse-case or insider-threat shaped, where Elevation-of-Privilege + Repudiation carry everything and Spoofing + Tampering don't fit), say so in the Alternatives considered section. *"STRIDE surfaced X; the more accurate lens here was Y; decision reasoned in Y's terms"* is a legitimate ADR move. The skill is a tool; the call is yours.

Ask Claude whether this ADR rides into future sessions automatically.

{{prompt:threat-model-with-stride-4}}

Claude's answer: no, ADRs don't auto-load like `CLAUDE.md` and `CLAUDE.local.md` do. They're on-disk and discoverable, but a future session loads them only when explicitly read. You can wire individual ADRs into team `CLAUDE.md` (one `@docs/adr/<file>.md` line per file, Claude Code's `@`-include is single-file, no glob), but most teams don't: ADRs accumulate, the window is finite, and rejected alternatives shouldn't sit in live context. Selective load is the practitioner default; M4 will tell Claude exactly which artifacts to read at the start of the long-running run, and that explicit list is the lesson.

---

## What this sets up

The next exercise authors a test-strategy skill and invokes it on this feature, which is now security-tested. The hardening decision becomes a test case in the test strategy. The ADR is in the repo. Rejected threats are documented. Your CISO has something to read.

