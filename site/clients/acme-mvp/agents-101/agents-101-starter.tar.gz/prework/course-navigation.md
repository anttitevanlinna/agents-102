# Agents 101 workbook navigation

Workbook: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/

Use this file for navigation and local progress. The workbook holds the teaching and exercise instructions. Help with the learner's current request; let the learner supply the material, make decisions, and choose when to continue.

## Returning to the workbook

After completing a request that matches a row below, save its current and return links at `prework/learning-position.md`. Record what the request produced and any unfinished learner action. Preserve existing revision notes. A written file does not establish that the learner played, compared, inspected, or accepted it.

Adding the course files is complete once the archive is unpacked, the reading cue is in place, and you have read this guide. Record that step as complete and save the calendar exercise as the next link.

End the reply with the row's return link and its readable label. Keep helping with revisions when asked. Wait for the learner to choose the next activity.

The training-folder `CLAUDE.md` starts with a course-navigation reading cue. Preserve it when the learner develops their own working rules in the Module 2 debrief. Navigation supplies no personal context or generation rules. Do not add those on the learner's behalf.

## Pausing

Save a short position note at `prework/learning-position.md`: current section, its exact workbook link if known in the conversation, finished work, unfinished work, and next action. Use a section title when the exact link is unknown; do not invent a link. Preserve unfinished work rather than treating a generated output as completion.

Keep this note local and limited to navigation and work status. Exclude names, companies, and source-document contents. Leave exercise outputs and root instructions unchanged. Finish with the workbook's [Resume learning](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#resume-learning) link.

## Resuming

Read the position note if it exists. Check only the exercise files it names. Files outside the note do not create a conflict. Briefly describe the recorded progress and next action. Give one workbook destination. When work remains, give only the saved current link and omit later-section links, including conditional previews.

- Work remains: give the saved current link.
- Current activity explicitly complete: give the saved next link.
- Section title without an exact link: give the workbook base link and that title; ask the learner to find it in the workbook.
- No note: link to [Prework](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#prework) and ask which section the learner reached. Existing output files do not prove completion.
- Conflicting or unclear evidence: ask one question about where the learner stopped and wait.

Resume only recovers position. Do not run an exercise, regenerate an output, or change root instructions. Do not transmit progress or request account details.

## Workbook returns

| Completed request | Current section | Return after request |
| --- | --- | --- |
| Extract the starter archive | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#3-install-the-training-folder-3-min) | [Summarize your week in meetings](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-summarize-your-week-in-meetings) |
| Build the snake game at prework/snake.html | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min) | [Open and play your snake game, then continue Prework](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min) |
| Summarize meetings at prework/meetings.md | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#5-summarize-your-week-in-meetings-10-min) | [See what makes this an agent](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#6-read-the-mental-frame-10-min) |
| Build the initial personal page from LinkedIn | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-1-the-boring-baseline) | [Apply a framework you know](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-2-apply-a-framework-you-know) |
| Write module-1/personal-brand-generation.md | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-7-close-package-what-you-learned) | [See the mechanism repeat in every phase](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#see-the-mechanism-repeat-in-every-phase) |
| Get a cold read of module-1/site.html | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#get-a-cold-read) | [Compare the cold read and finish Module 1](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#get-a-cold-read) |
| Run the Module 2 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#building-agent-systems) | [Start Module 3: Multi-agent systems](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#multi-agent-systems) |
| Run the Module 3 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#multi-agent-systems) | [Start Module 4: Security](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#security) |
| Run the Module 4 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#security) | [Start Module 5: Output quality](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#output-quality) |
| Run the Module 5 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#output-quality) | [Start Module 6: Evaluations](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#evaluations) |
| Run the Module 6 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#evaluations) | [Start Module 7: Personal to team](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#personal-to-team) |
| Run the Module 7 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#personal-to-team) | [Start Module 8: Agents building agents](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#agents-building-agents) |
| Run the Module 8 debrief | [Current section](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#agents-building-agents) | [Finish Module 8 and the course](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#agents-building-agents) |
