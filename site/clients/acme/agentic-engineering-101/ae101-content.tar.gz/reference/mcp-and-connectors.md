# MCP and connectors: reference

Flat lookup. How to wire your agent to a ticket tracker (and other outside-the-repo systems) in Claude Code.

**Last verified: 2026-07-26** (cohort-driven re-test; see the maintainer `Source verification` block for the per-source stamp) against Claude Code MCP docs, Atlassian remote MCP server docs, Linear MCP docs, GitHub MCP server repo, local `claude mcp add --help`.

## Three paths to a work-app action

An action becomes callable in a Claude Code session:

1. **Path 1, connector inheritance.** A connector added at [claude.ai/customize/connectors](https://claude.ai/customize/connectors) is automatically available when the CLI is logged in to the same account. Best path for Jira and Linear.
2. **Path 2, `claude mcp add` from the command line.** Install an MCP server directly. Covers connectors not in the Claude.ai directory, project-scoped servers (`.mcp.json` in the repo), and local stdio MCPs.
3. **Path 3, first-party CLI via Bash.** When the work app ships a CLI (`gh`, `aws`, `gcloud`), Claude calls it through Bash. No MCP. Best ergonomics where the CLI exists; `gh` is the canonical case.

Per-tracker install commands come next. Plugins distribute Path 2, `claude mcp add`, at scale, under *Plugins and marketplaces*.

**Vocabulary.** MCP is the protocol. **Connector** = the wire into a work app (the word Claude Code's configuration uses). **Action** = a verb with effect in the world (*read ticket, comment, close*). **Tool** = the umbrella term for anything the model can call. A first-party CLI exposes actions through Bash; an MCP server exposes them through the protocol. Same end state from the agent's point of view.

**Sources:** [Claude Code MCP docs](https://code.claude.com/docs/en/mcp) · [Use MCP servers from Claude.ai](https://code.claude.com/docs/en/mcp#use-mcp-servers-from-claude-ai) · [Anthropic Directory](https://claude.ai/directory) · [Model Context Protocol spec](https://modelcontextprotocol.io/introduction)

## GitHub Issues

**Default for AE101:** `gh` CLI (Path 3, first-party CLI). GitHub ships [`gh`](https://cli.github.com), its official CLI. Claude Code's Bash tool calls it directly: no MCP server, no PAT management, no allowlist work for IT.

```
gh auth status     # check
gh auth login      # if not signed in
```

Ask Claude to *read issue NNN*, *comment on issue NNN with this body*, *open a PR from this branch*, or *check the failing GH Action*. Claude runs `gh issue view`, `gh issue comment`, `gh pr create`, `gh run view`, `gh api`, etc. via Bash. The surface is broad: every GitHub REST/GraphQL endpoint is reachable via `gh api`, so `gh` covers what the MCP server covers for nearly every practical task.

**When to add MCP instead.** Reach for the official GitHub MCP server (Path 1, connector inheritance, or Path 2, `claude mcp add`) when you want discoverable tool definitions in `/mcp`, structured arguments rather than CLI prose, multiple GitHub accounts in one Claude session (`gh` is single-account), or you're working with another agent runtime that lacks shell access.

**MCP install (Path 2, `claude mcp add`):**

```
claude mcp add --transport http github https://api.githubcopilot.com/mcp/ --header "Authorization: Bearer YOUR_PAT"
```

Trailing slash is canonical. Requires a GitHub fine-grained Personal Access Token with appropriate scopes (commonly `repo` for issue/PR access; pick narrower scopes if your work is read-only). OAuth via Claude.ai inheritance (Path 1) is the smoother modern option where supported.

**Sources:** [`gh` CLI](https://cli.github.com) · [`gh` manual](https://cli.github.com/manual/) · [GitHub MCP server repo](https://github.com/github/github-mcp-server) · [GitHub PAT settings](https://github.com/settings/personal-access-tokens)

## Jira: Atlassian Rovo MCP (official)

Atlassian's Rovo MCP Server hit GA on 2026-02-04, covering Jira, Confluence, Bitbucket, and Jira Service Management. Jira, Confluence, and Bitbucket tools use OAuth 2.1; JSM ships its own read/write scopes, API-token auth only. Docs: [support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/).

**Easiest path: Claude.ai inheritance.** Add Atlassian at [claude.ai/customize/connectors](https://claude.ai/customize/connectors), complete OAuth, then start a Claude Code session logged in to the same account. The connector appears in `/mcp`. No `claude mcp add` needed. On Team and Enterprise Claude.ai plans, only admins can add at this surface.

**CLI install**, when you want project scope or a different Claude.ai account:
```
claude mcp add --transport http jira https://mcp.atlassian.com/v1/mcp/authv2
```

Then in Claude Code:
```
/mcp
```

Browser opens; you sign in to your Atlassian org; scopes approve at user level. Once your org's first 3LO consent is complete (3LO is Atlassian's three-legged OAuth: the app, your org, and you each approve) and the domain is allowed, individual engineers don't need per-install admin approval. Admins control product scopes and which domains can connect, not whether individuals can install after that.

**Note:** the older `https://mcp.atlassian.com/v1/sse` endpoint stops working 2026-06-30 per [Atlassian's support docs](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/). The current canonical endpoint is `/v1/mcp/authv2`.

**Sources:** [Atlassian Rovo MCP docs](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/) · [JSM supported tools](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/supported-tools/) · [Atlassian admin console](https://admin.atlassian.com/) · [Composio (Jira MCP bridge)](https://composio.dev/)

## Linear: first-party MCP (official)

Linear publishes its own MCP server. Reference: [linear.app/changelog](https://linear.app/changelog) (search "MCP").

**Easiest path: Claude.ai inheritance.** Add Linear at [claude.ai/customize/connectors](https://claude.ai/customize/connectors), complete OAuth, then start a Claude Code session logged in to the same account. The connector appears in `/mcp`. On Team and Enterprise Claude.ai plans, only admins can add at this surface.

**CLI install:**
```
claude mcp add --transport http linear https://mcp.linear.app/mcp
```

Cleanest UX of the three trackers for solo engineers, regardless of path.

**Fallbacks**, when a tenant blocks the first-party server: Composio or Merge Agent Handler host third-party bridges; a local stdio MCP with a personal Linear API token works without any external host.

**Sources:** [Linear changelog](https://linear.app/changelog) · [Linear MCP endpoint](https://mcp.linear.app/mcp) · [Linear API token settings](https://linear.app/settings/account/security)

## Other trackers (Asana, Shortcut, Azure DevOps, ServiceNow, etc.)

Check the [Anthropic Directory](https://claude.ai/directory) for reviewed connectors and your tracker's own docs. Most have a third-party MCP or a CLI fallback (like `gh`).

**Sources:** [Anthropic Directory](https://claude.ai/directory) · [Model Context Protocol examples](https://modelcontextprotocol.io/examples)

## Plugins and marketplaces: MCP servers bundled for distribution

A Claude Code **plugin** is a packaged extension that can bundle skills, agents, hooks, MCP servers, LSP servers, and background monitors into one installable unit. A **marketplace** is a catalog (a `marketplace.json` file hosted in a git repo) that lists plugins and where to fetch them. Plugins distributed this way are the most ergonomic path when one MCP server needs to land on many machines. A team marketplace install replaces N copies of `claude mcp add`.

**How MCPs ride inside plugins.** A plugin author puts a standard `.mcp.json` at the plugin root; when the plugin is enabled, every server in that file loads automatically. Plugin-provided MCP servers occupy their own scope in Claude Code's precedence hierarchy (above Claude.ai connectors, below user / project / local-CLI scopes), so a server installed via Path 2 still wins on URL collisions. Plugins can ship more than MCP. A single plugin can deliver a tracker server plus the skills and agents that use it. For tracker workflows, though, the MCP-bundle dimension is the one this page covers.

**Add a marketplace**, then install a plugin:

```
/plugin marketplace add owner/repo
/plugin install plugin-name@marketplace-name
```

The first argument to `marketplace add` accepts a GitHub `owner/repo`, a full git URL (`https://gitlab.com/company/plugins.git`), or a local path. Refresh a marketplace's catalog with `/plugin marketplace update`. Non-interactive equivalents exist as `claude plugin marketplace ...` for scripting.

## Marketplace governance: official vs team, and when to reach for plugin distribution

**Official vs team marketplaces.** Anthropic operates a set of official marketplaces (reserved names include `claude-plugins-official`, `anthropic-marketplace`, `agent-skills`). Teams and individuals host their own, public or private, by putting `marketplace.json` in a git repo. Private repositories work the same as any other git operation: Claude Code reuses your existing credentials (`gh auth login`, macOS Keychain, `ssh-agent`, `git-credential-store`).

**Enterprise pre-registration.** The managed settings file (`managed-settings.json` on supported OSes) can pre-register approved marketplaces via `extraKnownMarketplaces` (so users don't need to run `/plugin marketplace add` at all) and restrict additions via `strictKnownMarketplaces`. Pairs with `managed-mcp.json` as the second half of tenant-side plugin policy.

**When plugins beat `claude mcp add`.** When the same connector needs to land on a team of N (one marketplace registration, one install command, one update path); when the MCP comes with companion skills or agents you want shipped alongside; when you want versioned releases and `/plugin marketplace update` semantics rather than ad-hoc re-adds. For a one-off solo install on one machine, plain Path 1 or Path 2 stays simpler.

**Sources:** [Claude Code plugins overview](https://code.claude.com/docs/en/plugins) · [Discover and install plugins](https://code.claude.com/docs/en/discover-plugins) · [Create and distribute a marketplace](https://code.claude.com/docs/en/plugin-marketplaces) · [Plugins reference (manifest + scope)](https://code.claude.com/docs/en/plugins-reference) · [Anthropic plugins on GitHub](https://github.com/anthropics/claude-plugins-official)

## What Claude Code doesn't do yet (as of 2026-08-19)

Current gaps:

- No standalone GUI marketplace for arbitrary MCP server install. MCP servers ride inside plugins: the in-CLI `/plugin` Discover tab installs plugin-bundled MCPs (e.g. `atlassian`, `linear`, `github` from `claude-plugins-official`), and OAuth connectors install at [claude.ai/customize/connectors](https://claude.ai/customize/connectors) and inherit into Claude Code (Team/Enterprise: admin-only). There is no in-CLI picker for adding a raw `claude mcp add --transport http <url>` server outside of a plugin. Claude Desktop's Settings → Connectors panel manages built-in OAuth connectors, not arbitrary MCP servers.
- No single-click OAuth across every MCP connector (Rovo, Linear, and Anthropic Directory connectors support it; most others don't).
- No in-chat picker of connector actions.

**Sources:** [Claude Code MCP docs](https://code.claude.com/docs/en/mcp) · [Claude.ai connector panel](https://claude.ai/customize/connectors) · [Anthropic Directory](https://claude.ai/directory)

