# Exercise: Threat-model with STRIDE

**Time:** 20 minutes.

**Window:** the main quest window (*m3-security*).

**What you do:** Invoke the curated STRIDE skill on the access-surface map you built in the previous exercise. You pick one threat worth hardening against, write the decision as an ADR in your repo's convention, and move on.

**The point:** Threat modeling is only useful if it produces a decision. STRIDE's value is that it gives you a structured surface to reject most threats against (acceptable risk, out of scope, already mitigated) so the one you decide to harden is defensible. The ADR is the artifact your CISO would actually read.

---

## Phase 1: invoke the skill on the mapped surface

Ask Claude to invoke the STRIDE skill as a subagent on the access-surface map from Exercise 1.

{{prompt:threat-model-with-stride-1}}


Let it run. The output will have more entries than you want to deal with. That's expected.

The STRIDE pass should take minutes. If it returns in seconds, Claude went shallow, push back and re-run. Stay in this window while it works, and read what lands.

## Phase 2: pick the one

You're going to pick one threat worth hardening against. Not five. One. The move is: name the worst realistic case, then the hardening decision is usually obvious.

Ask Claude to propose the most plausible incident story and walk you through the STRIDE pick from there.

{{prompt:threat-model-with-stride-2}}


Read what Claude proposes. The "most plausible incident story" is the move that makes STRIDE useful rather than performative, push back if the story doesn't fit your codebase's reality. Work with Claude to land on the right mitigation. You'll save it next.

## Phase 3: write the ADR

Ask Claude to draft the ADR in your repo's convention and show it before saving.

{{prompt:threat-model-with-stride-3}}


Read it. If the Decision section reads like it was written for a compliance reviewer rather than a future engineer, push back. The ADR should read like one engineer explaining a call to another. Ship & Save.

If STRIDE's six categories feel like the wrong lens for your feature (some features are really abuse-case or insider-threat shaped, where Elevation-of-Privilege + Repudiation carry everything and Spoofing + Tampering don't fit), say so in the Alternatives considered section. *"STRIDE surfaced X; the more accurate lens here was Y; decision reasoned in Y's terms"* is a legitimate ADR move. The skill is a tool; the call is yours.

**Where did the ADR actually land?** Check the path Claude proposed. Is it in your main session's repo, or in the M3 worktree?

If it's in the main repo, skip ahead.

If it's in the worktree, the agent reasoned itself there. M3 forked a worktree at turn 1, and "this is M3 work" has been the scrollback's framing since. From the agent's vantage, the worktree was created specifically *for M3*, so M3's artifacts look like they belong there. The fork prompt called it "the side-quest"; the agent inferred "M3 = side-quest = worktree" and skipped the architectural detail that only the *quality* side belongs there. `pwd` would have answered differently. The agent reasoned forward from the conversation, not from the filesystem.

Just tell Claude to move it over.

Ask Claude whether this ADR rides into future sessions automatically.

{{prompt:threat-model-with-stride-4}}

Claude's answer: no, ADRs don't auto-load like `CLAUDE.md` and `CLAUDE.local.md` do. They're on-disk and discoverable, but a future session loads them only when explicitly read. You can wire individual ADRs into team `CLAUDE.md` (one `@docs/adr/<file>.md` line per file, Claude Code's `@`-include is single-file, no glob), but most teams don't: ADRs accumulate, the window is finite, and rejected alternatives shouldn't sit in live context. Selective load is the practitioner default; Module 4 will tell Claude exactly which artifacts to read at the start of the long-running run, and that explicit list is the lesson.

Not everything survived to disk, though. The skills returned their work into this session: the full access-surface map from Exercise 1, and the complete STRIDE walk here, including the threats you considered and set aside. The ADR holds the one decision. The analysis around it is real security documentation, and it clears when the session does.

> **Worth keeping?** Ask Claude to save the access-surface map and the STRIDE walk to your repo's `docs/` directory, next to the ADR, before you clear. Your CISO and the next engineer read what's on disk, not your scrollback.

**What happened:** You made one call and wrote the ADR, and the decision shipped to the repo. The rest of the STRIDE output stayed in the session as evidence, not on disk and not a hardening backlog.

---

## What this sets up

The next exercise authors a test-strategy skill and invokes it on this feature, which is now security-tested. The hardening decision becomes a test case in the test strategy. The ADR is in the repo. Your CISO has something to read.

