---
key: close-the-ticket-3
dest: Claude Code
runtime: any
---
Update the ticket: short close-out note naming what the root cause was and how we fixed it, link to the PR if you opened one (otherwise link the branch). If we needed to create the ticket just now, create it first, then update. Tell me what you wrote.
