# Steering the wiring

At M5 you forked the M4 starting SHA into a worktree. A real engineering call lived in that fork: gitignored files (`CLAUDE.local.md`, `.claude/memory/`) don't ride into a worktree because git doesn't see them. AE101's default chose `cp` at fork time, your M1/M3 evidence rode forward, M5/M6 compounding diverged in the worktree, and post-M6 you decide what to merge back.

That's one wiring. It's not the only one.

## Four moves in the space

- **`cp` at fork time.** Copy the gitignored evidence across by hand after the worktree opens. UNIX pragmatism, no infrastructure invented.
- **Promote to user-level.** Move the rules that should ride everywhere up to `~/.claude/CLAUDE.md`. Auto-loads in every working directory, including worktrees. The cost is that they ride everywhere, including projects where they don't fit.
- **Rules as part of the reference artefact.** If a rule from M1/M3 matters for THIS task, it lands in the reference Claude reads explicitly. Selective inclusion per task, context economy stays explicit, no blanket auto-load.
- **Worktree as fresh compound loop.** M5/M6 produces its own rules from this run's evidence. Post-loop, you manually integrate worktree-rules back. The integration is itself a compound move.

## You steer

Four moves, four wirings, no canonical answer. You've now run an arc that touched the underlying mechanics, worktrees, reference + plan + verifier, compound loops, three-block memory. Pick the wiring that fits how you work.

At the start of this training, you might have asked someone what the right wiring is. The engineer you are at the close of M6 picks.

