---
key: three-minds-one-synthesis-3
dest: Claude Code
context: optional
runtime: any
---
You choose fixes. Aim for optimal function in the next session that runs on this.
