# Arc retrospective

**What you do:** Ask an agent to read everything you've authored across the training and write a one-page note on what changed. The agent names the arc from your own evidence, not a template.

**What happens:** You end with a short written note in your repo (ADR-shaped or a loose memo, your call) that names how your practice changed across the modules. Not a self-congratulation round, not a trainer monologue. A reading of your own artefacts by a fresh agent who has the patience to look at all of them at once.

**The point:** The throughline of the training is that everything is scaling of learning. Each module's loop is the same loop at a wider scope. That's only visible retrospectively, and only from your own artefacts. The agent's job here is to name the arc so you see it too.

**Time:** 15–20 minutes.

> **Quick timebox note.** The read across M1–M6 artefacts is wide; the beat stays short. One arc-reading pass, one push-back, save or drop. If the agent's note reads true, save. If it reads thin after one re-draft, drop. Dropping is not the soft option; it is a signal your artefacts did not carry the density the read needed. Note that and move on. No perfect note to chase. The arc is yours; the note is just the agent helping you see it.

---

Open a new Claude Code session in your repo. A fresh session, so there's no scrollback coloring the read. Ask the agent to walk the artefacts you've authored and write the arc from them.

**Prompt** *(Claude Code)*

```
Read my work across the training. Specifically:

- My team `CLAUDE.md` (if present) and my personal `CLAUDE.local.md`.
- Everything at `.claude/memory/` (three-block memory: observations/hypotheses/rules, decisions, quality criteria).
- The ADRs in this repo — wherever our convention puts them (`docs/adr/` or equivalent).
- Both skills I authored at `~/.claude/skills/` during the training (the test-strategy skill from earlier, and the skill I authored today).
- The M4 un-packaged run artefact (commits, files, the session transcript under `~/.claude/projects/` in a folder matching this repo — the earliest long-running run).
- The M5 packaged re-run artefact (commits, files, the session transcript from the re-send of the same task).

Run this audit in a fresh sub-task via the Task tool, so the read isn't colored by this conversation.

Write a one-page note on what changed across this body of work. Not a changelog. What shape did my practice have at the start, what shape does it have now, what specific artefacts show the shift. Quote from my files. Name the pattern that you see recurring across modules if you see one. Don't invent a pattern to make the note tidy; if the arc is uneven, say so and show where.

Propose where the note should live in my repo (ADR, memo in `.claude/memory/`, or a standalone file). Show me the note before you save it. I'll push back, then we save.
```


Read the note. Push back where the agent over-generalises, or where it praises without quoting. This isn't a retrospective report card; it's a reading. The quoted moments are the substance. If the note reads generic, ask the agent to re-draft with more quotes and less framing.

If after one re-draft the note still reads thin, drop it. A thin note is data: it tells you the artefacts don't yet carry the density the arc-reading needs. Better no note than a template.

If the note reads true, save it. You'll re-read it when the next long task stalls.

