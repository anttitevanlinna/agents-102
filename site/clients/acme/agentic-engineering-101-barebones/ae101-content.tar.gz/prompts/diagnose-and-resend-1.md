---
key: diagnose-and-resend-1
dest: Claude Code
runtime: any
---
I'm working in a fresh worktree. A run I sent off earlier left its `task.md` at the root here, with the run's coordinates recorded in it: the `m4/` branch the run happened on, and the path to its session transcript. Print that transcript path and confirm the `.jsonl` is there. That transcript is the previous run's full scrollback, drift and dead-ends included.
