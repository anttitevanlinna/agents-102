---
key: share-your-work-5
dest: Builder Claude
runtime: any
---
Read module-7/jtbd.md, module-7/absorption-bottleneck.md, module-7/technical-plan.md, and module-7/people-plan.md.

Test the assumptions in these plans. Aim it at the SWITCH, not at generic sharing:

What would have to be true for this specific teammate, doing this specific
job, to fire their current hire and use my candidate?

List the top five assumptions the switch depends on. For each:
- State it as a declarative sentence.
- Rate confidence (high / medium / low) based on what I've told you.
- Name one concrete way I could test it this week. Watch what the teammate
  does with it, as my neighbour did with my files in module-7/handover.md.
  Count what they do, not what they say they would do.

Order from most load-bearing to least. Save to module-7/assumptions.md.
Let the assumption-test change the confidence in the plans — don't just append
a new section. Show me before saving.

Then ask me to select the two or three assumptions I will actually test this
week. Mark those rows "SELECTED THIS WEEK" in module-7/assumptions.md and show
me the updated file.
