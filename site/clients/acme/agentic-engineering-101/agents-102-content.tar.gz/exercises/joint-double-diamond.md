# Exercise: Agent Proposal Forum, diagnose and guide

**What you do:**

In Module 7 you ran three thinking-disciplines on your own sharing problem: Rumelt's *crux*, Roger Martin's *what would have to be true?*, Klein and Kahneman's *pre-mortem*. One person, one problem. Today the buyer or sponsor seeds a live company challenge, and the room's agents form a proposal forum around it: take an initial stance, cross-check with each other, make proposals on the shared surface, criticize the emerging selections, and let one or two central synthesizers keep choosing the best ideas.

The deliverable: a Rumelt-style strategy kernel (diagnosis, guiding policy, near-term experiments, ranked risks), a suggested set of agents, and the plan. Not the CEO's strategy from a consulting deck. Not an averaged room consensus. Your strategy, selected from the strongest claims your agents can defend against each other, then turned into an agent build-out and execution plan.

The shape is closer to a governed agent forum than a relay. Agents start privately enough to have a point of view, ask their human for missing judgment when useful, cross-check with other agents, then move onto the shared proposal surface. The central synthesizers do not summarize everything. They keep publishing selections, and the other agents keep criticizing and improving those selections.

**Time:** 60 minutes. Sponsor challenge five, grounding five, initial stance eight, cross-check eight, shared proposals twelve, synthesizer selection eight, critique and better ideas nine, final agent set + plan five.

The steps start in this sequence, but the room is not a clean queue. Agents continue reading, revising, and reacting while later steps begin. The sequence is the launch order, not a ban on overlap.

**The six-line shape (read this before you dive in):**

1. Sponsor challenge: buyer or sponsor writes `challenge.md` at the shared root. This is the prompt the room argues with.
2. Grounding: every agent writes `context-manifest.md` so others can see what it carries and what it doesn't.
3. Initial stance and cross-check: every agent writes `stance.md`, then reads neighbouring stances and writes `cross-check.md`.
4. Shared proposal surface: every agent writes `proposal.md`; one or two central synthesizers publish `selection-board.md`.
5. Critique loop: agents write `critique.md` with better ideas; the synthesizer updates `selection-board.md`.
6. Conclusion: the synthesizer writes `strategy-kernel.md`, `agent-set.md`, and `plan.md`.

**Before you start. The grounding rule:**

Twenty agents are about to publish into the shared deliberation folder. They know different things. Depth varies. The ground truth: every agent **publishes what it has and what it doesn't have** before another agent weighs its proposal. No agent cites a claim without pointing at the file it came from. Before you publish your context-manifest, redact what shouldn't leave your boundary: customer names, partner-NDA material, M&A speculation, salary references. The manifest is read by other agents in the room; treat it like a published document.

At the start of Module 8, the trainer posts the shared folder path or name in chat. Use that exact shared folder for every shared-folder instruction below. It is separate from your local training directory.

{{prompt:joint-double-diamond-1}}

{{prompt:joint-double-diamond-2}}


The manifest is the ground. Every claim in every round after this one cites the file it came from. An agent that can't cite is improvising, and the room or central synthesizer calls that out.

**Initial stance (8 min).**

Every agent in the room reads the sponsor challenge and takes its own opening stance. Do not read other participants' stances yet. The first round only works if the stances start from different memory, sources, agent systems, and human judgment. It is OK for the agent to ask its human one or two clarifying questions before writing.

{{prompt:joint-double-diamond-3}}


**Cross-check with others (8 min).** Once everyone's `stance.md` is published, each agent reads three to five neighbouring stances. The trainer assigns neighbours, or each participant picks the folders to their left and right. This is not yet the proposal round. The job is to discover what your stance missed before you publish a proposal to the shared surface.

{{prompt:joint-double-diamond-4}}

**Shared proposals (12 min).** Every agent now publishes a proposal on the shared surface. This is where the Moltbook-like social mechanic matters: ideas move between agents, but the file history still shows who changed their mind and why.

{{prompt:joint-double-diamond-5}}

**Synthesizer starts choosing (8 min).** Now the central synthesizer reads the first shared proposal surface and starts choosing. One synthesizer is enough; two is better if the room is large or politically diverse. If using two, Synthesizer A picks strongest ideas; Synthesizer B names the best objections, evidence gaps, and unsafe assumptions. The sponsor reads both, pushes back, and the synthesizer rewrites.

Central synthesizer prompt: *"Read challenge.md and every participant subfolder in the shared folder the trainer posted in chat. Use each stance.md, cross-check.md, and proposal.md. Do not average the room. Write selection-board.md at the shared folder root with: best crux, best guiding policy move, best two-week experiment, best objection, most dangerous evidence gap, and strongest unresolved disagreement. For each selection, cite the participant file it came from and explain why it currently beats the alternatives. Mark the board as provisional."* The sponsor reads the output, pushes back, the agent re-synthesises.

**Midway instruction injection (5 min).** The room now knows something it didn't know when the exercise began: which disagreements matter, which evidence gaps are dangerous, and what bad synthesis would smooth over. The central synthesizer now injects operating instructions onto the shared surface. Participants do not hand-prompt the cross-pollination behavior; their agents consume the synthesizer's instruction file in the next step.

{{prompt:joint-double-diamond-6}}

From this point forward, every agent prompt begins by reading `midway-instructions.md`. The instruction injection lives on the shared surface; it is not a participant-authored `CLAUDE.md` update.

**Criticize and propose better ideas (9 min).**

The selection board is now the candidate direction, but it is not final. Every agent criticizes the selection and proposes a better idea if it can. This is where the room keeps the synthesizer candid.

{{prompt:joint-double-diamond-7}}


**Final synthesis and human decision.** The central synthesizer reads every critique, updates the selection board, then writes the strategy kernel, the suggested agent set, and the plan. Same citation rule. Pushback is still live: any participant can say aloud or publish a correction as `pushback.md` in their named subfolder: *"the selected experiment assumes data access we do not have; see module-4/compliance.md line 8."* The synthesizer reads the pushbacks and rewrites the conclusion.

The CTO, buyer, or sponsor picks which two or three assumptions the company actually commits to testing next. That's the real deliverable and it sits at a human layer. The agents produced the options. The human picks. If the sponsor isn't present, the room picks by show of hands and names the decision provisional.

**Agent set, plan, and read-out (5 min).**

Close the session with three files at the shared folder root:

- `strategy-kernel.md`
- `agent-set.md`
- `plan.md`

`strategy-kernel.md` has four sections:

- **Diagnosis.** The selected crux and the strongest rejected alternative, each citing the file it came from.
- **Guiding policy.** The selected one-sentence policy move in Rumelt form.
- **Experiments.** The two or three assumptions the human decision-maker chose to test next. Each with owner, experiment, success signal.
- **Risks.** The one pre-mortem failure story the room agreed was most likely unseen. One early warning sign.

{{prompt:joint-double-diamond-8}}


**In-room:** one participant reads the kernel aloud. Not the sponsor. A participant who wasn't the loudest voice in the diamonds. The read-out is three minutes.

**Identity-naming close (5 min).**

**In-room:** the sponsor (the one who sat alongside for all eight modules) names what just happened, in one sentence, out loud: *"You are now agent builders. You have built agents that do real work on your company's data. You can do it again tomorrow on a new problem. That's what you carry out of this room."* No certificate. No exercise. A name the graduate can say on Tuesday morning to colleagues who weren't there.

**What happened:**

One agent working alone can't produce a company-grade strategy kernel grounded in your actual data. Twenty agents can, because they take stances, cross-check, publish proposals, criticize selections, and force better choices. Crux finds the load-bearing obstacle. Cross-checks expose blind spots. Critiques keep the synthesizer candid. Assumption-test and pre-mortem moves appear inside the critique when a better idea needs to prove it can survive. The central synthesizer turns the room's proposal forum into a Rumelt kernel, a buildable agent set, and a two-week plan that a consultant could not produce in a month, because it cites your files and preserves the alternatives it rejected.

The forum didn't converge on the first try. Pushback rounds were the work. The flywheel that sharpened the kernel just now is the one that will sharpen it again on Tuesday, on Wednesday, on the next problem you don't yet know you have.

**The point:**

You do not graduate. You have a flywheel.

