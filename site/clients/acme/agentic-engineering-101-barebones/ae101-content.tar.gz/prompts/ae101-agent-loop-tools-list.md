---
key: ae101-agent-loop-tools-list
dest: Claude Code
runtime: any
---
List the tools you have available in this session. One line each.
