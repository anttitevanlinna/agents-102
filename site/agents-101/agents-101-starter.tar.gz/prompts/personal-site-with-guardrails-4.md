---
key: personal-site-with-guardrails-4
dest: Claude Code
runtime: any
---
Next comes a list of things I hate about work. For each one, work out what kind of work and what kind of people produce it, then describe me as the opposite, in the positive: what I do and what I move toward, never "I don't do X".

Use the result to sharpen how the whole site sounds: the headline, the first line, the section headings, the stance. Don't add a section about what I'm against. Then regenerate `module-1/site.html`.

After that you have a free hand on presentation. Rethink structure, order, sections and visual rhythm so that a colleague who opens the page wants to spend more time with me. Keep the substance we built: the section on how I help colleagues, the strengths, and the stance from this list.

My hate list:
