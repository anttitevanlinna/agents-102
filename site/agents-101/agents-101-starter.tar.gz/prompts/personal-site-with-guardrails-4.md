---
key: personal-site-with-guardrails-4
dest: Claude Code
runtime: any
---
Rewrite `module-1/site.html` through my strengths below. They change what the site claims about me and how it sounds. Don't add them as a list. Keep them as blunt as I wrote them.

You have a free hand on presentation. Rethink structure, order and visual rhythm so that a colleague who opens the page wants to spend more time with me. Keep the stance from my hate list and my belief.

My strengths:
