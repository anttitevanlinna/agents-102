# The far half of the map

## Back to the map: the far half opens

```
  (near half, done: INTENT · CONTEXT · WORK)   ▶   VERIFICATION ─▶ ABSORPTION ─▶ OUTCOME
                                                    the far half: M4–M6
```

- **The near half is behind you.** Intent, Context, Work: how to aim the work, what the agent needs to know, how a loop runs and compounds. Every move so far lived there.
- **The map lights its other side now.** Verification, Absorption, Outcome. M4 to M6 go there, starting with the run you send off in this module.

## Long-running answers to three new governors

- **Long-running is not more of the same.** So far you sat inside every loop: you read each reply, caught each wobble as it happened. When the agent runs for an hour without you watching, that quick feedback goes quiet. You stop seeing every move and meet the result at the end, all at once.
- **Verification governs how you know the result is any good.** Tests, checks, reads, judges: everything that pushes back on the work before you accept it. On a long run, this stops being a glance and becomes a job. The map drew a checking loop across this ground as a ghost, dashed and not yet built; this half is where you build it.
- **Absorption governs how much of the output you can actually take up.** Generating is fast; reading, judging, and merging are not. On a long run the gap between the two decides your real throughput.
- **Outcome governs what survives the run.** The fix you keep, the rule it taught you, and whether any of it crosses the wall from you to the team.

## Your first un-packaged long run

- **One long run goes off un-packaged, on purpose.** You watch what the agent does with the system you built, exactly as it stands. Nothing added for the occasion.
- **You are not handed the laws of this country up front.** You feel where it bites first, here. The laws that explain the bite get named at M5 and M6, against what your own run did.
- **One question to carry into the run.** When the agent takes a hundred steps alone, what makes you trust the result at the end?

