---
key: a101-m1-debrief-cold-critic
dest: Claude Code
runtime: any
---
Launch a fresh subagent to give an unbiased read on `module-1/site.html`. The agent should read it cold, with no memory of building it.

Have the agent answer:
1. Quote the one line that feels most uniquely this person (not the best line, the most UNIQUELY them).
2. Quote the most generic line that could be copy-pasted from anyone's site.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#get-a-cold-read
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#get-a-cold-read

End your reply with [Compare the cold read and finish Module 1](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#get-a-cold-read). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.
