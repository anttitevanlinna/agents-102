# Pick one threat, record the decision

**Time:** 20 minutes.

**Window:** the main quest window (*m3-security*).

**What you do:** invoke the curated STRIDE skill on the map you built, then pick one threat worth hardening against.

**What you build:** one recorded hardening decision, written as an ADR (Architecture Decision Record) in your repo's convention.

**The point:** STRIDE's value is rejection, not enumeration.

---

## Phase 1: Run the threat scan across your mapped surface

*7 min*

- STRIDE is a six-category checklist for threats. Spoofing, Tampering, Repudiation, Information disclosure, Denial of service, Elevation of privilege. The curated skill walks your surface against all six, so you don't hold the taxonomy in your head.
- The subagent does the walk; you read the result. It runs in fresh context against the map, not the raw code.

Ask Claude to invoke the STRIDE skill as a subagent on the access-surface map you built.

{{prompt:threat-model-with-stride-1}}


## Read the threat list, expect more than you'll use

- The output over-produces on purpose. You reject most of its entries in the next phase; that rejection is the point, not a failure of the scan.
- A scan that returns in seconds went shallow. The pass should take minutes. If it comes back instant, push back and re-run. Stay in this window while it works, and read what lands.

## Phase 2: Pick the one threat worth hardening against

*8 min*

- One threat, not five. The move: name the worst realistic case first, and the hardening decision is usually obvious from there.
- The agent proposes the incident story; you assess whether it fits.

Ask Claude to propose the most plausible incident story and walk you through the STRIDE pick from there.

{{prompt:threat-model-with-stride-2}}


## Push back on the incident story, land the mitigation

- The incident story is what makes STRIDE useful rather than performative. Read what Claude proposes. Push back if the story doesn't fit your codebase's reality.
- Work with Claude to land on the right mitigation.

## Phase 3: Write the decision as an ADR

*5 min*

- The ADR states the call, its alternatives, and the constraint that picked the winner. You write it in your repo's convention. It is the artifact your CISO would actually read.
- Have the agent draft it and save it, then read the diff before you decide whether to keep it.

Ask Claude to draft the ADR in your repo's convention, save it, and show you the diff.

{{prompt:threat-model-with-stride-3}}


## Read the ADR, check the voice and the lens

- The Decision section should read like one engineer explaining a call to another. Read it. If it reads like it was written for a compliance reviewer rather than a future engineer, push back, then save it.
- STRIDE is a tool, not the only lens. If its six categories feel wrong for your feature (some features are really abuse-case or insider-threat shaped, where Elevation of privilege and Repudiation carry everything and Spoofing and Tampering don't fit), say so in the Alternatives considered section. *"STRIDE surfaced X; the more accurate lens here was Y; decision reasoned in Y's terms"* is a legitimate ADR move. You decide.

## Check where the ADR landed

- Check the path Claude proposed. Is the ADR in your main session's repo, or in the M3 worktree? If it's in the main repo, skip ahead.
- If it landed in the worktree, the agent reasoned itself there. The fork prompt called the worktree "the side-quest", and the scrollback has framed everything since as M3 work, so M3's artifacts look like they belong there. `pwd` would have answered differently. The agent reasoned forward from the conversation, not from the filesystem.
- Just tell Claude to move it over.

## Ask whether the ADR loads into future sessions

Ask Claude whether this ADR rides into future sessions automatically.

{{prompt:threat-model-with-stride-4}}

- Claude's answer: no. ADRs don't auto-load like `CLAUDE.md` and `CLAUDE.local.md` do. They're on-disk and discoverable, but a future session loads them only when explicitly read. You can wire individual ADRs into team `CLAUDE.md` (one `@docs/adr/<file>.md` line per file; Claude Code's `@`-include is single-file, no glob), but most teams don't: ADRs accumulate, the window is finite, and rejected alternatives shouldn't sit in live context.
- Selective load is the practitioner default: naming exactly what to read at the start of a long-running session, rather than trusting broad auto-load.

## Save the map and the STRIDE walk before you clear

- The skills returned their work into this session: the full access-surface map you built, and the complete STRIDE walk here, including the threats you considered and set aside. The ADR holds the one decision. The analysis around it is real security documentation, and it clears when the session does.

> **Worth keeping?** Ask Claude to save the access-surface map and the STRIDE walk to your repo's `docs/` directory, next to the ADR, before you clear. Your CISO and the next engineer read what's on disk, not your scrollback.

**What happened:** You made one call and wrote the ADR, and the decision shipped to the repo. The rest of the STRIDE output stayed in the session as evidence, not on disk.

**What this sets up:** The next exercise authors a test-strategy skill and invokes it on this codebase.

