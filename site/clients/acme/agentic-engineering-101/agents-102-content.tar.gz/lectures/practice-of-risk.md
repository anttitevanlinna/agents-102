# Lecture: The discipline of risk

You built something. It works. Would you bet your job on it being safe? Probably not. And that feeling, that specific, uncomfortable, *I'd like to know and I don't* feeling, is the most plain thing in the room today.

Here's the hard part. The feeling doesn't go away. Not with more testing, not with a better policy, not with a certification. Agent systems don't hand you certainty. You can wait for it, or you can get to work.

**Certainty is a fantasy you inherited.**

Software security, done well, sells you a clean story. Perimeter. Access control. Patch the bug, sign off the build, the system is secure. You've probably worked with people who live inside that story and mostly do a good job of it. The story works because classical software is deterministic (same input, same output). You can find the bug, prove you fixed it, and sleep.

Agent systems break the story in three places.

The behaviour is non-deterministic. Same prompt, same files, same tools, different run, different answer. A test that passed before doesn't prove the system passes today.

The attack surface is the instruction set. The dangerous move isn't breaking into your server. It's getting your agent to *decide* to do something harmful with access it legitimately has. Well-formed English, arriving through a document the agent reads. Your firewall doesn't see it because your firewall has never had to worry about persuasion.

Capability is emergent. The agent does what its instructions, its context, and the user's ask imply it should do, combined. You can't fully predict the combination. You can only bound it.

Put the three together. You don't get *secure / not secure.* You get *safe enough, under these conditions, within these limits, for now.* If that sounds less like engineering and more like medicine, it is.

In the full agent picture, this is the boundary piece. What may the agent read? What may it change? What must come back to a human? More capability without boundaries is not progress. It is just more blast radius.

**The work is the loop.**

You don't get certainty. You get a loop. Four steps, plain, repeatable.

**Assess.** Point a lens at the system and see what it reveals. Today starts with your company's actual rules, raw, against your actual agent. Then you package that policy check so it can run again. The agent-risk lens asks what the agent can reach, what it might leak, and how ordinary text could mislead it. Neither lens makes you an expert. The reusable check is the expert. The job is reading the reports with judgment.

**Mitigate.** Pick one risk. Apply the smallest change that reduces it. Agent mitigations are shaped differently than firewalls. Scope (give the agent less). Split (break it into two agents with different trust levels). Filter (post-process the output before it leaves). Gate (a human approves before a sensitive action). Review (a second agent judges the first's output). None of these are perimeter. All of them are loop design.

**Reassess residual.** After the mitigation, the risk isn't gone. Something remains. Name it. Write it down. *The residual risk here is X. If Y happens, we haven't prevented it, we've made it less likely.* Residual risk as an artifact, not a shame.

**Decide.** Accept the residual on record, or close the door. Those are the two options. *"Hope it doesn't happen"* is not one.

Run the loop. You never finish. You iterate. The discipline isn't arriving at certainty. It's running the loop again.

**The best mitigation is the one you don't need.**

Here's the move nobody puts in a security training, because it sounds too much like common sense to charge for. The cheapest, most reliable way to reduce risk on an agent is to not open the door in the first place.

Should the agent have write access to that system? If not, scope down before you scope up. Should the agent read from that mailbox? If not, don't connect it. Should the agent be the one that drafts customer-facing language? If that's where the biggest risk lives, maybe a human drafts and the agent reviews, not the other way around.

The policy lens exists partly to tell you which doors not to open. Your company has already decided. The job is to notice.

Avoidance beats reduction. Scope beats patch. Don't-open beats mitigate. This isn't timid design. It's plain design. Every door you don't open is a residual risk you don't have to name, mitigate, monitor, re-test, or apologise for.

**The uncomfortable part, said plainly.**

Some of your agents are going to be wrong, in ways you won't catch, and ship output you won't love. That's true for every agent in production anywhere in the world right now. The organisations that handle this well aren't the ones with the best technology. They're the ones that run the loop openly, name residual risks plainly, and close doors they don't need to open.

You can't buy certainty. You can run a loop. Today the loop runs once, on your own system, first with the policy files raw and then with two reusable lenses doing the expert work. Damn, this is complex stuff. It will still be complex when the next agent gets built. The discipline is what carries.

Read the reports. Pick a risk. Apply a mitigation. Name what's left. Decide.

That's the work.

