---
key: ae101-m4-commit-starting-point
dest: Claude Code
runtime: any
---
Create a fresh feature branch named m4/<short-task-slug>. Before committing, append a protected block to `./task.md` headed `Run coordinates (do not rewrite or remove)` so a later session can recover this experiment without searching for it: the branch name exactly as `git branch --show-current` reports it (read it back from git — don't retype it from memory), and the transcript path you just located. Then stage everything, commit with message "M4 starting point", and tell me the short SHA.
