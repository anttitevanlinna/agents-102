# Prep the run, *fill the gaps*

**Time:** 55 minutes.

**Session** *(new, "Module 4 - Run the first experiment")*

```
/rename m4-walk-send
```

Start clean at your repo root. The task here is bigger than anything so far. Before the new session, check your working tree and branch. You ride that state into the closing `m4/<slug>` commit, and the next module forks its worktree from that commit.

**What you do:** walk a task you've been avoiding against what you've built, then fill the worst gaps it exposes.

**What you build:** a scoped task, and the worst gaps filled in `observations/`.

**The point:** you find the thin spots before the agent does.

---

## Phase 1: Pick the task you'll send off

*10 min*

- A real slice you'd send off rather than nudge bit by bit. Bigger than a typo-fix, smaller than an epic.
- Bring one or two candidates.

Ask Claude to screen your candidates, scope the winner, and add them after the colon.

{{prompt:walk-and-send-off-1}}

## Push back until the task is one end-to-end slice

- Push back when the screen misses something you know about the codebase.
- You'll use this task again next module.

## Phase 2: Build the ranked list of what will hurt the agent

*45 min*

- The agent reads `CLAUDE.md`, `CLAUDE.local.md`, memory, ADRs, and any skills you've authored, then ranks the five thin spots that will hurt it most on this task.
- Heavy audit expected. Skim past the opening summary; the ranked thin-spots list is the payoff. If the ranked list comes back thin, push Claude to keep digging rather than letting a shallow pass stand as done. If it comes back long and unranked, send it back for five, ranked.

Ask Claude to run the audit as a subagent and return a ranked top-five.

{{prompt:walk-and-send-off-2}}

## Correct the list and reprioritise it

- The ranking is Claude's read of your system. Tell it what's wrong, what's missing, and what you'd move up.
- You fill the top few next.

## Fill the worst two or three gaps

- Pick the ones that will hurt the agent most, probably two or three, not all five. You'll see next module what the others were for.
- New observations land in `observations/`, gitignored. That's the default home. If your team kit pins a different path, tell Claude which one and stay consistent with it. If `observations/` is new to your repo, ask Claude to add it to `.gitignore` before any writes; the fills below land there and you don't want them tracked.
- The agent reads `observations/` when a prompt names the path, the same way it reads your ADRs. It is not auto-loaded the way `CLAUDE.md` and `CLAUDE.local.md` are.

Ask Claude to walk the picked gaps one at a time, with AskUserQuestion.

{{prompt:walk-and-send-off-3}}

## Match each fill to its shape and home

A fill looks like one of these shapes (the audit tags each gap with one):

- **Observation or rule:** *"Add this to observations: the payments service treats idempotency keys case-sensitively even though the docs don't say so."* Lands in `observations/`.
- **Sharpen an existing rule:** *"In my `CLAUDE.local.md`, under 'testing', replace the current mocking rule with one that says: integration tests hit a real Postgres in Docker; unit tests mock at the service boundary, never at the repository."* Lands in `./CLAUDE.local.md`. (Team-worthy version would go in a PR against `CLAUDE.md` separately.)
- **Wire a connector:** if the task needs something only a connector reaches (issue tracker, staging logs, internal API), wire it now while the task is on your mind, not mid-send-off. Claude Code action, not a file write.
- **Bring the material in:** if the task turns on business rules the repo doesn't carry (customer segments, regulatory scope, team commitments), fetch them. Paste the section, export the Notion page, save the PDF, give Claude the link if it can reach it. Tell Claude to land what you bring in `observations/`. A pointer the agent can't open is not context.

## Push back when Claude drifts from the codebase

- If Claude says something about your codebase you didn't tell it, ask where it read that.

## Compare notes, then tidy the folder

> **Time check.** Different paces hit this point at different times. The room doesn't wait for the slowest. Five to ten minutes to share what surfaced, where the audit missed, and why the agent sometimes goes lazy.

- Before the send-off, tidy the folder: *"Propose 5 to 10 ways to make `./observations/` load better into future sessions, in priority order."* Take as many as you want from the top.

