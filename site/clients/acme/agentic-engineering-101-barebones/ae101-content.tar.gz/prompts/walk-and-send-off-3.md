---
key: walk-and-send-off-3
dest: Claude Code
runtime: any
---
Use the AskUserQuestion tool, at most four options per question, one question per call. First ask which 2-3 audit gaps I want to focus on; if the audit surfaced more than four, offer the four most material as options.

After I've picked, list the gaps you left off so I can see what didn't make the cut.

For each picked gap, propose a resolution in the shape the audit named, hear my pushback, then persist it: the `./observations/` folder in your repo for observations and material you brought in, `./CLAUDE.local.md` for rule sharpening, connector setup for connector wiring.
