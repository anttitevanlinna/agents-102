# Composing the workflow


---

By now you've shipped enough on your own that the next question stops being one a prompt can answer for you. You have a kit: a test-strategy skill, a verifier, a second skill. How practitioners compose kits like this into workflows is a conversation the field is having right now. Not one converged shape. At least five approaches in active use among the practitioners this curriculum surveys, plus a counter-position arguing the human reviewer is the constraint, not the composition. There is no prompt to drill at this point. The move is to read.

Klaassen ships Compound Engineering as a named framework: file paths between subagents, with hard gates at every seam. Cherny publishes scattered composition primitives on X: subagents, slash commands, hooks, MCP, verifier discipline. He has not unified them under a framework label. Pocock ships a public kit of small named skills the human invokes one at a time as the task calls for them. Cognition argues for a single writer surrounded by advisor agents that contribute intelligence, not actions. Amp ships composition features and methodologies, vendor-side. Ronacher, the counter-voice, argues review bandwidth is the constraint composition cannot relax, and keeps his own skills disposable. These approaches disagree about what *subagent* even means, where memory closes, and whether the human should be doing the chaining or the chain should be doing the human.

The reading walks each approach with what's distinctive, the canonical URL, and where a practitioner running it actually starts. Two or three practitioners is enough to track. Pick across the approaches whose shape resembles your day. The conversation will keep moving. The slower-moving signal is the shape of work each approach handles.

This is one level higher in abstraction and composition. Compound engineering already ships as a plugin you can install. Your Claude Code can build the kit you need once it finds the right thread to pull. Choice in the world is approaching infinite. This is one of those places that calls for intuition and taste. Your intuition.

[Workflow composition lineages](trainings/agentic-engineering-101/supplementary/workflow-composition-lineages.md)

