# Two windows on one codebase

**Time:** ~5 minutes.

Module 3 runs in two windows. Security is the main quest in your chosen repo. Quality is a side-quest in a sibling worktree.

**What you do:** start a security session in your repo, fork a sibling worktree, and open a second session there.

**What you build:** two Claude Code sessions running side by side on one git history.

**The point:** a long-running prompt is dead time only if you have one window.

## Fork the side worktree from your security lane

- Security is the main quest. Start it in your repo. Access mapping, STRIDE, and the ADR all live here.

**Session** *(new, "m3-security")*

```
/rename m3-security
```

- A sibling worktree is a second working directory on the same git history. Useful when two unrelated changes run concurrently: `git worktree add` makes the sibling folder on its own branch, and a new Claude Code session in another window works there. The [Multi-session and Git survival guide](../trainings/agentic-engineering-101/reference/multi-session-git.md) carries the longer read.
- Personal files like `CLAUDE.local.md` don't sync between worktrees. They get copied across once at fork time, then evolve independently.
- Decide where to base the side worktree. It branches off your current local HEAD. Clean main is the safe default. If you want another base, switch to it before you fork.

Ask Claude to fork a sibling worktree and copy your personal rules across. The prompt reads your repo's folder name from the working directory: paste it as-is, Claude fills in `<repo-name>` itself.

{{prompt:ae101-m3-fork-quality-side}}

## Read back the worktree path

- Claude reports the sibling worktree path. That path is where the second session opens.

## Open the quality lane in the new worktree

- This is your side-quest lane. Start a second Claude Code session in another window, in the sibling worktree directory Claude just named.

**Session** *(new, "m3-quality")*

```
/rename m3-quality
```

- Authoring and invoking the test-strategy skill both happen in this window, on this codebase. It installs to user scope, so it crosses back to the main lane on its own, and you never carry it by hand.
- Ask Claude to confirm the worktree state, then wait.

{{prompt:ae101-m3-quality-side-orient}}

## Set the two windows side by side

- Two windows, side by side. Arrange them so neither disappears behind the other.
- The move this module installs: when one window kicks off a long-running prompt, the other is where you work. You run security in the main window from here; the quality side waits until you author the test-strategy skill there.

