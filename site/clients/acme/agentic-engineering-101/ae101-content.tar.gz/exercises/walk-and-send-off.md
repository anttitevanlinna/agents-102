# Walk and send off

**Time:** 55 minutes inside a 1h45 module slot (Phases 1–3, breakdown: pick 10 / walk-and-fill 35 / see-the-frame 10). The send-off (~5 min, single prompt paste) is owned by the module file, not this exercise; the two together close Module 4.

**Session** *(new, "Module 4 - Run the first experiment")*

Start a new Claude Code session at your repo root.

```
/rename m4-walk-send
```

**Start clean.** M4 picks up a bigger task than M1–M3. Before the new session, check your working tree and branch. You ride that state into Phase 4's `m4/<slug>` commit and M5's fork.

**What you do:** Pick a task you've been avoiding, the kind you'd send off rather than nudge bit by bit. Walk what you've built across four modules against it. Fill the worst gaps. See Huryn's three-block frame in your own material. At Debrief, compound your rules file and send the task off, un-packaged, to the same Claude Code session. Leave the laptop awake while you step away, or stop the run when you've seen enough.

**The point:** This is the first experiment of a two-run arc. The un-packaged send-off here teaches Module 5 what packaging adds, a lesson no lecture can land. Every send-off is a test, not a production run; you are testing and you are learning.

---

## Phase 1: Pick the task

Start a new Claude Code session in your repo. One or two candidate tasks come in with you (Connections). Claude screens them: it can't scan your roadmap or Jira, and that stays your call. The picking work is your judgement about what's been sitting; Claude's job is to check fit.

**Not an epic. Not a typo-fix. A real slice you'd send off rather than nudge bit by bit, with a 'done' you can name in a sentence.**

Ask Claude to screen the candidates you bring against the three long-run criteria and scope the winner. Drop the candidates after the colon.

{{prompt:walk-and-send-off-1}}


Push back when the read misses something about the codebase. Claude is reading the shape, not the substance. If you catch yourself imagining a finished demo for a candidate, you've scoped too big; slice it down to one end-to-end thing the agent can chew on.

**The point:** pick one task well. You'll use it again next module.

---

## Phase 2: Walk and fill

### Run the audit

Ask Claude to audit your system as a subagent and return a ranked top-5 of what will hurt the agent most on this task.

{{prompt:walk-and-send-off-2}}

Heavy run expected. Skim past the opening summary, look for the ranked thin-spots list, that's the payoff.

Read the ranked list. Name which ones you already knew about, which surprised you. **Framework**: this is *gap analysis*, walk the system you have against the system the task needs. You'll use it forever for every agent hand-off.

### Fill the gaps

Pick the ones that will hurt the agent most (probably two or three, not all five). You'll see next module what the others were for.

Observation-path note, first time through: the default home is `observations/` in your repo, gitignored. If your team kit pins a different path, stay consistent with it. Tell Claude which one and move on.

**If `observations/` is new to your repo, ask Claude to add it to `.gitignore` before any writes.** The fills below land there; you don't want them tracked.

The agent reads `observations/` when a prompt names the path, the same way it reads your ADRs. It is not auto-loaded the way `CLAUDE.md` and `CLAUDE.local.md` are. The three blocks you'll arrange below live across this folder, your ADRs, and your skills; `observations/` holds the first.

Ask Claude to walk you through the picked gaps one at a time, using the AskUserQuestion tool to scaffold the flow.

{{prompt:walk-and-send-off-3}}

A fill looks like one of these shapes (the audit at Phase 2 tags each gap with one):

- **Observation or rule:** *"Add this to observations: the payments service treats idempotency keys case-sensitively even though the docs don't say so."* Lands in `observations/`.
- **Sharpen an existing rule:** *"In my `CLAUDE.local.md`, under 'testing', replace the current mocking rule with one that says: integration tests hit a real Postgres in Docker; unit tests mock at the service boundary, never at the repository."* Lands in `./CLAUDE.local.md`. (Team-worthy version would go in a PR against `CLAUDE.md` separately.)
- **Wire a connector:** if the task needs something only a connector reaches (issue tracker, staging logs, internal API), wire it now while the task is on your mind, not mid-run. Claude Code action, not a file write.
- **Name a business-rules gap:** if the task touches customer segments, regulatory scope, or team commitments and you don't have that written anywhere Claude can read, *the gap IS the finding*. Write one line in observations naming what's missing and where the real material lives (external wiki, team Notion, sponsor's head). Claude knows what it doesn't know. That's still context. Lands in `observations/`.

Push back when Claude writes something that doesn't match the codebase. Your observations are what you just admitted is thin in spots; don't let them re-seed with drift.

---

> **Time check.** Different paces hit this beat at different times. The room doesn't wait for the slowest. Five to ten minutes to share what surfaced, where the audit missed, and why the agent sometimes goes lazy.

## Phase 3: See the frame

Ask Claude to rearrange your memory, ADRs, and skill into Huryn's three blocks, quoting your own work for each block before naming the frame.

{{prompt:walk-and-send-off-4}}

Skim past the opening summary, look for the quoted-example-per-block payoff, that's where the three blocks earn their names.

Read the examples first. If they're from your own files, the frame should click. If it doesn't, ask Claude to quote different examples until one does.

Once the frame is named through your own material, let Claude propose the actual rearrangement. Cap it at one or two file moves or renames; larger reorganisation is a separate session, not a mid-module sweep. When the proposal looks right, tell Claude to make the moves and show you the diff. The send-off fires next, so the tree wants to be settled on disk, not just planned in chat.

**Framework**: Huryn's three-block memory. Not a template you fill; a frame that names what you've been building.

**What happened:** You picked a real task you'd send off rather than nudge bit by bit. You walked what you'd built across four modules against it, filled the worst gaps, and let Claude rearrange memory and ADRs into Huryn's three blocks against your own material. The frame named what was already there. Phase 3 ended with the tree settled before the Debrief's send-off.

---

## What closes the module (owned by the module's Debrief section)

Phase 3 is where the exercise ends. The module's Debrief takes over:

1. You nudge the compound step: Claude reads the session, rewrites your personal `CLAUDE.local.md` from evidence, integrates, sharpens, removes, and reports 3–5 lines. Team-worthy rules get flagged in the summary, not auto-PRed.
2. You push back on the 3–5 line summary.
3. You paste the send-off prompt to the same session. Keep the laptop awake and plugged in. Don't close the lid; sleep freezes the session and it won't resume on wake. If you want to stop the run early, wait for a tool call to finish; clean interrupts between tool calls are fine. Traces are data either way.

