# Claude Code for engineers — reference

Flat look-up for the primitives AE101 leans on. No pedagogy, no hand-holding. When a module says *"see the reference for CLAUDE.md precedence"* or *"plan-mode options"*, this is where.

Source of truth is Anthropic's docs. Links and verbatim quotes below point at [code.claude.com/docs/en/memory.md](https://code.claude.com/docs/en/memory.md), [skills](https://code.claude.com/docs/en/skills), [sub-agents](https://code.claude.com/docs/en/sub-agents), [settings](https://code.claude.com/docs/en/settings), [hooks](https://code.claude.com/docs/en/hooks), [cli-reference](https://code.claude.com/docs/en/cli-reference). This reference is a shortcut. When the shortcut disagrees with the docs, the docs win.

**Last verified against docs:** 2026-05-14.

**Stale if older than:** 30 days. Re-verify against [code.claude.com/docs/en/](https://code.claude.com/docs/en/) and run a live capability check (`claude --version`, `/help`, `claude-code-guide` subagent) before the next cohort.

---

## 1. The memory hierarchy — where your rules actually live

Four layers. More specific overrides broader. All loaded files **concatenate** — they don't replace each other.

| Scope | Path | Governance | Audience |
|---|---|---|---|
| **Managed policy** | macOS `/Library/Application Support/ClaudeCode/CLAUDE.md` · Linux/WSL `/etc/claude-code/CLAUDE.md` · Windows `C:\Program Files\ClaudeCode\CLAUDE.md` | IT/DevOps deploys via MDM / Group Policy / Ansible. Cannot be excluded. | Everyone on the managed machine |
| **Project** | `./CLAUDE.md` OR `./.claude/CLAUDE.md` | Checked into git → PR review | Your team |
| **User** | `~/.claude/CLAUDE.md` | You own | You, across every project |
| **Local** | `./CLAUDE.local.md` | You own; **gitignore** it | You, this project only |

**Precedence within a directory:** `CLAUDE.local.md` loads after `CLAUDE.md`, so your local file wins on conflict.

**Walk-up behavior:** Claude Code walks up the directory tree from your working directory, loading `CLAUDE.md` and `CLAUDE.local.md` at every level. If you run Claude Code in `foo/bar/`, it loads from `foo/bar/`, `foo/`, and up — everything concatenates into context.

**Subdirectory behavior:** CLAUDE.md / CLAUDE.local.md in *sub*directories (below the working directory) are NOT loaded at launch. They load on demand when Claude reads a file in that subdirectory.

**`CLAUDE.local.md` is the intended gitignored pattern.** Verbatim from docs:

> For private per-project preferences that shouldn't be checked into version control, create a `CLAUDE.local.md` at the project root. It loads alongside `CLAUDE.md` and is treated the same way. Add `CLAUDE.local.md` to your `.gitignore` so it isn't committed; running `/init` and choosing the personal option does this for you.

**Worktree gotcha:** gitignored `CLAUDE.local.md` only exists in the worktree where you created it. Cross-worktree personal instructions → import from home directory instead: `@~/.claude/my-project-instructions.md` in your `CLAUDE.md`.

**Which layer compounds per AE101 session:** `CLAUDE.local.md` by default (personal, fast loop, no PR friction). Team rules land in `./CLAUDE.md` via PR — rare, intentional, earns review. Global personal patterns that travel across codebases → `~/.claude/CLAUDE.md`.

Docs: [memory.md § Choose where to put CLAUDE.md files](https://code.claude.com/docs/en/memory.md#choose-where-to-put-claude-md-files).

---

## 2. CLAUDE.md vs. auto memory — two systems, not one

Two memory systems load at session start. You write one; Claude writes the other.

| | CLAUDE.md | Auto memory |
|---|---|---|
| **Who writes** | You | Claude |
| **Contains** | Instructions, rules, conventions | Learnings, patterns, things Claude noticed |
| **Scope** | Project / user / org (per § 1) | Per working tree (per-repo) |
| **Location** | Per § 1 hierarchy | `~/.claude/projects/<project>/memory/` |
| **Loaded into context** | Every session, in full | Every session, first 200 lines or 25KB of `MEMORY.md` |
| **Use for** | *"Always do X"* rules | *"I learned X about this codebase"* notes |

**Auto memory structure:**

```
~/.claude/projects/<project>/memory/
├── MEMORY.md          # index; loaded at launch
├── debugging.md       # topic file; loads on demand
├── api-conventions.md # topic file; loads on demand
└── ...
```

**`MEMORY.md` is an index.** Claude keeps it concise and moves detail into topic files. Topic files load when Claude reads them — not at launch.

**Version requirement:** auto memory needs Claude Code **v2.1.59+**. Check with `claude --version`.

**Disable auto memory:**
- In-session toggle: `/memory` → auto memory toggle
- Settings: `"autoMemoryEnabled": false` in project settings
- Env var: `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1`

**Relocate auto memory:** `"autoMemoryDirectory": "~/my-custom-memory-dir"` in user or local settings. Not accepted from project settings (security — prevents a shared project from redirecting your memory writes).

Docs: [memory.md § Auto memory](https://code.claude.com/docs/en/memory.md#auto-memory).

---

## 3. `.claude/rules/` — path-scoped rules

When rules only apply to certain files, don't put them in `CLAUDE.md`. Put them in `.claude/rules/` with a `paths:` frontmatter glob. They load only when Claude reads a matching file.

**Layout:**

```
your-project/
├── .claude/
│   ├── CLAUDE.md
│   └── rules/
│       ├── code-style.md       # loaded always (no paths frontmatter)
│       ├── testing.md          # loaded always
│       └── api/
│           └── handlers.md     # path-scoped (see below)
```

**Path-scoped example:**

```markdown
---
paths:
  - "src/api/**/*.ts"
---

# API Development Rules
- All API endpoints must include input validation
- Use the standard error response format
```

Glob patterns: `**/*.ts`, `src/**/*`, `*.md`, `src/components/*.tsx`. Brace expansion supported: `"src/**/*.{ts,tsx}"`.

**User-level rules:** `~/.claude/rules/preferences.md` and similar apply to every project. Project rules override user rules.

**Symlinks supported.** Link a shared rules repo into multiple projects:

```bash
ln -s ~/shared-claude-rules .claude/rules/shared
ln -s ~/company-standards/security.md .claude/rules/security.md
```

**CLAUDE.md vs. rules vs. skills — the decision:**

| Concern | Home |
|---|---|
| Always-on project conventions | `CLAUDE.md` |
| Rules that only apply to certain paths | `.claude/rules/` with `paths:` |
| Task-specific workflow Claude invokes when relevant | A skill |

Docs: [memory.md § Organize rules with `.claude/rules/`](https://code.claude.com/docs/en/memory.md#organize-rules-with-claude/rules/).

---

## 4. Imports — `@path/to/file`

`CLAUDE.md` (and `CLAUDE.local.md`) can import other files via `@path` syntax. Imported files load into context at launch alongside the parent.

```markdown
See @README for project overview and @package.json for available npm commands.

# Additional Instructions
- git workflow @docs/git-instructions.md
- personal preferences @~/.claude/my-preferences.md
```

Relative paths resolve relative to the importing file, not the working directory. Recursion depth: **5 hops maximum.**

**First-time approval:** the first time a project uses external imports, Claude Code shows an approval dialog. If you decline, imports stay disabled and the dialog doesn't reappear.

Docs: [memory.md § Import additional files](https://code.claude.com/docs/en/memory.md#import-additional-files).

---

## 5. Plan mode at depth

Plan mode: Claude researches and proposes a plan instead of writing files. You approve the plan; Claude executes.

**Toggle on:**
- Prompt: *"Enable plan mode."* or prefix a single prompt with `/plan`
- Shift+Tab cycles permission modes (default → acceptEdits → plan). `auto` and `bypassPermissions` slot in after `plan` only when enabled per-account (live-verified 2026-05-14)
- Desktop mode dropdown: pick *Plan*

**Five approval paths when the plan is ready** (live-verified 2026-05-14 against `code.claude.com/docs/en/permission-modes#analyze-before-you-edit-with-plan-mode`):

| Option | Behavior | Pick when |
|---|---|---|
| **Approve and start in auto mode** | Full execution, no further approval | Plan looks right, work is reversible or low-stakes; auto-mode requirements met |
| **Approve and accept edits** | Auto-approves file edits; Bash still prompts on non-filesystem commands | Plan looks right, edits-only is the shape of the work |
| **Approve and review each edit manually** | Claude pauses per file write | Plan looks right, work touches something you need to watch |
| **Keep planning with feedback** | Push back with specific items; Claude regenerates the plan | Plan is 80% there; one or two named fixes |
| **Refine with Ultraplan** | Hand off to a Claude Code on the web session in plan mode for browser-based review | Plan needs more thought than you want to spend in-session; cloud surface gives you per-section comments |

**Exit without executing:** Shift+Tab again, or mode dropdown.

**Keep-planning-with-feedback (before approval):** instead of approving, push back with specific items. Claude regenerates. Use when you want to sharpen the plan without restarting the whole prompt.

**AE101 cross-refs:** M2 exercise `push-back-on-the-plan.md` teaches the two-read pattern (human push-back → Pocock `grill-me` second-pass → approve). M1 deliberately runs without plan mode (trivial bug doesn't earn it).

Docs: [plan mode](https://code.claude.com/docs/en/permission-modes#analyze-before-you-edit-with-plan-mode), [Ultraplan](https://code.claude.com/docs/en/ultraplan).

---

## 6. Subagents — Agent tool, fresh context

When you need Claude to do structured work in a fresh context — breadth-first audits, long structured reports, parallel work on different concerns — spawn a subagent.

**Invocation in practice:**
- Prompt explicitly: *"Run this as a subagent via the Agent tool."*
- Or `/clear` if you just want a fresh context without parallelism (coarse alternative)
- Claude decides subagent count; you specify the shape (*"three subagents — one for X, one for Y, one for Z — then synthesize"*)

**When subagent, when main thread:**
- **Subagent:** breadth-first audits, long structured reports that would clutter scrollback, genuinely parallel work, invoking a skill on a one-shot bounded job.
- **Main thread:** interactive authoring (one-question-at-a-time), iterative steering where you want to see every reply, short jobs where context-switch cost > benefit.

**Persistent memory for subagents:** subagents can maintain their own auto memory. See [subagent configuration](https://code.claude.com/docs/en/sub-agents#enable-persistent-memory).

**AE101 cross-refs:** M3 Ex1/Ex2 invoke the curated access-control + STRIDE skills as subagents; Ex3 (test-strategy authoring) stays main-thread. M4 Phase 2 audit runs as a subagent. The discrimination *"which job belongs in which thread"* is a named LO in M3.

Docs: [sub-agents](https://code.claude.com/docs/en/sub-agents).

---

## 7. Skills

Scoped, named capabilities. Markdown file with frontmatter + instructions, lives in `.claude/skills/<name>/SKILL.md` (or equivalent team-kit location per the pre-engagement contract).

**Two invocation modes:**
- Claude invokes when it determines the skill is relevant to the current task
- You invoke explicitly: *"apply the `stride` skill to this feature"*

**When to reach for a skill vs. a rule:**
- **Skill:** task-specific, loads on demand, reusable move (*"review this against our security policy"*)
- **Rule:** always-on (or path-scoped), constraints Claude should honour whenever active

**AE101 cross-refs:** M3 ships two curated skills (`access-control-analysis`, `stride`) and you author one (`test-strategy`). M6 authors a second one, the learning-loop skill built from the two-run diff.

Docs: [skills](https://code.claude.com/docs/en/skills).

---

## 8. Connectors / MCP

Covered separately in `reference/mcp-and-connectors.md`. Per-tracker install (GitHub Issues via `gh` CLI, Jira via Atlassian Rovo MCP, Linear via Composio or Merge), tenant-admin fallbacks, freshness-dated.

Short version: `+` button next to the prompt, or Settings → Connectors. OAuth flow. Tenant admin gate for M365 / Google Workspace. Screenshot fallback when IT hasn't green-lit yet.

Docs: [Claude Code desktop → Connectors](https://code.claude.com/docs/en/desktop).

---

## 9. Long-running shapes — `/loop`, scheduled tasks, Routines, `/goal`

Four primitives. Pick by intent. Composes with any installed skill.

**`/loop` — in-session recurring.** Two forms (re-verified 2026-05-25 against `code.claude.com/docs/en/scheduled-tasks`; the delivery-time scheduling-primitive recheck this date covers the Desktop and Routines blocks below too):
- **Fixed interval:** `/loop 5m <prompt>` runs the prompt every 5 minutes while the session is open. Closes when you close the session.
- **Self-paced:** `/loop <prompt>` (omit interval). Claude picks the cadence (1 min to 1 hour) based on activity — short waits while a build is finishing, longer waits when nothing is pending. Bare `/loop` (no prompt either) runs the built-in maintenance prompt at a dynamically chosen interval, or a `.claude/loop.md` if you've written one.

Use for polling during a work block, watching a build, monitoring a long-running task's intermediate output, continuous polish on active work. *"Check the build every 5 minutes until it passes."* *"Re-run the verifier every 2 minutes on each new commit."* Ralph-style re-feed sits here.

**Desktop scheduled tasks — local (the everyday choice).** Sidebar: **Routines → New routine → choose Local.** Set the name, instructions, and schedule. Runs on your laptop when the task fires; uses your local config files and connectors.

**Missed-run behavior:** if the laptop was asleep at scheduled time, Claude Code catches up **once** for the most recently missed slot (within a 7-day window). A daily task missed for three days runs once on wake, not three times. Encode time-awareness in the prompt if catch-up would misfire (*"only run if it's before 10:00am; otherwise report skipped"*).

**Routines / `/schedule` — remote (Anthropic's cloud).** Run `/schedule daily PR review at 9am` in the CLI (a one-off like `/schedule tomorrow at 9am …` works too), or sidebar: **Routines → New routine → choose Remote.** Runs on Anthropic's infra regardless of your laptop, on Pro/Max/Team/Enterprise with Claude Code on the web enabled. **Requires a GitHub repo** as working directory (cloned fresh each run) — AE101's default assumption is a local repo, so Routines is out-of-scope for core modules. Flag for later if your org has cloud-Git workflows. CLI `/schedule` creates scheduled triggers only; API and GitHub-event triggers are web-only. No catch-up on wake (the cloud doesn't sleep).

**`/goal <condition>` — condition-driven autonomy.** Set a verifiable completion condition. Claude keeps working turn after turn until the condition holds, then stops. Status with bare `/goal`, stop with `/goal clear`. The runtime evaluates the condition against what showed up in the transcript, so the condition has to be demonstrable in chat. *"All tests pass"* works. *"Code is optimised"* doesn't (too subjective). Different shape from the three above: not scheduled, not interval-driven, condition-driven. The runtime-shipped sibling of the verifier you author later in the training. Verified live 2026-05-15 against Claude Code 2.1.142.

### When each fits

| Primitive | Good for | Not for |
|---|---|---|
| `/loop` | Iterative polish on active work, continuous check-and-fix, Ralph-style re-feed patterns | Morning automation when you're not at the laptop |
| Desktop local task | Standing verifier runs, nightly codebase sweeps, rule-drift monitoring, scheduled research OODA loops. Catch-up on wake means weekend misses don't drop on Monday | Anything that needs to react in the same session you're actively working in |
| `/schedule` (Routines) | Cloud-Git workflows, multi-machine scenarios where any laptop might be off | Local-repo training work (AE101 default) |
| `/goal` | Multi-hour work with a measurable end-state you can name in one sentence; runtime-shipped condition gate | Vague "good enough" goals; subjective quality bars |

### How it composes with an authored skill

The scheduler or condition invokes the skill. The skill is the thing that catches the gap, judges the output, or packages the move. The scheduler tells it when; `/goal` tells it until-what.

**Nightly verifier run.** Desktop local task at 2:00am → prompt reads *"Invoke the `commit-verifier` skill on the last 24h of commits. Report anything the skill flags."* The skill is the check; the schedule is the cadence.

**Continuous polish loop.** `/loop 3m` while editing → prompt reads *"Invoke the `tighten-draft` skill on the current file. Propose changes."* The skill is the move; the loop is the rhythm.

**Rule-drift monitor.** Desktop local task weekly → prompt reads *"Invoke the `rule-drift` skill on the project root. Flag rules in `CLAUDE.md` that the last week of commits contradicted."* Your second authored skill from M6 is a strong candidate to wire into a schedule like this one.

### Session lifecycle — three gotchas

Apply to any long-running session, scheduled or not. An un-packaged same-session send-off depends on these as much as a `/loop` or a `/goal` run does. Verified 2026-04-23.

1. **Laptop sleep freezes the session.** The Claude Code process pauses when the OS sleeps and does NOT resume on wake — you reopen Claude Code manually. For overnight runs, prevent sleep (`caffeinate -dims` on macOS; power-plan change on Linux/Windows). Don't close the lid.
2. **Ctrl+C during a tool call can corrupt the session.** Interrupting cleanly between tool calls is fine; interrupting mid-tool can leave the session's `.jsonl` in a state that fails to resume. If the run genuinely needs stopping, wait for a tool call to finish, or accept that `/resume` may not work on that session.
3. **No per-session budget cap.** Auto-compaction keeps context from ballooning, but there's no built-in token budget or time cap. A multi-hour agentic run can burn more than you expect. Watch the scrollback for drift; `stop when you've seen enough` is a real discipline.

### Send-off implications

The un-packaged send-off runs in the **same Claude Code session** (not `/loop`, not scheduled, not `/goal`). Laptop stays awake + plugged in (see module file for OS-specific power settings). Cancel mid-run is legitimate; traces are data. Scheduled agents and `/goal` are named as a callout, not authoring exercises.

Docs: [Desktop scheduled tasks](https://code.claude.com/docs/en/desktop-scheduled-tasks), [`/loop`](https://code.claude.com/docs/en/scheduled-tasks), [Routines](https://code.claude.com/docs/en/routines). Ctrl+C corruption is documented across [GitHub issues #3003, #17466, #18880](https://github.com/anthropics/claude-code/issues/3003) (checked 2026-05-25 — #3003 closed as duplicate, #17466/#18880 closed as not-planned; the corruption is documented, not resolved). #3003 documents `messages.N: tool_use ids were found without tool_result blocks` after mid-tool interrupt + `--resume`.

---

## 10. Session transcripts — read what actually happened

Claude Code stores session transcripts on disk. They are not the same thing as memory. Memory is the compacted knowledge Claude writes for future sessions. A transcript is the run itself: prompts, tool calls, decisions, dead ends, corrections, and final output.

Default location:

```text
~/.claude/projects/<encoded-project-path>/<session-id>.jsonl
```

The encoded project path is the absolute working-directory path with `/` replaced by `-`. A repo at `/Users/me/Projects/checkout` maps to:

```text
~/.claude/projects/-Users-me-Projects-checkout/
```

In a worktree, this matters. The transcript folder usually follows the working directory where that session ran. The original repo and the worktree may have different encoded folders.

Your current session knows its own transcript. The `CLAUDE_CODE_SESSION_ID` environment variable holds this session's id in Bash and PowerShell tool subprocesses, and the folder is the working directory encoded as above, so the full path is `~/.claude/projects/<encoded-cwd>/$CLAUDE_CODE_SESSION_ID.jsonl`. That makes the durable move recording, not searching: when a run will be read by a later session, write its transcript path down while you have it. The modules do this, recording the path into `task.md` on the un-packaged run and `plan.md` on the packaged re-run, so the next session reads it instead of hunting.

If you arrive at a run with no recorded path, you can still find its transcript by recency. Ask Claude to locate and read it; expect a narration before the findings, skim past the opening to the numbered list.

**Prompt** *(Claude Code)*

```text
Find the transcript for the previous Claude Code session in this repo. Start from the current working directory. Look under `~/.claude/projects/` for the encoded project path, list the `.jsonl` files by modified time, and pick the most recent session that is not this current one.

Read it enough to tell me:
1. What task the session was trying to do.
2. What files it changed or tried to change.
3. Where it drifted, stalled, restarted, or corrected itself.
4. Which decisions were made in chat but not encoded into files.

Then compare that read against `git log`, `git diff`, and branch state. Tell me where the transcript and git agree, and where one sees something the other misses.

Report literal counts and quoted text: actual restart numbers, exact correction messages. No softened summary.
```

Why both layers: git tells you what changed. The transcript tells you why the agent changed it, what it almost did, what it misunderstood, and where you steered. A good post-run read uses both.

**Subagents:** subagent transcripts may sit in a `subagents/` folder beside the parent session transcript. If a run used subagents, ask Claude to read the parent transcript first, then any subagent files it references.

**Security note:** transcripts can contain secrets, customer data, tickets, pasted logs, and failed attempts. Treat them as sensitive local artifacts. Do not commit them. Do not paste a whole transcript into another system. Point Claude at the file and ask for the narrow read you need.

**AE101 cross-refs:** M4 leaves an un-packaged run behind. M5 reads the transcript plus git state to diagnose what packaging changes. M6 compares two runs, so the transcript becomes evidence, not trivia.

---

## 11. Session-hygiene commands — `/memory`, `/init`, `/context`, `/clear`, `/compact`

**`/memory`** — lists every `CLAUDE.md`, `CLAUDE.local.md`, and rules file loaded in the current session. Toggle auto memory on/off. Link to open the auto memory folder in your editor. **First stop when Claude seems to be ignoring a rule** — check it actually loaded.

**`/init`** — scans your codebase and drafts a starting `CLAUDE.md`. If one exists, `/init` suggests improvements rather than overwriting. Multi-phase interactive variant: `CLAUDE_CODE_NEW_INIT=1 claude` runs an interactive flow (asks which artifacts to set up — CLAUDE.md, skills, hooks — then explores with a subagent and proposes).

**`/context`** — visualises current context-window usage as a coloured grid. Per-item breakdown of what's loaded (CLAUDE.md, memory, rules, skills, MCP, tool results, conversation). Optimisation suggestions for context-heavy tools, memory bloat, capacity warnings. Pass `all` to expand the per-item view in fullscreen mode. **Use when the conversation feels heavy** — see where the tokens are going before you reach for `/compact` or `/clear`.

**`/clear` and `/compact` — two verbs split the work** (live-verified 2026-05-14 against `code.claude.com/docs/en/commands`):

- **`/clear`** starts a new conversation with empty context. The previous conversation stays available in `/resume` (pass a name to label it in the picker — `/clear my-old-thread`). Aliases: `/reset`, `/new`. Project memory (CLAUDE.md, rules, auto-memory) re-loads on the fresh thread. Use when the task is genuinely done and the next task wants its own slate.
- **`/compact`** summarises the conversation in place — same thread, smaller context. Project-root `CLAUDE.md` re-reads from disk and re-injects; nested subdirectory CLAUDE.md files **do NOT** re-inject (they reload next time Claude reads a file in that subdir); conversation-only instructions (things you said in chat but didn't write to a file) are LOST. Optionally pass focus instructions: `/compact keep the auth-flow diagnosis verbatim`. Use when you want to keep going on the same task with less weight.

If an instruction disappeared after `/compact`, it was either conversation-only or lives in a subdirectory CLAUDE.md that hasn't reloaded. Persistent instructions belong in a file, not just in scrollback.

Docs: [memory.md § View and edit with `/memory`](https://code.claude.com/docs/en/memory.md#view-and-edit-with-memory), [commands § `/context` / `/clear` / `/compact`](https://code.claude.com/docs/en/commands), [context-window § What survives compaction](https://code.claude.com/docs/en/context-window#what-survives-compaction).

---

## 12. `--append-system-prompt` — system-prompt-level instructions

**CLAUDE.md is loaded as a user message, not the system prompt.** Claude reads it and tries to follow, but there's no strict compliance guarantee.

For instructions that need system-prompt-level treatment (stronger adherence, harder to override mid-conversation), use `--append-system-prompt`:

```bash
claude --append-system-prompt "Never edit production config files."
```

Passed at every invocation — suited for scripts, CI, and automation more than interactive use. For interactive sessions, wrap in a shell alias or launcher.

Docs: [cli-reference § system-prompt flags](https://code.claude.com/docs/en/cli-reference#system-prompt-flags).

---

## 13. Hooks — runtime extension points

A hook is a small script the runtime invokes on a named event. The script fires deterministically: the agent has no say in whether it runs. That property is what the closing lecture on packaging names — *"hooks always fire"* — and what makes hooks the right home for anything that **must** happen versus what's **recommended** (prompts and `CLAUDE.md` rules carry the recommended layer).

**Nine canonical events** (verified 2026-05-15 against Claude Code 2.1.142 — five via this repo's working `.claude/settings.json` configs, four via the CLI's own hook-event listing):

| Event | Fires | Common use |
|---|---|---|
| `SessionStart` | When a new session opens at this working directory | Inject context (today's date, recent commits, session-start reminders) |
| `SessionEnd` | When a session closes | Persist session signals; log run metadata |
| `UserPromptSubmit` | After the user submits a prompt, before Claude responds | Surface preflight (load relevant compendium, gate restricted prompts) |
| `PreToolUse` | Before a tool call runs | Gate dangerous operations; require approval; redirect path |
| `PostToolUse` | After a tool call returns | Lint / format / auto-fix the file Claude just touched; queue downstream audits |
| `Notification` | When Claude emits a notification (idle, needs input) | Forward to OS notification, Slack ping, paging integration |
| `Stop` | When Claude completes a turn | Surface end-of-turn nudges, run wind-down checks, log session signals |
| `SubagentStop` | When a dispatched subagent completes | Roll up subagent results, trigger downstream audits |
| `PreCompact` | Before auto-compaction summarises history | Capture mid-context state to disk before it folds into the summary |

This repo's own `.claude/settings.json` wires five of these (SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, Stop) — useful working configs to grep when authoring your first hook.

**Config shape (`.claude/settings.json`):**

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit",
        "hooks": [
          { "type": "command", "command": "/abs/path/to/script.sh" }
        ]
      }
    ]
  }
}
```

The `matcher` filters which tools fire the hook (regex matched against tool name). Omit `matcher` to fire on every event of that type.

**Two minimal examples:**

*Stop-hook verifier* — runs the test suite after each Claude turn that touched files, blocks the next turn if tests fail:

```json
{
  "hooks": {
    "Stop": [
      { "hooks": [{ "type": "command", "command": "cd $CLAUDE_PROJECT_DIR && npm test" }] }
    ]
  }
}
```

*UserPromptSubmit preflight* — surfaces a context reminder before Claude reads the prompt:

```json
{
  "hooks": {
    "UserPromptSubmit": [
      { "hooks": [{ "type": "command", "command": "/abs/path/to/surface-detector.sh" }] }
    ]
  }
}
```

The hook script receives JSON on stdin (event metadata, tool name + args for tool events, prompt text for UserPromptSubmit) and can emit JSON on stdout to inject context, block the action, or report a message.

**When to reach for a hook** (vs other primitives):

| If you need... | Use |
|---|---|
| Something that **must** happen on every event (verifier always runs, formatter always fires, secret never leaks) | **Hook** |
| Something Claude should consider but can override based on context (style preference, naming convention, suggested approach) | **`CLAUDE.md` rule** |
| A reusable move Claude invokes on demand (security review, threat-model walk, test-strategy authoring) | **Skill** |
| A check loop that re-runs until a condition holds | **`/goal`** (§ 9) or **Ralph re-feed verifier** |
| An event-driven sequence Claude orchestrates within one turn | Tool calls inside Claude's response — no hook needed |

**Debugging hooks that don't fire:** run `claude --debug hooks` to see hook-loading and event-firing logs. Useful when `/memory` confirms the config is loaded but the hook still isn't running on the expected event.

**AE101 cross-refs:** M5 closer lecture (`what-packaging-is.md`) names hooks as the runtime primitive behind Cherny's shell-hook verifier shape. M3 leans on hooks implicitly via the `eval-class-router` PostToolUse pattern (curriculum's own infrastructure; not student-authored at M3 but referenced as exemplar).

Docs: [hooks](https://code.claude.com/docs/en/hooks).

---

## 14. Monorepo hygiene — `claudeMdExcludes`

Ancestor CLAUDE.md files from *other* teams' directories get picked up by the walk-up. In a monorepo, that's noise.

`.claude/settings.local.json`:

```json
{
  "claudeMdExcludes": [
    "**/monorepo/CLAUDE.md",
    "/home/you/monorepo/other-team/.claude/rules/**"
  ]
}
```

Glob patterns match absolute paths. Configurable at any settings layer (user / project / local / managed); arrays merge across layers.

**Managed-policy CLAUDE.md cannot be excluded.** Org-wide instructions always apply regardless of individual settings.

Docs: [memory.md § Exclude specific CLAUDE.md files](https://code.claude.com/docs/en/memory.md#exclude-specific-claude-md-files).

---

## 15. Managed-policy CLAUDE.md — IT/DevOps controlled

For orgs that centrally manage Claude Code behaviour across dev machines. A `CLAUDE.md` at the managed policy location (paths in § 1) applies to every user on that machine and cannot be excluded by individual settings.

Deploy via MDM, Group Policy, Ansible, or equivalent config-management tool.

**Managed CLAUDE.md vs. managed settings:** different tools for different jobs.

| Concern | Configure in |
|---|---|
| Block specific tools / commands / paths | Managed settings: `permissions.deny` |
| Enforce sandbox isolation | Managed settings: `sandbox.enabled` |
| Env vars / API provider routing | Managed settings: `env` |
| Force login method / org UUID | Managed settings: `forceLoginMethod`, `forceLoginOrgUUID` |
| Code-style and quality guidelines | Managed CLAUDE.md |
| Data-handling / compliance reminders | Managed CLAUDE.md |
| Behavioral guidance for Claude | Managed CLAUDE.md |

Settings are enforced by the client regardless of Claude's behaviour. CLAUDE.md shapes behaviour but is not a hard enforcement layer. Use settings for gates, CLAUDE.md for guidance.

Docs: [memory.md § Manage CLAUDE.md for large teams](https://code.claude.com/docs/en/memory.md#manage-claude-md-for-large-teams), [permissions § managed settings](https://code.claude.com/docs/en/permissions#managed-settings).

---

## 16. Troubleshooting

**"Claude isn't following my CLAUDE.md."** Run `/memory` first. Check the file actually loaded. If loaded and still not followed: specificity (*"Use 2-space indentation"* beats *"format code nicely"*); conflict (two files giving contradictory guidance); and the fundamental non-enforcement — CLAUDE.md is context, not a system-prompt constraint. For strict adherence use `--append-system-prompt` or a hook.

**"Auto memory saved something weird."** `/memory` → open the auto memory folder. Plain markdown. Edit or delete.

**"CLAUDE.md is too large (>200 lines) and adherence is dropping."** Move path-scoped rules to `.claude/rules/`. Move rare-but-needed content to `@path` imports (note: imports still load into context at launch, so they don't reduce size — they only organise). Trim what isn't needed every session.

**"Instructions seem lost after `/compact`."** Project-root CLAUDE.md survives; nested subdirectory CLAUDE.md and conversation-only instructions don't. Put persistent rules in a file at a level that survives.

**"Multiple CLAUDE.md files in a monorepo are polluting context."** `claudeMdExcludes` in settings (§ 14).

**"I want to verify exactly which files loaded and why."** `InstructionsLoaded` hook (§ 13).

Docs: [memory.md § Troubleshoot memory issues](https://code.claude.com/docs/en/memory.md#troubleshoot-memory-issues), [debug your configuration](https://code.claude.com/docs/en/debug-your-config).

---

## Related references

- [`reference/mcp-and-connectors.md`](mcp-and-connectors.md) — per-tracker install and tenant-admin fallbacks
- [`reference/claude-quick-reference.md`](claude-quick-reference.md) — Agents 101 audience (SVP-level) version of some of this material

## Related AE101 modules (where these primitives land)

- **M1 Getting going** — §§ 1 (first `CLAUDE.md` seed, user-level or `CLAUDE.local.md`), 8 (one connector wire)
- **M2 Plan mode, done right** — § 5, plus Pocock `grill-me` skill as second-pass read
- **M3 Earn the trust** — §§ 6 (subagents), 7 (skills); first skill use + first authoring
- **M4 Run the first experiment** — §§ 1 (personal compound target), 6 (subagent audit), 9 (session-left-running for un-packaged send-off), 10 (transcript as trace)
- **M5 Learn from the test, re-send packaged** — §§ 5 (plan.md authoring), 7 (verifier as eval), 9 (send-off), 10 (read transcript plus git)
- **M6 Spot gaps, build the loop** — §§ 7 (second skill authoring), 9 (long-running shapes callout in closer + Ralph→`/goal` story), 10 (compare two run transcripts)


---

**This document grows.** If you hit something during the training that belongs here and isn't, flag it. For feature-specific detail, the [official docs](https://code.claude.com/docs/en/memory.md) are the source of truth. When docs disagree with anything above, trust the docs.

**Quality:** compendium-audited 2026-05-03 (story@bb9c1d5 behavior@bb9c1d5)
- judges @bb9c1d5: writing grandfathered, story PASS, technical grandfathered, behavior PASS
