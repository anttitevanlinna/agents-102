# Exercise: *Audit* your agent

**Session** *(new, "Module 4 - Security audit")*

<span class="rt-code">Start a new Claude Code session at your training-directory root. The personal skill you saved in Exercise 1 autoloads.</span><span class="rt-cowork">Start a new Cowork task with your training-directory root as the working folder. The personal skill you saved in Exercise 1 autoloads.</span>

```
/rename m4-security-audit
```

**What you do:**

Load the reusable security check you authored in the previous exercise, then run it against the system you built in modules 2-3. Two reusable-lens reports: the same skill, two different checks. One mitigation. One residual-risk decision added to the report; residual risk means what remains after mitigation. The goal is not a clean bill of health. The goal is to run the loop (assess, mitigate, reassess residual) on the system you actually built.

**Time:** 35 minutes. Phase 1 ~3, Phase 2 ~12, Phase 3 ~10, Phase 4 ~10.

Four phases. Bring the policy raw report from the previous exercise; that is the baseline. Bring the reusable check you just authored; that is the expert. Bring your Module 3 system; that is the target.

**Phase 1. Load the reusable check.**

Open this exercise in a fresh session at your training-directory root. The personal skill saved at the end of Exercise 1 autoloads at session start, so a session opened after the save is required.

Type `/` in the prompt and look for `/security-audit` in the autocomplete list. That means the skill loaded. The two lenses live inside the same skill; the audit prompts below tell the skill which lens to apply.

<div class="rt-cowork">

If `/security-audit` doesn't appear, you may have skipped pressing the Save button in Exercise 1. Go back, save the skill, then open a new session.

</div>

Do not run a toy verification on one file. The first loaded use is the real audit.

**Phase 2. Run the policy audit.**

Ask Claude to apply the packaged policy lens to your full module-3 system and produce one report. This is not the same as the raw run. The raw report came straight from `module-4/policies/`; this report comes through the reusable lens you shaped.

<div class="rt-cowork">

Cowork doesn't always engage `/security-audit` from pasted prompt text alone. If the audit doesn't fire after sending, click into the prompt dialog and expand `/security-audit` from the autocomplete to engage the skill.

</div>

{{prompt:audit-your-agent-1}}

While the report runs, stay with it. The report is more useful when you read it cold. Expect the reusable check to find things you did not think about, and to leave things "I can't tell" you thought were settled.

Read Claude's three lists. Then open `outputs/policy-report.md` and find the rows Claude flagged. You are reading with a hypothesis, not row-by-row from scratch. Notice which of Claude's surprises match yours and which do not. That mismatch is data.

**Phase 3. Run the agent-risk audit.**

In the same session, ask Claude to apply the agent-security lens and write the ranked risk report.

{{prompt:audit-your-agent-2}}

Now work the risks. List them, have Claude explain each, what it means in this system, why the rank landed where it did, what the failure would actually look like, and prepare to pick one. No prompt for this; you drive the conversation.

Feel free to glance at the reports and compare. Two different lenses; some risks will overlap, some will not. That is correct.

You now have the assessment half of the loop. The uncomfortable feeling is the evidence.

**Phase 4. Mitigate one risk. Reassess the residual.**

Look at the two reports. Pick one risk to mitigate. Not the easiest, not the scariest. The one that bugs you on the second skim. Your gut is data here. This is about running the loop once, not solving the worst problem on your list.

Tell Claude the risk in one sentence, then paste the prompt. You are steering by judgment, not by technical detail. Claude picks the mitigation shape, applies the change, and walks you through what landed and why.

{{prompt:audit-your-agent-3}}

Claude applies the mitigation and walks you through what changed. If the shape does not fit, tell Claude and iterate. Re-run the check. Read the residual section in `outputs/security-report.md`.

The risk did not go away. That is expected. A mitigation reduces, it does not eliminate. The residual section is part of the report. Name it, accept it on record, and stop there.

**Still not sure? Ask a person.**

Sometimes the correct next step is not another prompt. If the policy report still has a serious "I can't tell", or the security report names a risk you do not know how to accept, show the evidence to someone who owns that area: legal, security, IT, compliance, or the business owner. Bring the report, the files it quotes, the mitigation you applied, and the residual that remains.

The instinct here is to skip the expert and resolve it yourself, or to escalate the whole tangle and hand them the problem cold. Both miss what you just produced. You ran the lens, you have the rows, you applied a mitigation, you have the residual on record. The narrow question the expert can actually answer is sitting in the report. Walk in with that.

**Prototype vs production.**

We did this for a single mitigation. Risk control is one of the things that separates a prototype from a real production agent. You must do the work.

**What happened:**

The Module 3 system has two packaged-lens reports against it now, plus the raw policy report that came before packaging. One policy lens. One agent-risk lens with four named patterns. One mitigation applied; one residual decision recorded in the security report. If judgment is still unclear, you know what to show a human expert. The loop ran once. The reusable check and the loop carry to the next agent.

**The point:**

Absolute certainty is not on offer. The discipline is. Raw policy files first, packaged lenses second, one mitigation, one named residual. The reusable check is the expert in the room. The report carries the evidence and the decisions. The unease that remains is what the loop is supposed to produce, not what it failed to remove.

You just ran **Recipe 4** end-to-end on your real system: the two-lens audit, the five named agent-risk patterns, the five mitigations (scope, split, filter, gate, review), the "I can't tell" verdict earning a row of its own. After Agents 101, when the next agent needs the same audit, the [Cookbook for Agent System Design](supplementary/cookbook-for-agent-system-design.md) names the moves and components without the training scaffolding.

