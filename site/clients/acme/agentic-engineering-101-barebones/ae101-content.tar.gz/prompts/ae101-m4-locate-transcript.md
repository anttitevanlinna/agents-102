---
key: ae101-m4-locate-transcript
dest: Claude Code
runtime: any
---
Show me where Claude Code is keeping the record of this session. Every session's scrollback is written live to a `.jsonl` file under `~/.claude/projects/`: the folder is this working directory's full path with every character that isn't a letter or digit turned into `-`, and the filename is this session's id, which lives in the `CLAUDE_CODE_SESSION_ID` environment variable. Build the full path, confirm the file is there, and show me the path.
