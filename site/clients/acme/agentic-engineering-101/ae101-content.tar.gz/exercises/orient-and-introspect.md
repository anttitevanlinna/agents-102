# Orient and introspect

**Time:** 15–20 minutes.

**Session** *(new, "Module 1 - Orient and introspect")*

Start a new Claude Code session at your repo root. Optionally rename to `m1-orient`.

```
/rename m1-orient
```

**What you do:** have Claude read your repo, then interrogate what it read.

**The point:** you can't steer what you can't see. This is the first move of every session after this one. Load deliberately, watch the budget, dig the self-report.

Claude Code is open on your repo. You have a trivial bug picked from prework. Now: deliberate orientation, then introspection on what Claude says it read, then a look at your context budget.

Ask Claude to read your repo deliberately and report shape, structure, what's load-bearing, what's stale.

> **Big repo? The read can fan out.** If Claude starts naming dozens of files, interrupt with `Esc`, narrow to one feature or directory, and say `continue`.

{{prompt:orient-and-introspect-1}}


Claude reads and reports. Let it finish.

Ask Claude to introspect on what it read, what it skipped, and the call it made on each.

{{prompt:orient-and-introspect-2}}


Read Claude's own account. This is one of the most useful moves in the training: Claude can introspect on what it did and why, including what it chose to skip. The caveat is load-bearing. The self-report is a reconstruction, not ground truth. Claude confabulates reasons sometimes. Assume 10% of what Claude says or does is misrepresentation. Could be more, could be less. Spot-check by quoting back a specific file or function and asking Claude to confirm it.

Now look at your context budget, the slash command that shows how full your context window is, total used and breakdown by category (system prompt, messages, memory, skills).

{{prompt:orient-and-introspect-3}}

Look at the percentage. The window has a ceiling; the more it fills, the less room for new work. The slice of the repo Claude didn't load is the bounded-window reality. Your job going forward is to steer what lands in those bytes.

You've seen what's loaded and what isn't. Hand off to the fix.

