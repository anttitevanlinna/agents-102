# Orient and introspect

**What you do:** have Claude read your repo, then interrogate what it read. The introspection prompt and `/context` together show you what actually landed in the window and what didn't.

**What happens:** Claude reports what it read and why, what it skipped and why. You see the bounded window directly. The self-report is a hypothesis; `/context` is ground truth. The delta is where the unread 10% lives.

**The point:** you can't steer what you can't see. This is the first move of every session after this one. Load deliberately, verify against the instrument, work inside a window you know the shape of.

**Time:** 15–20 minutes.

Claude Code is open on your repo. You have a trivial bug picked from prework. Now: deliberate orientation, then the instrument that shows you what Claude actually read.

**Prompt** *(Claude Code)*

```
Read enough of this repo to tell me what's here: the shape, the structure, what looks load-bearing, what's been touched recently, what looks stale. Don't try to be complete. Read what you judge worth reading; skip what you judge isn't.
```


Claude reads and reports. Let it finish.

Now introspect on the read:

**Prompt** *(Claude Code)*

```
What did you read, and why those files? What didn't you read, and why not? Name the specific files or directories you skipped and the call you made on each.
```


Read Claude's own account. This is one of the most useful moves in the training: Claude can introspect on what it did and why, including what it chose to skip. The caveat is load-bearing. The self-report is a hypothesis, not ground truth. Claude confabulates reasons sometimes. Take it with a grain of salt; verify against the actual output and the instrument below.

Now look at the instrument directly. In the Claude Code chat, type:

```
/context
```

That's the slash command for the context window: what's loaded, how much, what's been consumed reading files. Look at the number. The rest of the repo (the slice Claude *didn't* load) is where the 10% it couldn't address lives. Not a bug; the shape of working with a bounded window. Your job going forward is to steer what lands in those bytes.

You've seen the window. Hand off to the fix.

