---
key: walk-and-send-off-1
dest: Claude Code
runtime: any
---
I'm about to run my first long-running experiment. Screen the candidates below against three criteria:

- Send-off shape: the task lets the agent push past 3-4 ambiguities without checking in at every step.
- Requirement-weaving: the task has multiple constraints that interact — getting one right means knowing the others.
- Multi-file reasoning: touches at least 3 files where touching the wrong one matters.

For each candidate, give me your read (fit / marginal / wrong shape) and why. If one is a clear fit, scope it into two or three sentences I can refer back to. If neither fits, tell me what's missing; if both fit, push me to pick the one that'll teach me more.

Once we've settled on one, save the scope as `./task.md` in the repo root (overwrite if it exists) so the send-off commit has something to capture and a later session can recover the task from disk.

Candidates:
