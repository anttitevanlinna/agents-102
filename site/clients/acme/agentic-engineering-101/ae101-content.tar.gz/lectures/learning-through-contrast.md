# Learning through contrast

You sent off an un-packaged run at the close of M4 and you have something to read now. Stopped, finished, ran out of credit, doesn't matter. The artefact is data either way.

Here is the move M5 asks of you. It cuts against most engineering instinct.

**Diagnose first. Fix later.**

When you see something an agent did wrong, the reflex is to fix it immediately. Edit the prompt, add a constraint, reach for the next tool. M5 holds that reflex off. You diagnose first. You name the failure modes. The failures earn the validation that catches them.

The arc is *test → learn → encode.* M4 was the test. Today is the learn. M6 will be the encode.

## Three lenses

The pre-read introduced these. One sentence each in case you skimmed.

**Goal drift.** The agent solved an adjacent problem with confidence. Buried instruction, redirected scope.

**Context rot.** Signal-to-noise dropped, agent rehashed approaches it ruled out an hour ago.

**Plausible-but-wrong.** Outputs look reasonable in isolation, don't match the spec.

These are your reading lens. Every artefact gets read through all three, even if one dominates.

## One operational move

The diagnosis session will fill its own working window. What works, per recent practitioner posts: trigger `/compact` manually at around 60% context. Don't wait for auto-compact. Auto fires when the model decides; manual at 60% means you choose what to keep (the diagnosis quotes, the failure-mode mapping, the validation shape you're sketching for Phase 3). Run `/context` when you want a current read on how full the window is.

This is session-management, not packaging. Packaging is what the exercise builds for the re-send.

## "What if I'm not there to compact?"

Fair question. The diagnosis session you're about to run is bounded keyboard work, so manual `/compact` works. But the re-send at the end of M5 will run for hours while you're away. You won't be there.

Two real options for hands-off runs.

1. **Trust auto-compact and live with what it picks.** The model decides what to keep when its window fills. Sometimes useful, sometimes wrong. Better than dropping context entirely.
2. **Build the agent something durable to re-read.** A working document the agent owns and updates. A reference it diffs its output against. An automated check that fires on produced work. Once those exist, auto-compact can fire and the agent can re-anchor from what survives.

Option 2 is what the exercise builds. The whole point of packaging is that you can leave the room.

## What is about to happen

Phase 1: start a Claude Code session in your repo, ask it to read your M4 artefact through the three lenses, quote specific moments for each. Don't generalise. Quote.

Phase 2 inverts the move: for each named failure, ask what validation would have caught it in minutes, not hours.

Phases 3 and 4 build. Then the module re-sends.

**Practice beats external proof.** The run shows you what no benchmark can.

Open your repo. Let's go.

