# Reading the return

## What would have caught this earlier?

- Whatever came back is the artefact. You stepped away with the agent working. The session finished, hit its budget, or was stopped because enough was seen. All three are readable results, and the read is the same.
- The closing summary is not the artefact. The machine would rather produce something than admit nothing: a stuck run invents a plausible way forward, and a thin result arrives described as progress. That is why the send-off prompt says *rather than inventing a way forward*, and why the read starts at the work, not the report.
- The question that drives the read: *what would have caught this earlier in the session?* Not *did the task succeed*. Not *should I have spec'd it tighter*. A diagnostic: you read the artefact, you find what went wrong, and for each thing you ask this one question.

## Three failure modes you'll use to read

- Practitioners hit the same three. Use them as the lens for the read.
- **Goal drift.** The instructions get buried as the conversation grows, and before long the agent is solving an adjacent problem with confidence. The LLM reasons from what fills the window now, and the original ask competes with everything generated since. Hard to spot until you compare what was asked against what was done.
- **Context rot.** Signal-to-noise drops as the working window fills. The agent rehashes approaches it already ruled out two hours ago, because "ruled out two hours ago" no longer fits in the working window.
- **Plausible-but-wrong.** Outputs look reasonable in isolation and don't match the original spec. The LLM produces the next likely word, not the next true one, so fluent and confident is its default finish whether the work is right or not. The most expensive failure to find, because it doesn't trigger an obvious tell.
- Your rules file is in that window too. Dex Horthy, on the failure: *"The longer your file gets, the more Claude seems to treat individual sections as optional."* One more question for the read: did the rules you compounded actually reach the work?

## Why these three, every session

- The three are consequences, not bad luck. The LLM is a statistical machine with a finite window: it predicts what is likely, and it holds only so much. Run it long enough and all three failures follow, whoever wrote the prompt.
- Predictable failures are readable failures. Because the three come from the machine, expect all three in any long session. That is why three lenses are enough to read whatever comes back.
- Use the three as lenses, not boxes. Ground each finding in a quoted moment from the artefact; the same moment can reveal more than one failure mode.

## Two long ports, long enough for all three

- In January 2026, Armin Ronacher ran a port between two languages in ten hours of agent time. 2.2 million tokens. Long enough for all three failure modes to show up.
- In May 2026, Jarred Sumner rewrote Bun in Rust the same way, over eleven days, peaking at about sixty-four agents at a time. He was on an unreleased model, so read the scale as where this is going, not as a target to match.
- Both ports held together anyway. Each had something specific in place that catches all three failure modes. What that was is where your own read leads.

