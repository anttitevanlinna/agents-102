---
key: a101-m1-debrief-cold-critic
dest: Claude Code
runtime: any
---
Launch a fresh subagent to give an unbiased read on `module-1/site.html`. The agent should read it cold, with no memory of building it.

Have the agent answer:
1. Quote the one line that feels most uniquely this person (not the best line, the most UNIQUELY them).
2. Quote the most generic line that could be copy-pasted from anyone's site.
