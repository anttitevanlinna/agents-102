# Close the ticket *your team's way*

**Time:** 20 minutes.

**What you do:** read one real ticket, have the agent work out how your team uses its tracker, then close the bug's ticket in that voice.

**What you build:** bug rules read off your own tracker, and a close-out note on the bug you shipped.

**The point:** the agent can reverse-engineer your team's rules.

## Read the ticket for your bug

- Open the ticket for the bug you fixed and paste its link.
- If there is no ticket for this bug, say so in the chat. The agent will offer to create one.

Drop the ticket link after the colon.

{{prompt:close-the-ticket-1}}

## Read the conventions off the ticket

- Every field carries a convention. Status, labels, severity, component, owner, repro steps: how your team fills them is a rule your tracker has been keeping for years.
- One ticket gives a sample of your team's rules, not the policy. The agent separates strong signals from guesses, and names what it cannot tell from a single ticket.
- No ticket of your own to read? Any other real ticket from your tracker works. One the agent just wrote carries none of your team's conventions.
- The rules the agent proposes are for this bug and the ones after it.

Ask Claude to reverse-engineer how your team handles bugs and propose five bug rules.

{{prompt:close-the-ticket-2}}

Push back on the five. The ones you reject sharpen the read as much as the ones you keep. A second bug ticket from a different part of the system shows which rules hold beyond one sample.

## Write the close-out and send it

- Adding a connector is one command per tracker. [MCP and connectors](../trainings/agentic-engineering-101/reference/mcp-and-connectors.md) has them, and it pays back on every session after this one.

Ask Claude to write the close-out, update the ticket, and report what it wrote.

{{prompt:close-the-ticket-3}}

## Double-check the voice

- Does it sound like the comments already on the ticket? If a line reads stiffer than your team's, name it and say what style you want instead.

## Anything can be reverse-engineered

- The ticket is one instance. Anything can be inspected and reverse-engineered with an LLM: a codebase nobody documented, a CI pipeline, a config, an API you did not write, the system your team runs on and cannot explain.
- The move is the same every time. Ask the agent to study the pipeline, the config, the undocumented code. Extract a `.md` file. Use that file as context in the next agent.

## What happened

The ticket gave up two things: a close-out note on the bug you shipped, and the conventions your team has been encoding in its fields all along. The loop that started with a failing test closed.

The field rules stay in the scrollback. The next exercise sweeps this whole session.

