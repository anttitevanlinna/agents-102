# Agents that build agents

## The handoff prompt that grows your kit

The shapes you drew are still in the session. Ask the agent to write you a handoff prompt to run later: one skill, with its checks.

{{prompt:agents-that-build-agents-handoff}}

What comes back is a prompt, not a plan. Save it where you will find it.

