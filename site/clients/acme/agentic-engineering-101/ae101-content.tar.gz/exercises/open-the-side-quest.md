# Two windows on one codebase

**Time:** ~5 minutes.

Module 3 runs in two windows. Security is the main quest in your chosen repo. Quality is a side-quest in a sibling worktree.

**What you do:** start a security session in your repo, fork a sibling worktree, and open a second session there.

**What you build:** two Claude Code sessions running side by side on one git history.

## Fork the side worktree from your security lane

- Security is the main quest. Start it in your repo. This is your main lane for Module 3. Access mapping, STRIDE, and the ADR all live here.

**Session** *(new, "m3-security")*

```
/rename m3-security
```

- A sibling worktree is a second working directory on the same git history. It opens next to your repo, useful when two unrelated changes run concurrently, each on its own branch and working state. `git worktree add` makes the sibling folder on its own branch; a new Claude Code session in another window works there; both sessions see the same git history but keep their own working state. The [Multi-session and Git survival guide](../trainings/agentic-engineering-101/reference/multi-session-git.md) carries the longer read.
- Personal files like `CLAUDE.local.md` don't sync between worktrees. They get copied across once at fork time, then evolve independently.
- Decide where to base the side worktree. It branches off your current local HEAD. Clean main is the safe default. If you want another base, switch to it before you fork.

Ask Claude to fork a sibling worktree and copy your personal rules across. The prompt reads your repo's folder name from the working directory: paste it as-is, Claude fills in `<repo-name>` itself.

{{prompt:ae101-m3-fork-quality-side}}

## Read back the worktree path

- Claude reports the sibling worktree path. That path is where the second session opens.

## Open the quality lane in the new worktree

- This is your side-quest lane. Start a second Claude Code session in another window, in the sibling worktree directory Claude just named.

**Session** *(new, "m3-quality")*

```
/rename m3-quality
```

- Authoring and invoking the test-strategy skill both happen in this window, on this codebase. It installs to user scope, so it crosses back to the main lane on its own, and you never carry it by hand. The main lane reads it later, at a step that revisits this window's scrollback rather than invoking anything here again, and the evidence-based sharpen runs there too, where the compound step lives.
- Ask Claude to confirm the worktree state, then wait.

{{prompt:ae101-m3-quality-side-orient}}

## Set the two windows side by side

- Two windows, side by side, both visible at once. Each holds its own scrollback. Arrange them so neither disappears behind the other.
- The move this module installs: when one window kicks off a long-running prompt, the other is where you work. Module 3's exercises name which window the work runs in, and where the switch points are.

**What happened:** You forked a sibling worktree for the quality side, opened two Claude Code sessions (one in your repo, one in the sibling), and confirmed each reads the same codebase from a different working directory. Security picks up in the main window at the next exercise. The quality side waits.

