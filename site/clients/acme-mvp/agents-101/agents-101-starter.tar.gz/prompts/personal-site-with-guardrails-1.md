---
key: personal-site-with-guardrails-1
dest: Claude Code
runtime: any
---
Build me a personal HTML one-pager site from the LinkedIn profile below. Save it as `module-1/site.html`.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-1-the-boring-baseline
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-2-apply-a-framework-you-know

End your reply with [Apply a framework you know](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-2-apply-a-framework-you-know). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.

LinkedIn:
