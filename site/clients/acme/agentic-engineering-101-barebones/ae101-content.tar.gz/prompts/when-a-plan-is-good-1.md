---
key: when-a-plan-is-good-1
dest: Claude Code
permission-mode: plan
runtime: any
---
How did your behaviour change now that we are in plan mode? Did your base prompt change, or what?
