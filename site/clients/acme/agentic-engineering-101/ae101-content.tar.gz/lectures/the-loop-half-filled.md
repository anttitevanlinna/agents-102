# The loop half, filled in

## Back to the map: near half filled

- Three modules in, the near half is lived ground. M1 stepped into the territory without the map, on purpose. The map arrived at M2, and everything since has landed on its near half: Intent, Context, Work, and how a loop compounds. This close puts names on the ground covered.
- **One loop, three sizes.** The agent's act-observe-correct inside a session; your orient, act, verify, compound around each session (M1's orient, fix, compound, close cut at different joints); and the slow loop that carries a win from you to the team. Same shape at three altitudes; the strands the map draws (context, plan, build, checking) are the same shape again, each wearing different work.
- A name is a handle, not a lesson. Every law coming up is a move already made. Naming it makes the move findable on Tuesday, transferable to a teammate, and checkable when it stops working.

<figure class="diagram">
<svg viewBox="0 0 1200 560" role="img" aria-label="The compounding engine at the M3 close: the near half (Intent, Context, Work) filled in and named, its loops drawn firm, with the compounding loop lit; the far half (Verification, Absorption, Outcome) sits under a haze marked ahead, its checking loop still dashed." style="display:block;width:100%;height:auto;background:#efe6d2;border:1px solid #c5b68d;border-radius:6px;">
<defs>
<linearGradient id="lh-wall" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2f6b6b"/><stop offset="1" stop-color="#a05a2c"/></linearGradient>
</defs>
<rect x="0.5" y="0.5" width="1199" height="559" rx="7" fill="#efe6d2"/>
<rect x="1000" y="12" width="190" height="534" fill="rgba(201,121,66,0.06)"/>
<line x1="1000" y1="12" x2="1000" y2="546" stroke="#c97942" stroke-width="1" stroke-dasharray="4 6" opacity="0.45"/>
<g stroke="#d6c8a3" stroke-width="1" opacity="0.8">
<line x1="200" y1="12" x2="200" y2="546"/><line x1="400" y1="12" x2="400" y2="546"/><line x1="600" y1="12" x2="600" y2="546"/><line x1="800" y1="12" x2="800" y2="546"/>
<line x1="12" y1="56" x2="1188" y2="56"/>
</g>
<g text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="3" fill="#8a3a2a" opacity="0.85">
<text x="100" y="26">01</text><text x="300" y="26">02</text><text x="500" y="26">03</text><text x="700" y="26">04</text><text x="900" y="26">05</text><text x="1100" y="26">06</text>
</g>
<g text-anchor="middle" font-family="Roboto Slab, Georgia, serif" font-size="15.5" fill="#4a4234">
<text x="100" y="44">Intent</text><text x="300" y="44">Context</text><text x="500" y="44">Work</text><text x="700" y="44">Verification</text><text x="900" y="44">Absorption</text><text x="1100" y="44" fill="#a05a2c">Outcome</text>
</g>
<text x="1180" y="76" text-anchor="end" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10" letter-spacing="2.5" fill="#a05a2c" opacity="0.85">THE TEAM →</text>
<g stroke="#cbbd98" stroke-width="0.9" fill="none" opacity="0.55">
<path d="M12,200 C170,150 310,265 490,225 S810,145 1010,250"/>
<path d="M12,370 C210,425 350,315 530,385 S830,465 1030,370"/>
</g>
<g fill="none" stroke-linecap="round" stroke-linejoin="round">
<path d="M112,208 C136,190 190,252 186,300 C182,348 122,392 100,372 C78,352 88,226 112,208 Z" stroke="#2f6b6b" stroke-width="1.8" opacity="0.65"/>
<path d="M208,222 C240,178 352,152 390,172 C424,190 396,244 340,266 C284,288 216,276 202,252 C194,238 198,234 208,222 Z" stroke="#2f6b6b" stroke-width="2.6" opacity="0.9"/>
<ellipse cx="300" cy="340" rx="98" ry="34" transform="rotate(8 300 340)" stroke="#2f6b6b" stroke-width="1.8" opacity="0.6"/>
<ellipse cx="445" cy="290" rx="58" ry="44" stroke="#2f6b6b" stroke-width="1.8" stroke-dasharray="3 9" opacity="0.45"/>
<path d="M436,306 C428,288 496,300 548,287 C600,274 712,222 750,230 C788,238 800,310 774,336 C748,362 652,386 596,380 C540,375 444,324 436,306 Z" stroke="#2f6b6b" stroke-width="3.4" opacity="0.95"/>
<ellipse cx="690" cy="286" rx="48" ry="17" transform="rotate(-5 690 286)" stroke="#2f6b6b" stroke-width="1.6" opacity="0.75"/>
<ellipse cx="822" cy="393" rx="145" ry="30" transform="rotate(-3 822 393)" stroke="#2f6b6b" stroke-width="1.8" stroke-dasharray="3 9" opacity="0.45"/>
<path d="M604,158 C582,136 700,118 736,124 C772,130 790,172 812,192 C834,212 906,254 872,248 C838,242 626,180 604,158 Z" stroke="#2f6b6b" stroke-width="2" opacity="0.7"/>
<path d="M604,158 C548,66 400,62 300,62 C210,62 160,95 122,192" stroke="#2f6b6b" stroke-width="1.8" stroke-dasharray="2 8" opacity="0.6"/>
<path d="M866,244 C858,230 998,244 1034,260 C1070,276 1110,340 1082,338 C1054,335 874,257 866,244 Z" stroke="url(#lh-wall)" stroke-width="2.4" opacity="0.8"/>
</g>
<g fill="#2f6b6b">
<polygon points="94,367 99,379 107,371"/>
<polygon points="398,176 383,165 381,179"/>
<polygon points="758,232 744,223 742,237"/>
<polygon points="588,379 603,373 604,387"/>
<polygon points="820,200 805,189 802,199"/>
<polygon points="119,201 128,190 118,186"/>
<polygon points="644,301 655,296 656,307"/>
</g>
<polygon points="1086,348 1075,333 1093,335" fill="#a05a2c"/>
<text x="445" y="300" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="26" fill="#2f6b6b" opacity="0.45">?</text>
<g text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" letter-spacing="2.5">
<text x="95" y="412" font-size="12.5" fill="#2f6b6b">THE CONTEXT LOOP</text>
<text x="330" y="88" font-size="14" fill="#1f1a13">THE PLAN LOOP · CORE</text>
<text x="300" y="412" font-size="12.5" fill="#2f6b6b">THE SECURITY LOOP</text>
<text x="528" y="210" font-size="12.5" fill="#786c56">◌ THE PROTOTYPING LOOP</text>
<text x="600" y="448" font-size="12.5" fill="#2f6b6b">THE BUILD LOOP</text>
<text x="660" y="330" font-size="11" letter-spacing="2" fill="#2f6b6b">THE AGENT'S OWN LOOP</text>
<text x="850" y="448" font-size="12.5" fill="#786c56">◌ THE CHECKING LOOP</text>
<text x="760" y="88" font-size="12.5" fill="#2f6b6b">↻ THE COMPOUNDING LOOP</text>
<text x="1055" y="430" font-size="12.5" fill="#a05a2c">↻ CROSSING THE WALL</text>
</g>
<g text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#4a4234">
<text x="95" y="427">grounds the plan</text>
<text x="330" y="103">decide · pin down what correct means</text>
<text x="300" y="427">amends the plan · what safe means</text>
<text x="528" y="225" fill="#786c56">spin a throwaway to finish the plan</text>
<text x="600" y="463">run · let it fail · shape the verifier · re-run</text>
<text x="660" y="344" font-size="10">act · read the result · correct</text>
<text x="850" y="463" fill="#786c56">read · judge · gate what ships · by hand for now</text>
<text x="760" y="103">each session's evidence → the next session's rules</text>
<text x="1055" y="445">prove it on yourself → promote</text>
</g>
<g text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="16" fill="#1f1a13">
<text x="100" y="507">A task worth running</text><text x="300" y="507">A grounded picture</text><text x="500" y="507">A candidate change</text><text x="700" y="507">A verdict you trust</text><text x="900" y="507">A win taken up</text>
</g>
<text x="1105" y="132" text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="17" fill="#1f1a13">Trusted shipped change</text>
<text x="1105" y="150" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9" letter-spacing="2" fill="#a05a2c" opacity="0.85">CROSSES TO THE TEAM ↗</text>
<g font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="2">
<text x="28" y="534" fill="#786c56">A FUZZY IDEA</text>
<text x="1172" y="534" text-anchor="end" fill="#a05a2c">TRUSTED · SHARED VALUE →</text>
</g>
<rect x="600" y="56" width="588" height="490" fill="#efe6d2" opacity="0.55"/>
<g text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" letter-spacing="2.5" paint-order="stroke" stroke="#efe6d2" stroke-width="4" stroke-linejoin="round">
<text x="760" y="88" font-size="12.5" fill="#2f6b6b">↻ THE COMPOUNDING LOOP</text>
<text x="528" y="210" font-size="12.5" fill="#786c56">◌ THE PROTOTYPING LOOP</text>
<text x="600" y="448" font-size="12.5" fill="#2f6b6b">THE BUILD LOOP</text>
<text x="660" y="330" font-size="11" letter-spacing="2" fill="#2f6b6b">THE AGENT'S OWN LOOP</text>
</g>
<g text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="4" stroke-linejoin="round">
<text x="760" y="103">each session's evidence → the next session's rules</text>
<text x="528" y="225" fill="#786c56">spin a throwaway to finish the plan</text>
<text x="600" y="463">run · let it fail · shape the verifier · re-run</text>
<text x="660" y="344" font-size="10">act · read the result · correct</text>
</g>
<text x="306" y="522" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="2" fill="#8a3a2a">NAMED SO FAR: INTENT · CONTEXT · WORK</text>
<text x="894" y="522" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="2" fill="#8a3a2a">THE FAR HALF · AHEAD</text>
</svg>
</figure>

## The loop and the model it runs on

- The agent loop is a **closed-loop controller**. (Work) It acts, observes the result, and corrects. Cut the feedback signal (a test, a check, a read) and it drifts. Signal quality is part of the law: a flaky test is a closed loop that still drifts. Everything you did in plan mode was feeding that signal early.
- **Local success, global drift.** (Work) The agent can win the function and lose the system. The drift lives in what nothing is watching: the dimensions your tests and reads don't cover. That is why the second read exists; one kind of scrutiny catches one kind of miss.
- Your context files are the agent's model of the system. (Context) `CLAUDE.md` and `CLAUDE.local.md` steer because the agent conditions every move on what they hold. What the files don't carry, the agent must rediscover or guess each session. Thin model, thin steering; the craft of shaping what the agent sees is called **context engineering**.

## How the loop compounds

- **The compound ladder**: fix → memory → skill → system. (spans the loop) One cycle is a fix. A rule is memory. A skill is reuse. Enough of them is a system that learns faster than the field moves. Your kit is already two rungs up: rules on the memory rung, the test-strategy skill on the reuse rung.
- **Double-loop learning.** (spans the loop) Single-loop fixes the failing test. Double-loop changes the rule that let the bug recur. Every time a rule gets sharpened from session evidence rather than rewritten from taste, that is the double loop running.

## The governor you carry forward

- **A governor is a pre-action question.** The smallest usable form of theory: it fires before the session, costs one sentence, and steers everything after. Laws explain what happened; a governor decides what happens next.
- **Name the uncertainty before you move.** (Intent) Aim the work at the unknown that will teach you the most. It is the question that opens every good plan, and it is the near half's one governor.
- It travels. It prices a plan read, picks the feature worth agent time, and tells you when a skill is worth authoring. A task that can't answer "what does this settle?" isn't aimed yet.

## Reading was never the control

- The outputs in this module were the biggest yet, and control never came from reading them whole. It came from three moves you already made.
- The delta note held the access map against what you already knew of the codebase, in both directions. A probe, not a read. The one-threat pick rejected most of the STRIDE walk with a named reason. The skill critique made the artifact name its own weakest part before it earned trust.
- **Control is interrogation.** Ranked list first, probe where you know most, make the output name its weak spot. The full record stays on disk. You can always read more; you can never read all.

## The branch is the permission

- The side quest ran on its own branch all module and never merged. That is the shape, not an accident.
- On a branch, acting without full control is safe: the blast radius is the branch. Let the agent run, read what your judgment flags, and leave the rest on disk.
- Control is exercised at the merge. The ranked findings, the delta against what you know, the weak spot named: the interrogation happens there, and the merge waits until the work survives it.
- An un-merged branch is not unfinished work. Holding the merge until control is earned is the control working.

## The far half goes quiet

- The near half ran on quick feedback. Every move so far returned a result you could read within minutes: a diff, a plan, a test run. You were the feedback signal, and you were never far from the loop.
- The far half is what happens when that goes quiet. Verification, Absorption, Outcome: the phases that govern work that runs long and alone. Different country, different rules. M4 opens it.
- Nothing from the near half retires. The loop, the model in the files, the ladder, and the governor keep running underneath. The far half adds the question the near half never made you ask: how do you trust work you didn't watch?

