# Exercise: Organisers prepare Claude Basics

**Time:** 2 hours before the workshop. Organisers only.

This is the setup exercise for the 3-hour live workshop. The live room has two moving parts: the repo demo and the rollout-crux synthesis. The build-and-verify exercises are homework in each participant's own safe folder.

## What organisers need to understand

Use one shared SharePoint workshop folder for the live synthesis. Everyone syncs that same folder before the workshop. Inside it, create one first-name folder for each participant and one directory named `shared/`; individual notes go in the first-name folders, group synthesis files and the optional organisers' readout go in `shared/`.

Participants do their build-and-verify homework later in an empty personal folder they choose. That homework does not use the shared SharePoint folder.

The public workbook gives prompts and file names. The actual group syntheses and any customer context stay in the customer's environment.

Participants copy the workbook prompts into Cowork. In the live crux exercise, the important mechanics are: each person can save personal notes in their own first-name folder, one group driver can read the group's first-name folders and write the group synthesis to `shared/`, and organisers can read the group files after they sync.

The synthesis comes from sync plus constraint. Most participants do not write shared files. Group drivers write the small number of group synthesis files. Once those files have synced, organisers can run the synthesis prompt without collecting documents manually or opening private participant folders.

Assume eventual consistency. A file that was just saved may need a moment before another Cowork session can read it. If synthesis cannot see a group file immediately, confirm the filename, confirm the `shared/` directory, wait briefly, and retry. Do not turn that moment into a content discussion.

The organiser role is mechanical and custodial, not epistemic. Organisers keep access, folders, filenames, timing, and synthesis moving. Participants do the rollout judgment.

## Phase 1. Prepare the live demo

Confirm the trainer can open the live demo without hunting:

- public workbook URL
- repo or screen-share setup for the trainer's system demo
- two or three prepared stops that show rules, prompts, checks, output, and a recent change

The demo should show structure, not become a code walkthrough.

## Phase 2. Prepare the live synthesis workspace

Create or confirm the shared SharePoint workshop folder. Make sure every participant and organiser has synced it locally before the workshop.

Inside the synced SharePoint workshop folder, create:

- one first-name folder per participant, such as `aino/`, `petra/`, or `juhani/`
- one directory named `shared/`

Expected file names:

- `rollout-synthesis-<label>.md` for each group synthesis. The label comes from the group driver prompt: a group name if the group gives one, or a crux-based label if the group does not
- `organisers-rollout-readout.md` if the optional organisers' readout runs

Keep workshop materials in the shared SharePoint workshop folder.

## Phase 3. Prove group-driver access

Before the workshop, prove at least one likely group driver can do all of this:

- open Cowork on the synced SharePoint workshop folder
- read test `rollout-notes.md` files from two first-name folders
- save a test markdown file in `shared/`
- see the saved file from another organiser's machine

If this fails, fix SharePoint sync or folder permissions before the room arrives. Do not debug shared writes live.

## Phase 4. Prepare group mechanics

Decide the grouping in the room. Each group can name itself on the fly. If a group does not care, Claude invents a short label from the selected crux.

Do not pre-assign group drivers unless access constraints require it. Each group should choose the person most comfortable operating Cowork.

## Phase 5. Dry-run the organiser prompt

Run a quick rehearsal of the organiser-only rollout synthesis prompt using dummy files:

- `[Exercise: Organisers synthesize rollout](exercises/organisers-synthesize-rollout.md)`

Use fake group files or non-sensitive sample content. The point is to test file paths, save behavior, timing, and the organisers' push-back rhythm.

## Phase 6. Dry-run as one participant

Create or use one safe test folder. Run the live crux path from a participant point of view, not from an organiser/admin view.

Do a thin pass:

- save `rollout-notes.md` in a first-name test folder
- as group driver, save a dummy `rollout-synthesis-test.md` in `shared/`
- as organiser, read that dummy group file and save a dummy `organisers-rollout-readout.md` in `shared/`

Delete or clearly mark test files before the workshop. Keep any real customer content inside the customer environment.

The dry-run succeeds only if the participant path works without organiser-only permissions.

## Phase 7. Frame the homework

Make sure organisers can say the homework path plainly:

- open Cowork on an empty personal folder
- run the build-your-system homework there
- run the verification homework there
- keep the resulting `CLAUDE.md`, `response.md`, `verification-table.md`, and `homework-summary.md`

No organiser material is required for the homework.

## Phase 8. Confirm the day-of contract

Before the room arrives, confirm:

- organisers know where the public workbook is and can point participants to the live module prompts
- trainer can run the repo demo without searching
- organisers know how groups will be formed in the room
- at least one likely group driver has already saved a test file to `shared/`
- organisers can save `organisers-rollout-readout.md` if the optional readout runs
- the test participant dry-run has passed
- organisers can explain the homework folder model in one sentence

The workshop is ready when the demo path, `shared/` save path, and homework framing all work.

