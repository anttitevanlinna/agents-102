# Exercise: Your first *scheduled* agent

**What you do:**

You built a memory today. One live challenge, curated sources, a compiled set of claims. Now give it a pulse. This homework puts a scheduled agent in front of your memory so it reads the thing every morning and tells you something useful before you've had coffee.

**Pick one of three jobs.** Choose whichever fits your week:

- **Morning plan informed by the challenge** — reads the memory and your calendar, produces a 5-line plan that names which of today's meetings actually move the challenge forward and which are noise
- **Daily risk scan** — reads the memory and flags the one assumption in it most likely to be wrong, or the one open question that's gone unanswered longest
- **Draft today's next move** — reads the memory and drafts a single concrete next action for the challenge: a message to send, a question to ask someone, a small decision to make before end of day

Pick one. Not all three. Something you'd actually read tomorrow morning.

**Step 1 — connect any data the job needs.**

For the morning-plan job, you'll want your calendar connected. Open Claude Code desktop. Click the **+** next to the prompt box (or go to **Settings → Connectors**). Enable Google Calendar or Microsoft Outlook Calendar. Sign in with your work account.

For the risk-scan and next-move jobs, no connector needed — the agent reads your memory and that's enough.

**Step 2 — capture the look.**

Your daily output shouldn't read like a terminal dump. Steal the look and feel from your company's website (colours, typography, headers, the voice) and store it as a pattern the agent reuses forever. Same lesson as the memory: text on disk, referenced by name.

Remember Module 1's snake.html? Claude writes HTML files. You're about to give those files a house style.

Paste:

```
Look at my company's website. I'll give you a URL or paste a key page when you ask. Extract the visual pattern — primary and accent colours (with hex codes), font families, header shape, spacing, overall tone of voice. Write it to style.md at the training-directory root, in plain language (not a CSS file). Short and practical: a designer reading style.md should be able to produce something that looks like our site without visiting it.

Then append one line to my root CLAUDE.md under a new "Styling" heading: "When producing HTML output, follow style.md."

Show me both files before saving.
```

Give Claude the URL or paste a key page. It extracts, writes `style.md` at the root, appends the `CLAUDE.md` rule. Read both. Edit `style.md` where Claude missed something — if your brand has a hard rule ("never pure black," "always serif headings"), put it in. The rule you just added to `CLAUDE.md` means every agent you build from here on will use this style when it produces HTML.

**Step 3 — write the agent's instructions.**

In your training directory, create `module-2/morning-agent/`. Paste this prompt:

```
I'm setting up a daily agent that reads my challenge memory every morning and reports back as a stylised HTML page. Ask me, one at a time:

1. Which job — morning plan, daily risk scan, or next-move draft?
2. What should the output look like — how long, what sections, what voice?
3. What must this agent never do? Name at least one hard boundary.

When I've answered all three, write the file at module-2/morning-agent/morning.md. The output instructions say: write the result as a single self-contained HTML file to module-2/morning-agent/latest.html, following the styling rules in style.md at the training-directory root. One file, overwritten each day. Show me morning.md before saving.
```

Claude asks, you answer, the file lands. Read it. Edit anything that doesn't sound like you.

**Step 4 — schedule it.**

In the desktop app, open the **Schedule** sidebar. Click **New task → New local task**. Fill in:

- **Name:** `Morning memory` (or whatever you want to see)
- **Frequency:** Daily at the time you actually want it to fire — 7:00 AM for most people
- **Prompt:** the single line below

```
Read module-2/morning-agent/morning.md and run the job. Read the current state of memory/ as context. Follow the rules in that file and in the root CLAUDE.md. Write the output to module-2/morning-agent/latest.html.
```

Save. Click **Run now** once. Double-click `latest.html` in your file browser — it opens in your browser and should look like it came off your company site. Fix anything off by editing `morning.md` or `style.md` — the scheduled task reads both every run, so tomorrow picks up the change.

**Step 5 — let it run for a week.**

Don't retune for the first three days. Watch what it produces as-is. Every morning, open `latest.html`. Watch for:
- Days when the output is genuinely useful — what made it work?
- Days when the output is comical or wrong — what was missing from the memory that would have saved it?
- Claims the agent made that you, the domain expert, know are off — those are your next memory edits.
- Styling drift — is `latest.html` still looking like your company site, or has it slowly gone generic? That's a signal to sharpen `style.md`.

The memory is alive now. What the agent misses today is a prompt to sharpen the memory tomorrow — and the HTML you open with your coffee is a system, not a document.

**What happens:**

Your memory stops being a snapshot and starts being a system. Every morning the agent reads it, pushes something back at you — in your own house style, not Claude's — and gives you one more piece of evidence about what's sharp and what's soft. A week of this and the memory looks different from the one you left class with, because you kept noticing. The HTML looks different too, because you kept tightening `style.md`.

**The point:**

A memory that sits there is a document. A memory that gets read by an agent on a schedule, producing output that looks like it belongs to your company and that you actually respond to, is the start of a loop. Module 2 built the memory; this homework builds the loop. Every subsequent module compounds on it — and `style.md` travels with you. Every agent you build from here on that produces HTML will look native to the organisation, because the rule is in the file every agent reads.

**Time:** 35 minutes to set up. One glance each morning for a week.

