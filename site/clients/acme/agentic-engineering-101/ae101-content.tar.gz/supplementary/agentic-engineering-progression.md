# The agentic engineering progression

Agentic engineering is the discipline of progressively extending an engineer's reach with AI. The engineer remains the active party: choosing what to attempt, shaping the conditions, judging the result, and deciding what the system should learn.

## Part 1: The progression

The levels run from assistance to a system you keep improving. Each level holds until it exposes the constraint the next one removes: what moves an engineer up is not ambition, it is a limit met in real work.

In March 2026, Fredrik Wollsén and Jesse McCrosky described a similar team-scale movement in [The AI-Native Engineering Playbook: Crawl, Walk, Run, Fly](https://positivelyfred.substack.com/p/the-ai-native-engineering-playbook). Their labels differ. The recurring progression is from using the agent inside one task to engineering the conditions behind many tasks.

## Assistance

AI helps with work already on your desk. It completes a function, explains a file, drafts a test. You stay beside it, supplying context and correcting each move, and you read everything before you use it.

**Moves you up:** the agent can act, not just answer, and carrying each suggestion into the code by hand is the slow part. The door is trust at one edit's scope, held by your own eyes and a test run. The way up is letting it edit a file and run the tests while you watch.

## Interactive work

One conversation, one task. The agent reads the code, proposes a change, and acts; you steer each step and watch the result land. Working side by side is where trust starts: you see what it gets right without you, and what it should never be left alone with. It is also where you return on an unfamiliar codebase.

**Moves you up:** once observed competence covers a whole task shape, standing beside every step is the expensive part. The door is trust across that whole shape, held by the task's conditions and its done-evidence instead of by your presence. The way up is handing one outcome over and judging what comes back.

## Delegating bounded outcomes

You hand over an outcome, not a step: the agent reads the repository, makes the change, runs the checks, and returns a diff. You have not left engineering. You have widened what you engineer: the task, the conditions around it, and the evidence that says it is done. Durable files let a handoff stretch longer, and verification lets it stretch farther without losing control.

**Moves you up:** a delegated task leaves you waiting, and waiting is capacity. The door is trust that survives your absence, held by durable files an agent can read cold and checks that run without you. The way up is shaping a second task and starting it beside the first.

## Directing parallel sessions

Once one task runs without your constant attention, another runs beside it. Worktrees separate the changes, durable files carry the context, and checks establish what deserves to survive. You direct several sessions rather than one conversation.

**Moves you up:** parallelism demands coordination, and the coordination repeats: the same handoffs, the same checks, the same merge discipline. The door is trust in the recurring task itself, held by a check you wrote into it. The way up is writing one loop down and letting a session run it.

## Encoding checked loops

Recurring work becomes a loop with its own checks: the task shape is written down, the gate that checks the result is part of it, and a session can run it end to end. You review outcomes instead of keystrokes.

**Moves you up:** a working loop no longer improves when you prompt harder; it improves when its surroundings do. The door is trust in the gates' own verdicts, held by calibration, the checking of the checks. The way up is working on the surroundings: the rules, the memory, the checks every session starts from.

## Improving the system

You improve the files, memory, skills, and verification that make every subsequent session stronger. Every fix that becomes a rule and every check that becomes a gate raises the floor of all future work. The limit keeps moving outward too: eventually it is what you can review, and what your team can absorb.

The measure is not maximum delegation. It is knowing what to delegate, how far to let it run, and what evidence to demand.

## Part 2: The leverage model

{{figure:delegation-frontier}}

- **Reach** is how much you delegate: the size of the task and the distance between checks.
- **Calibration** is whether trust in the result was earned by a check you have verified.
- High reach splits on calibration. Measured gates produce calibrated agency. Unmeasured green produces reckless autonomy.
- The frontier moves outward only as fast as the gates behind it. Push reach past calibration and you are checking less, not delegating more.

At the high-reach edge, scale makes the distinction visible. In August 2026, Wollsén wrote in [This is getting ridiculous: I shipped 490 pull requests in June](https://positivelyfred.substack.com/p/this-is-getting-ridiculous-i-shipped) that he kept 30 to 40 sessions open and actively managed 10 to 15 through a working day. By his own estimate, the value his four-engineer team delivered ran far below what its pull-request count alone would suggest: he kept output volume and delivered value on separate axes.

Leverage is not reach alone. It is reach that measured trust can keep up with.

## One model, not two

The progression and the leverage model describe the same thing. Every **Moves you up:** is a check getting cheap enough to license more reach, so the levels are calibration states, not ranks. Read the doors again: the same trust every time, at a larger scope, held by a check that needs less of you. That is why an unfamiliar codebase sends you down a level, and why moving down is the model working.

