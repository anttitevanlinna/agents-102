# When a plan is good

**Session** *(new, "Module 2 - Plan mode done right")*

```
/rename m2-plan-mode
```

## Plan mode changes the tools and the instructions

- Plan mode removes the edit tools and swaps the instructions to explore and propose. You press Shift+Tab until the status bar shows plan mode on. The agent reads files, runs shell commands to explore, and writes a plan file, but it won't edit your source until you approve.
- The read-only part is load-bearing. Plan mode isn't "Claude thinks before doing." It's "Claude writes a thing you can read, edit, and push back on before your source changes."
- The plan is saved on disk under a descriptive filename such as `migrate-auth-hash-calm-otter.md`. You can find it again without searching the chat.
- You will notice the wait. While Claude plans, other sessions could be making progress elsewhere. Not today, but soon.

## Optional: ask plan mode directly

A 30-second move first. Enter plan mode in your own session right now and ask Claude what shifted from its side.

Ask Claude to describe what changed in its behaviour when plan mode turned on.

{{prompt:when-a-plan-is-good-1}}


Watch what comes back. Sometimes Claude names the read-only state directly, sometimes the specific instructions it is following. Skip if you trust the framing.

## Five things a good plan has

- **A specific file list.** Not "update the config." *Which* config, *which* keys. A plan that names three files has made three decisions. A plan that says "the relevant files" has made zero.
- **An early runnable slice.** Find the first step after which something runs end-to-end. A plan that builds layer by layer (data, then services, then UI) answers "the last one," and every wrong guess stays hidden until then. A plan that stands up a thin end-to-end slice early gets checked by reality from step two onward.
- **A verification step** that could actually fail. *"Run the tests"* is cosmetic; *"run `pytest tests/auth/ -k hash` and expect 14 passing, 0 failing"* is a gate. The test is whether, reading the step alone, you could tell Claude it failed and Claude would know what to fix.
- **Named assumptions.** Good plans flag what they're assuming (library versions, schema shapes, whether a teammate's migration ran last week). A plan without assumptions isn't assumption-free; it's just assumption-silent.
- **A list of non-goals.** What the plan will *not* touch. Every adjacent improvement looks helpful, so the agent does the ones you never ruled out. (Dex Horthy)

## Three pressures that make bad plans look good

- **Structure is persuasive.** A 7-item plan with section headers and bold text looks like a decision. It often isn't. It's a draft formatted like a decision. The formatting is the trap.
- **Reasonableness passes for rightness.** Each step sounds reasonable, so the plan sounds right. But three reasonable steps in the wrong order still ship a bug. Read the sequence, not the steps.
- **You already agree with it.** The plan matches what you'd have written, which feels like alignment. But Claude wrote it from a partial read of the codebase and your instinct isn't a substitute for the read. Agreement is cheap; the read is what matters.

## Two reads, paired

- Your read and the agent's walk-down catch different misses. You bring the voice of experience: the soft item, the step that contradicts how this codebase actually works. The agent brings breadth: it can keep walking branches without getting bored or skipping the dull ones.
- The full grilling is an offer, not an obligation. Order matters: your push-back first, so your read stays in the driver's seat; then let the walk-down surface what you did not see. Stop when another answer would no longer materially sharpen the plan.
- Check the revision, not the acknowledgement. The agent agrees easily. A flagged step can come back softened rather than sharpened. A push-back is finished when the regenerated plan is sharper, not when Claude says it heard you.

If the plan still has open questions, run the walk-down. If it's all clear, your read is enough.

## Find is easier than judge

- Generating candidates is cheap for the agent; judging them is where you're needed. Stuck naming a soft item? Ask Claude which step it's least confident about. That answer is a candidate. Whether it matters depends on the codebase and the task.
- The agent finds, you judge, and everything from here sharpens one side or the other. The split runs through the whole discipline.

## Plan review is a high-leverage gate

- A plan is a check before implementation. One correction can redirect every step that follows before the agent turns the plan into code.
- What the plan doesn't decide, the agent decides mid-run, inside work in flight, and you will not notice. A wrong call propagates across files, and the wrongness tangles with everything built after it: what would have been a line edit in the plan becomes an untangling job in the code.
- Aim the read at the unknown that teaches you the most. The branches worth walking are the ones that change what done means. The rest you'd settle in verification anyway.
- You don't have to execute a plan to know it's good. Recognizing a good plan is the skill; the execution can wait for the day the task is real.

## What you can test and check sets your complexity ceiling

<figure class="diagram">
<svg viewBox="0 0 1200 560" role="img" aria-label="A two-by-two map of delegated work. Horizontal axis: reach, how much you hand off. Vertical axis: calibration, whether trust was earned by a measured gate. Four states: chat-shaped work bottom-left, controlled assistance top-left, reckless autonomy bottom-right, calibrated agency top-right. A dashed ochre curve labelled the frontier rises from low reach at low calibration to high reach at high calibration, and moves outward as fast as the gates behind it." style="display:block;width:100%;height:auto;background:#efe6d2;border:1px solid #c5b68d;border-radius:7px;">
<rect x="0.5" y="0.5" width="1199" height="559" rx="7" fill="#efe6d2"/>
<rect x="12" y="12" width="1176" height="536" fill="none" stroke="#d6c8a3" stroke-width="1" opacity="0.9"/>
<rect x="650" y="270" width="500" height="200" fill="rgba(138,58,42,0.05)"/>
<g stroke="#d6c8a3" stroke-width="1" stroke-dasharray="2 8" opacity="0.8">
<line x1="650" y1="70" x2="650" y2="470"/>
<line x1="150" y1="270" x2="1150" y2="270"/>
</g>
<g stroke="#786c56" stroke-width="1.6" stroke-linecap="round">
<line x1="150" y1="470" x2="1140" y2="470"/>
<line x1="150" y1="470" x2="150" y2="80"/>
</g>
<g fill="#786c56">
<polygon points="1150,470 1138,464 1138,476"/>
<polygon points="150,70 144,82 156,82"/>
</g>
<text x="650" y="505" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#786c56">REACH · HOW MUCH YOU HAND OFF →</text>
<text x="125" y="270" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#786c56" transform="rotate(-90 125 270)">CALIBRATION · TRUST, MEASURED ↑</text>
<g text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="12.5" letter-spacing="2">
<text x="400" y="150" fill="#2f6b6b">CONTROLLED ASSISTANCE</text>
<text x="400" y="400" fill="#2f6b6b">CHAT-SHAPED WORK</text>
<text x="800" y="150" fill="#2f6b6b">CALIBRATED AGENCY</text>
<text x="960" y="400" fill="#8a3a2a">RECKLESS AUTONOMY</text>
</g>
<g text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234">
<text x="400" y="168">small handoffs, tight review</text>
<text x="400" y="418">you read everything</text>
<text x="800" y="168">big handoffs, gates and checks you trust</text>
<text x="960" y="418">big handoffs, green you took on faith</text>
</g>
<path d="M 480,470 C 640,420 760,330 850,240 S 980,120 1020,70" fill="none" stroke="#a05a2c" stroke-width="2.4" stroke-dasharray="7 7" opacity="0.85"/>
<text x="935" y="205" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="11" letter-spacing="2.5" fill="#a05a2c" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">THE FRONTIER</text>
<text x="935" y="221" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">moves as fast as the gates behind it</text>
<line x1="880" y1="250" x2="945" y2="250" stroke="#a05a2c" stroke-width="1.8" stroke-linecap="round"/>
<polygon points="955,250 943,244 943,256" fill="#a05a2c"/>
<text x="650" y="533" text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="15.5" fill="#4a4234">The frontier: the largest task you can hand off, well designed, enough unclarity removed.</text>
<text x="1176" y="36" text-anchor="end" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9" letter-spacing="2" fill="#8a3a2a">TWO AXES · FOUR STATES</text>
</svg>
</figure>

- Every task you hand off sits on two axes. Reach is how much you delegated: the size of the task, the distance between checks. Calibration is whether your trust in what came back was earned by a check you have verified.
- The plan read is a calibration move. It is cheap, it runs before anything is built, and its cost does not grow with the size of what you approved.
- Reach without calibration is what the three pressures produce: a plan that reads well, approved at a scope your read never actually covered.
- Push reach past what you can check and you have not delegated more. You are checking less.
- The ceiling is not fixed. Every check you make cheap and repeatable raises it, so building a better check buys you more than approving a bigger plan.

