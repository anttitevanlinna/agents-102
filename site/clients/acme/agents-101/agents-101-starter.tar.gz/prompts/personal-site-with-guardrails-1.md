---
key: personal-site-with-guardrails-1
dest: Claude Code
runtime: any
---
Build me a personal HTML one-pager site from the LinkedIn profile below. Save it as `module-1/site.html`.

LinkedIn:
