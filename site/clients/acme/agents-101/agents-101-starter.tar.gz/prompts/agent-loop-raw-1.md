---
key: agent-loop-raw-1
dest: Claude Code
runtime: any
---
What tools do you have available?
