# Set the markers, *send it off*

**Time:** 12 minutes.

**Session** *(continue, m4-walk-send)*

The same session that ran the audit. It already holds the scoped task.

**What you do:** pin where this session starts and where its record lives, then send the task off and step away.

**What you build:** a branch, a starting commit, and a transcript path the next session can find.

**The point:** send it off plainly and you find out what you can't steer yet.

---

## Phase 1: Set the two return markers

*5 min*

- Claude Code writes every session's scrollback to disk, live. The next session reads this one from that file.

Ask Claude where the record of this session lives.

{{prompt:ae101-m4-locate-transcript}}

## Pin the starting point

- Whatever sits in your working tree lands in this commit. Unrelated WIP: scope it out first.
- The commit writes the branch name and the transcript path into `task.md`, so a later session recovers this experiment from disk instead of hunting for it.

Ask Claude to create a feature branch and commit current state, then report the short SHA.

{{prompt:ae101-m4-commit-starting-point}}

## Push it only if you want it off this laptop

- The commit is local, and that is the default. This is throwaway work you can reset away, and the next module forks from the local commit.

Ask Claude to push the branch to the remote.

{{prompt:ae101-m4-push-starting-point}}

## Phase 2: Send it off

*7 min*

Ask Claude to take the scoped task end-to-end in this same session.

{{prompt:ae101-m4-take-task-end-to-end}}

## Nudge sparingly while it runs

- Keep the laptop awake and plugged in (power settings → prevent sleep on power).
- Nudge by hand: answer a question, correct a path, push back on visible drift. Past ten or so interventions, you have become the agent; call it and read the transcript.
- If the session goes completely off the rails, stop it. The trace is the evidence either way.

If the agent stalls, ask it to keep going. The nudge reads as encouragement and lands as a taunt.

{{prompt:ae101-m4-nudge-continue}}

