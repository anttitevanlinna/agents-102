---
key: a101-prework-extract-tarball
dest: Claude Code
runtime: any
---
Download the starter tarball into the working folder and extract it. Use the shell:

  curl -fLO <CONTENT_URL>
  tar xzf agents-101-starter.tar.gz

If `agents-101-starter.tar.gz` is already in the folder, skip the download. If curl gets a 401, ask me for the username and password and retry. If curl cannot reach the internet, say so in one line and wait: I will download it in my browser and drag it into this folder.

(Leave `agents-101-starter.tar.gz` behind after extraction. It is harmless.)

Then list what's in the working directory and confirm these folders exist:
prework/, memory/, sources/, agents/, and module-4/policies/.
If tar is not available, tell me what error you got.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#3-install-the-training-folder-3-min
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min

End your reply with [Build a snake game](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.
