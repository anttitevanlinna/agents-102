# Compound and *close the loop*

**Time:** 30 minutes.

**What you do:** let Claude review the whole session and write your `./CLAUDE.local.md` from session evidence. Wire one MCP connector. Close the bug's ticket outside the repo.

**What you build:** three things that close the first compound loop outside the repo: a rules file written from session evidence, a live connector into your tracker, and a close-out note that lands where your team reads it.

**The point:** the compound step (plan → work → review → compound, Kieran Klaassen's loop) doesn't interview you with three retro questions. The session is the evidence; Claude reviews it and writes. You push back where it misread.

The PR shipped. Now compound the session, then close the bug's ticket. That's the first move outside the repo.

## Write your rules file from the session

- **The session is the evidence.** Claude reviews the whole scrollback in one shot and drafts your rules from how you actually worked. No three-question retro; the compound step reads what happened and writes.
- **You are not drafting from a blank page.** The agent reads the session for you. Your job is to push back where it misreads.

> **Long session, long read.** Claude reviews the whole scrollback in one shot. If the review stalls or runs past a couple of minutes, interrupt with `Esc`, narrow to the orient and introspect phases first, and say `continue`.

{{prompt:compound-and-close-1}}


## Push back where the summary misreads

- **Quote the moment back at Claude.** Read Claude's summary. Push back where it misreads. Quote the specific session moment back at Claude. That push-back is the reflection move.
- **The rules file is yours now.** Born from the session, extended by every module after this one.
- **The `.gitignore` edit is your call.** If `CLAUDE.local.md` wasn't already ignored, the compound step added it to your `.gitignore`. That is an uncommitted change now. What you do with it is your call.

## Reach past the repo with a connector

- **Your agent's reach stops at the repo.** Real engineering work spans tickets, pull requests, CI, chat, documentation: the system around the code. **MCP** is the protocol Claude Code uses to connect to that system. Three words land together: **connector** (the wire into a work app), **action** (a verb with effect in the world), **tool** (the umbrella for anything the model can call). Full primer in [MCP and connectors](../trainings/agentic-engineering-101/reference/mcp-and-connectors.md).
- **One connector, two actions (read + update), closes the loop** you just ran on the bug, in the tracker your team actually lives in.

## Wire one connector into your tracker

- **Pick the cleanest path for your tracker.** Three work:
 1. **GitHub Issues:** check `gh auth status` in your session. Claude runs `gh` for you via Bash, no MCP install needed.
 2. **MCP connector to your tracker** (Linear, Jira, other): follow the install line in [MCP and connectors](../trainings/agentic-engineering-101/reference/mcp-and-connectors.md) for your tracker. If tenant admin approval is required, it's worth asking, not today.
 3. **Manual paste:** Claude writes the close-out; you paste it into the tracker UI yourself. Five seconds, no tool setup.
- **The teaching moment is the agent reaching across a tool boundary with a real engineering note**, not the install choreography. For paths 1 or 2, get your connector up and running.

> **Connector added after this session started?** Check MCP status and authenticate with `/mcp`. If the new connector still isn't there, exit the session and resume it with `claude --resume <session-id>`.

> **Quick timebox note.** Second connectors and deeper MCP debugging may regress to install yak-shaving. One connector firing on one ticket is the proof the loop closes outside the repo. The rest is homework.

## Send the close-out note to the ticket

Ask Claude to read the ticket for your bug and report what's on it. Paste a ticket ID, a URL, or "create me a new one" if there isn't one.

{{cut:compound-and-close-2|project-admin}}


Claude reads the ticket (or confirms there isn't one). Then ask Claude to write the close-out (root cause, how you fixed it, a link to the PR), update the ticket, and report what it wrote.

{{cut:compound-and-close-3|project-admin}}


## Read the close-out and ship it

- **Read the close-out; push back if it's stiff or wrong.** Tell Claude how your team actually writes ticket comments. It'll adjust.
- **Ship the update** (or paste it into the tracker yourself on path 3). The bug fix is now visible where it should be: in the tracker your team reads, not only in the repo.

## Sweep the session into your rules file one more time

- **One more pass before close.** Anything earned since the first compound (the ticket beat, the push-backs, the catch on the missing PR) that didn't land yet?

Ask Claude to sweep the session for anything earned since the first compound and integrate.

{{prompt:compound-and-close-4}}

## Clear the session, the loop is closed

**What happened:** Your rules file was born from how you actually worked, not from a template. The first move outside the repo happened on a real job: the ticket for the bug you just shipped. Claude reviewed the session, you pushed back where it misread, and the close-out landed in the tracker where your team reads it.

The loop ran. The PR is open, the rules file was born from session evidence, the ticket is updated where your team reads it. Setup in place.

You can now clear. What you stored may or may not help you in future sessions. Let's find out then.

