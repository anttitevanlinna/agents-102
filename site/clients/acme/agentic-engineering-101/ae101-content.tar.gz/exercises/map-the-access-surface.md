# Map the access surface, own the *delta*

**Time:** 20 minutes.

**Window:** the main quest window (*m3-security*).

**What you do:** invoke the curated access-control skill on the feature you brought, and name what it missed.

**What you build:** an access-surface map plus the delta only you can add.

**The point:** STRIDE without an access-surface map is pub-quiz threat modeling.

---

## Take the ranked ten, leave the rest on disk

- From here on, outputs get big. The access map runs pages, the STRIDE walk after it runs longer, and soon two windows produce at once.
- The countermove from M1 goes to work: never let the agent say everything. The prompts here route the heavy output to disk and keep the chat read short, the saved map first, then a walk-through of what stood out.
- Your read is the short list, plus the two or three entries your own knowledge of the codebase flags. The file holds the rest until a decision needs it.
- When an answer balloons into an essay anyway, say so: ranked list first, ten lines. One sentence buys the time back.

## Phase 1: Run the curated skill on your feature and save the map

*7 min*

- You invoke; the skill does the breadth walk. The `access-control-analysis` skill was installed as a personal skill during prework, so Claude Code auto-discovers it by name in the m3-security session.
- See what skills your Claude has loaded first. In the Claude Code chat, type:

```
/skills
```

- You should see `access-control-analysis` and `stride` listed under **User**. (If they're missing, check back where the prework extracted the bundle and installed the curated skills.) The Project list is whatever this repo ships; User is your personal skills. Skills you author later in Module 3 land in User too.

Ask Claude to list its installed skills, with storage location and context-load status.

{{prompt:map-the-access-surface-1}}

These are the moves Claude has on hand for the rest of this module. Only each skill's name and description sit in context until you invoke one; the body loads then.

## Point the skill at your feature

Pick the feature and let the skill run. Ask Claude to invoke the access-control-analysis skill on the feature you type after the colon, and save the surface map to a temp directory.

{{prompt:map-the-access-surface-2}}

The plan path you noted at Module 2's close is the best input here: it names the files, the flows, and the scope the feature actually touches. Paste it, or a ticket link, a design-doc path, or the feature description; Claude reads whatever you give it. Then send. Claude narrates what the skill is doing before the map appears; skip past the opening and look for the saved path when it lands. The skill walks the surfaces and produces the map.

## Kick off the pass, then work the other window

- The access-control pass is a breadth walk and takes a few minutes. That wait is the two-window move Module 3 installs: kick off a long task in one window, do active work in the other, come back when the first lands.
- Switch to your m3-quality window now. While the map builds in m3-security, start *Author your test-strategy skill* there. It opens as a question-at-a-time conversation about how your codebase tests, so a couple of answers fit the wait. When the map lands back in m3-security, switch back to walk it and write the delta. Both windows are already open from *Open the side quest*; this is a focus switch, not a new session.

## Phase 2: Read the map back before you decide the delta

*3 min*

- You're back in m3-security now; the map landed here. The rest of this exercise runs in this window.
- See the structured read before you decide. Ask Claude to walk you through the surface map in chat: categories, key findings, ambiguous spots. You want the structured read in front of you before you name your deltas in Phase 3.

{{prompt:map-the-access-surface-3}}

## Phase 3: Add the surface the skill over-called, and the one it missed

*7 min*

- You decide which surface goes on each side of the delta. Two reads.
- **The over-call.** Where did the map flag something you'd have under-weighted? Lower-risk in your read, higher-risk in the skill's.
- **The miss.** What's missing that you know matters? Often the "weird bit" of your feature, the part you'd describe as not-quite-standard.
- If neither is obvious from a quick scan, ask Claude in chat to propose two or three candidates per side with a one-line reason each. Pick from those; push back if the reasons read generic.

Ask Claude to integrate the surface the skill called out harder than you would have into the map.

{{prompt:map-the-access-surface-4}}

Then ask Claude to add the surface the skill missed but you know matters.

{{prompt:map-the-access-surface-5}}

## Push back until the reason names your codebase

- Answer, then sharpen. Push back until the reason names something specific to your codebase. *"The billing webhook re-hits the queue on retry, so the same event gets reprocessed"* beats *"webhooks need auth."*

## Phase 4: Add the context header a cold reader needs

*3 min*

- You're about to hand this map to the STRIDE skill. Glance at it. If a teammate landing on this file cold would miss something the map assumes you know, add a one-line context header. If it reads clean, move on.
- Your call.

**What happened:** A short delta-note is on the record, and it is the artifact STRIDE reads next, not the raw skill output.

## What this sets up

The STRIDE exercise invokes the curated STRIDE skill on the map you just built. The surface map IS the input. If you rushed Phase 2, STRIDE threat-models a thin map; if you worked the delta, STRIDE has something real to chew on.

