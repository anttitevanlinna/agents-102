# Close the ticket *outside the repo*

**Time:** about 15 minutes, on your own.

**What you do:** wire one MCP connector into your tracker, then have Claude close the bug's ticket with a real close-out note.

**What you build:** a live connector into your tracker and a close-out note that lands where your team reads it.

**The point:** your agent's reach stops at the repo. The move that reaches past that boundary is a real one: the ticket for the bug you shipped in Module 1. One connector, and the loop closes where your team actually reads it.

Module 1 shipped the PR and compounded your rules file. The bug is fixed. The move that reaches outside the repo is closing its ticket, from the agent, not by hand.

## Reach past the repo with a connector

- Your agent's reach stops at the repo. Real engineering work spans tickets, pull requests, CI, chat, documentation: the system around the code. **MCP** is the protocol Claude Code uses to connect to that system. Three words land together: **connector** (the wire into a work app), **action** (a verb with effect in the world), **tool** (the umbrella for anything the model can call). Full primer in [MCP and connectors](../trainings/agentic-engineering-101/reference/mcp-and-connectors.md).
- One connector, two actions (read + update), closes the loop you just ran on the bug, in the tracker your team actually lives in.

## Wire one connector into your tracker

- Pick the cleanest path for your tracker. Three work:
 1. **GitHub Issues:** check `gh auth status` in your session. Claude runs `gh` for you via Bash, no MCP install needed.
 2. **MCP connector to your tracker** (Linear, Jira, other): follow the install line in [MCP and connectors](../trainings/agentic-engineering-101/reference/mcp-and-connectors.md) for your tracker. If tenant admin approval is required, it's worth asking, not right now.
 3. **Manual paste:** Claude writes the close-out; you paste it into the tracker UI yourself. Five seconds, no tool setup.
- The teaching moment is the agent reaching across a tool boundary with a real engineering note, not the install choreography. For paths 1 or 2, get your connector up and running.

> **Connector added after this session started?** Check MCP status and authenticate with `/mcp`. If the new connector still isn't there, exit the session and resume it with `claude --resume <session-id>`.

> **Quick timebox note.** Second connectors and deeper MCP debugging can regress to install yak-shaving. One connector firing on one ticket is the proof the loop closes outside the repo. The rest can wait.

## Send the close-out note to the ticket

Ask Claude to read the ticket for your bug and report what's on it. Paste a ticket ID, a URL, or "create me a new one" if there isn't one.

{{prompt:compound-and-close-2}}

Claude reads the ticket (or confirms there isn't one). Then ask Claude to write the close-out (root cause, how you fixed it, a link to the PR), update the ticket, and report what it wrote.

{{prompt:compound-and-close-3}}

## Read the close-out and ship it

- Read the close-out; push back if it's stiff or wrong. Tell Claude how your team actually writes ticket comments. It'll adjust.
- Ship the update (or paste it into the tracker yourself on path 3, manual paste). The bug fix is now visible where it should be: in the tracker your team reads, not only in the repo.

## What happened

The move outside the repo happened on a real job: the ticket for the bug you shipped in Module 1. Claude read the ticket, wrote the close-out, and the note landed in the tracker where your team reads it. The loop that started with a failing test closed where the work is actually visible.

