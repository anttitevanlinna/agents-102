---
key: a101-prework-snake-game
dest: Claude Code
runtime: any
---
Build me a snake game as a single HTML file. Save it as `prework/snake.html`.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min

End your reply with [Open and play your snake game, then continue Prework](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#4-build-a-snake-game-10-min). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.
