---
key: close-the-ticket-1
dest: Claude Code
runtime: any
---
Read the ticket for the bug we just fixed. Tell me what it says: reporter, description, any comments.

If you can't find it, search the tracker by keywords from the bug; if there still isn't one, say so and we'll create one. If you find it but can't open it, ask me to paste the fields rather than reading anything off the URL.

Ticket:
