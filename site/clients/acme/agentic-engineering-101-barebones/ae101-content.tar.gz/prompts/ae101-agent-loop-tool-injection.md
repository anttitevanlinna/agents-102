---
key: ae101-agent-loop-tool-injection
dest: Claude Code
runtime: any
---
Explain how you know what tools you can call in this session.

Then explain how MCP-connector tools get injected into the same set.

Last, tell me whether any of them are deferred until you need them, and what that means for the list you gave me earlier.
