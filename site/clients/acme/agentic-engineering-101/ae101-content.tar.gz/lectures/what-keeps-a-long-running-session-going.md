# What keeps a long-running session going?

The session is working. Watch what already helps it continue, and where it still waits for you.

## Durable state keeps the place

- A long-running session needs a place it can recover its position from. The live context moves and eventually fills; files on disk survive.
- Your rules, observations, task coordinates, current files, and transcript are the durable state this session has today. They do different jobs, but they all outlast a turn in the conversation.
- Durable state needs a home and an owner. A file that loads everywhere and belongs to nobody is not memory the system can trust.

## Feedback keeps the direction

- The session can produce changes faster than you can judge them. Every unread diff joins a queue downstream of the agent.
- Flow engineering calls the push from a slower downstream stage **backpressure**: slow down, stop, or redirect when the next stage cannot safely accept more.
- During the handoff, feedback has to come from the system itself. You judge the result when you return.

## A boundary decides whether to continue

- Some boundaries already stand without you: tests, types, lint, permission limits, and explicit stop or ask conditions. Each can catch a problem and send the work back for correction before later steps build on it.
- The question is not how many checks the repo has. It is what notices first when this particular session goes wrong.
- Watch what catches problems, where the session waits for you, and where nothing pushes back. That is part of the result you bring back.

