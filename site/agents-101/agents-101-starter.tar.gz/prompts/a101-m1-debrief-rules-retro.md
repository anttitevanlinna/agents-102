---
key: a101-m1-debrief-rules-retro
dest: Claude Code
runtime: any
---
Run a retro on `module-1/personal-brand-generation.md`. Hold it against what we did building the site and against `module-1/context-trace.md`. Which moves worked, which fell flat, where did my context break through, where did the output stay generic? Sort each rule into keep, sharpen or drop. Name what the rules missed.

Assume the rules file is at least 30% wrong or thin. Find that 30%.

Then overwrite `module-1/personal-brand-generation.md` with the retro applied. Rewrite the file in place; don't append retro notes.

When you're done, list what you dropped and why, what you sharpened (before and after), what you added and why the session needed it, and what you want me to decide.
