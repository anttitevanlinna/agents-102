# What just happened

**Time:** 8 minutes.

Think back an hour. *Context* was a word someone might put on a slide. You had a vague sense it mattered. Now it's something you can point at — the bit you added that turned a generic About page into a site your neighbour recognised as yours. You felt it move.

That's a small thing. It's also the whole thing.

The rest of the training is seven more instances of the same move. Sit down, build, notice what shifted, adjust, build again. You just did a round of it; you'll do a lot more.

Two beats worth naming, because the mechanism you just used is older than AI.

**You act on the future to know what's real.** Nobody knows where agents are going. Not Anthropic, not your board, not the people running this training. What's known: the people who'll figure it out first are the ones sitting down and running the experiment. Reading a McKinsey report on the agentic enterprise is not the same category of activity as what you just did. One produces opinions about a future. The other produces scar tissue from it. Guess which one transfers.

**Mental models only come from doing.** Before today, you had a vocabulary. Now you have a little piece of felt experience. Those are different goods. A vocabulary is cheap; a felt model is the thing a leader uses to make a decision at 4pm on a Tuesday when the next reorganisation is being argued about. Nobody can give you a felt model. You can only catch one by reaching for it.

Everything in the next seven modules is more of this. More reaching, more watching, more adjusting. Don't expect a lecture to replace the doing. There isn't one.

Now: five minutes with Claude. The debrief.

