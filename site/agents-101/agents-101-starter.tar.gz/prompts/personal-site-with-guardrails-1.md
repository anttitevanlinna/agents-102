---
key: personal-site-with-guardrails-1
dest: Claude Code
runtime: any
---
Build me a one-page personal site from my LinkedIn profile below. Save it as `module-1/site.html` and keep a copy as `module-1/first-site.html`.

LinkedIn:
