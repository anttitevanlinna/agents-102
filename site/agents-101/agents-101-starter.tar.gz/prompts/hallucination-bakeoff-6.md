---
key: hallucination-bakeoff-6
dest: Claude Code
runtime: any
---
Tell me about precision and recall.

Use the scoreboard at `module-5/scoreboard.md` for the examples and point at specific rows from my run. End with one line on which one matters more for catching fabrication, and why.
