# Diagnose and *package*

**Time:** 53 minutes.

**Session** *(new, "Module 5 worktree session")*

In the worktree at `../<repo-name>-m5` (set up at module open).

```
/rename m5-diagnose-resend
```

**HOX** You should be in the worktree now. Make sure you are not continuing in the original repo or on its branch.

**What you do:** read the un-packaged run through three failure-mode lenses, then build a verifier against your worst one.

**What you build:** a verifier, a reference, and a plan.md, each built against a failure you actually read.

**The point:** packaging you built against your own failure beats packaging you guessed at.

---

## Phase 1: Read what the un-packaged run did

*10 min*

- You're diagnosing, not fixing. The un-packaged run was supposed to underdeliver. What came back is data, not blame.
- Two places hold the story. The repo's git history (commits on the `m4/<slug>` branch, files modified, branch state, all visible from the worktree) tells you *what* the agent did. That run's session transcript, at the path recorded in `task.md`, tells you *how* it got there, drift and dead-ends included.
- You hold the three lenses. You are not holding the codebase. The agent reads that for you.

Ask Claude to read the recorded transcript path from `task.md`.

{{prompt:diagnose-and-resend-1}}


Confirm the path is right. Then ask Claude to read the repo state on the previous-run branch and the transcript, and walk the work through three failure-mode lenses with quoted moments.

{{prompt:diagnose-and-resend-2}}


## Make Claude show its work, make it dig

- Push back where Claude generalises. If a lens comes back without a quote from the run, send it back for one. The same moment may carry more than one lens.
- This is an agent's account of an agent's work, on a run you weren't watching. Same prior as the repo read in Module 1: assume about 10% of the account misrepresents the run, and you can't spot which tenth by eye. Ask Claude to show you where two or three of its quotes appear in the transcript. If it can't show you, don't trust that quote.

## Phase 2: Match each failure to the check that catches it

*10 min*

- For each named failure, ask: *what validation would have caught this in minutes, not hours?*
- Match the verifier shape to the failure. Drift and context rot fire mid-run, on every spec re-read or window fill, so minute cadence is real there. Plausible-but-wrong fires on output: the work compiles, passes lint, looks right, and is wrong.

Ask Claude to walk each diagnosed failure backwards into the validation that would have caught it.

{{prompt:diagnose-and-resend-3}}


Claude gives the full three-way mapping. Your decision is narrower: which failure cost most, and why the other two pieces belong. Once two or three quoted moments make that clear, leave the rest at summary depth.
## Phase 3: Build the verifier for your worst failure

*20 min*

- Pick the verifier shape that matches the failure that cost you most.

- **LLM judge.** Separate Claude session reads the produced work and judges it: an opinion, not a pass-fail script. Right when the failure was qualitative (style, fit, "did it answer the question").
- **Deterministic shell-hook.** Tests, lint, type-check, compile, custom invariant. Right when the failure has a true-false answer (broke the build, touched the wrong directory). The shell-hook shape IS a Claude Code stop-hook; you will meet the word again if you extend the verifier to fire automatically between runs.
- **Ralph re-feed.** Loop the prompt with a check baked in; the agent re-runs on top of the previous round's output until the check passes. Right when drift was the dominant failure and re-anchoring catches it.

Drop the shape name after the colon, one of: judge, shell-hook, Ralph re-feed.

{{prompt:diagnose-and-resend-4}}


Read what Claude proposes. Push back if the verifier covers the wrong shape (a generic test suite when you needed a judge, or the reverse). The fit between failure shape and verifier shape is what you are after. When the shape fits the failure, say *save it.*

## Prove the verifier actually fires

- A built-but-untested verifier is no verifier. The wiring (hook config, file paths, slash-command registration, loop trigger) is fragile, and silent failures cost the next phase. Fire it once before Phase 4.

{{prompt:diagnose-and-resend-5}}

## The reference and plan.md

- **Reference**, what the task is and what done looks like: success criteria, plus pointers to the memory, skills and connectors that matter.
- Written once, before the run, and it stays put while the agent works.
- **plan.md**, the agent's working document: the steps, and where it has got to.
- The agent rewrites it as it goes and re-reads it when the context window fills. Not the plan-mode plan.

## Phase 4: Write the reference and plan.md

*10 min*

Ask Claude to assemble both, scoped to the same task, in conversation.

{{prompt:diagnose-and-resend-6}}

> **Cut the grill when the package is good enough to re-send.** The prompt keeps looking because that is its job. Your threshold is practical: scope, success criteria, constraints, tests, and done are clear enough for the second session. Then say *lock it in.* Until then, neither file should change; push back if the agent rewrites between turns.

> **Timebox check.** Two or three rounds fit the slot. If the grill is still finding questions when your time is up, take the recommended answers for the rest, say *lock it in*, and move to Phase 5.

## Approve

Say *lock it in.* The agent writes both files.

## Phase 5: Re-send it, packaged

*3 min*

Now the re-send. Same task, packaged this time, and notice the prompt: it shrank while the task stayed the same. The packaging does the explaining; the prompt invokes it.

**Session** *(new, "M5 long-run")*

In the worktree at `../<repo-name>-m5`. The packaging files live on disk; the worktree's auto-loaded rules (`CLAUDE.md`, `CLAUDE.local.md`) load fresh into the new session. The exercise session can stay open if you want to glance back at the assembly conversation.

```
/rename m5-long-run
```

Fresh context matters here. The exercise session built heavy scrollback (verifier scaffolding, hooks, plan.md drafts); every re-send turn would otherwise pay cache-read on that prefix. A fresh session avoids repeatedly carrying the heaviest context, and the field has a name for this move (Ralph's fresh-sessions camp, Amp's manual-handoff camp; see [What packaging is](lectures/what-packaging-is.md)).

Prefer to stay in the exercise session? Paste this to drop scrollback in-place:

{{prompt:ae101-m5-clear-before-rerun}}

## Send it off

Either way, the re-send prompt below stands alone: Claude finds the packaging in the worktree and reads it cold.

Ask Claude to re-run the same task using the reference, plan.md, and verifier you just built.

{{prompt:ae101-m5-rerun-packaged}}

The walk-away report at the close is what Module 6 opens on. Expect partial failures framed as partial successes, *"shipped most of it, hit a snag on X."* RLHF is a big part of why: agreeable answers won the preference round. The contrast with the un-packaged session depends on this report being candid evidence, not encouragement. If the summary reads polished, ask the agent to list the artifacts that didn't ship and quote the verifier output verbatim where it fired. You decide whether to push.

The laptop stays awake and plugged in while it runs (power settings → prevent sleep on power). Same cancel-is-legit rule as the un-packaged session: stopping when the trace is enough is the result. Manual nudges are part of the session; when nudging turns into typing every step, the agent isn't the agent any more, that's a result worth reading.



