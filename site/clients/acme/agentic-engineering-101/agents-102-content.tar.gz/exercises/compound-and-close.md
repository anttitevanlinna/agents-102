# Compound and close

**What you do:** let Claude review the whole session and write your `./CLAUDE.local.md` from session evidence. Wire one MCP connector. Close the bug's ticket outside the repo.

**What happened:** your rules file is born from how you actually worked, not from a template. The first move outside the repo happens on a real job: the ticket for the bug you just shipped.

**The point:** the compound step (plan → work → review → compound, Kieran Klaassen's loop) doesn't interview you with three retro questions. The session is the evidence; Claude reviews it and writes. You push back where it misread. Then Claude updates the bug's status in the tracker.

**Time:** 30 minutes.

The PR shipped. Now compound the session, then make the first move outside the repo.

## Compound

**Prompt** *(Claude Code)*

```
Review this session end-to-end: the orientation and introspection, the /context read, the TDD bug fix, the diff push-back. Write ./CLAUDE.local.md at the root of this repo (create it if it doesn't exist; add it to .gitignore if it's not already; if the file already exists, integrate, don't append). This is my personal gitignored rules file, not the team ./CLAUDE.md. Add rules that came from how we actually worked, not rules that sound good. Name the shape of the loop we ran and cite the practitioner who wrote it up if one fits.

If any rule is team-worthy (one every engineer on this codebase should know) flag it in the summary below, don't PR it. I'll decide whether to open a separate PR against team ./CLAUDE.md.

Tell me in 3–5 lines: what you wrote and why, grounded in specific session moments. I shouldn't need to open the file to know.
```


Read Claude's summary. Push back where it misreads. Quote the moment. That push-back is the reflection move. The rules file is yours, born from the session, extended by every module after this one.

> **Quick timebox note.** Second connectors and deeper MCP debugging both regress to install yak-shaving. One connector firing on one ticket is the proof the loop closes outside the repo. The rest is homework.

## MCP: why your agent needs to reach outside the repo

Up to this point, your agent's reach stops at the repo. Real engineering work spans tickets, pull requests, CI, chat, documentation: the system around the code. **MCP** is the protocol Claude Code uses to connect to that system. Three words that land together: **connector** (the wire into a work app), **action** (a verb with effect in the world), **tool** (the umbrella for anything the model can call). Full primer in [MCP and connectors](reference/mcp-and-connectors.md).

One connector, two actions (read + update), is enough to close the loop you just ran on the bug in the tracker your team actually lives in.

## Close the ticket

Ask Claude to write the close-out note: what the root cause was, how you fixed it, a link to the PR. Then pick how the close-out lands. Three paths, pick whichever is cleanest for your tracker:

1. **GitHub Issues:** in your session, check `gh auth status`. Claude runs `gh` for you via Bash, no MCP install needed.
2. **MCP connector to your tracker** (Linear, Jira, other): follow the install line in [MCP and connectors](reference/mcp-and-connectors.md) for your tracker. If tenant admin approval is required, it's worth asking, not today.
3. **Manual paste:** Claude writes the close-out; you paste it into the tracker UI yourself. Five seconds, no tool setup.

The teaching moment is the agent reaching across a tool boundary with a real engineering note, not the install choreography.

If you have a live connector (1 or 2):

Ask Claude to read the ticket for your bug and report what's on it.

**Prompt** *(Claude Code)*

```
Read the ticket for the bug we just fixed. Tell me what it says: reporter, description, any comments. If you can't find it, search the tracker by keywords from the bug; if there still isn't one, say so and we'll create one.

Ticket:
```


Claude reads the ticket (or confirms there isn't one). Then:

Ask Claude to update the ticket and report what it wrote.

**Prompt** *(Claude Code)*

```
Update the ticket: short close-out note naming what the root cause was and how we fixed it, link to the PR you opened earlier. If we needed to create the ticket just now, create it first, then update. Tell me what you wrote.
```


Read the close-out. If Claude wrote something stiff or wrong, push back. Tell it how your team actually writes ticket comments. It'll adjust.

Ship the update (or paste it into the tracker yourself if you're on path 3). The bug fix is now visible where it should be: in the tracker your team reads, not only in the repo.

You're near the end of the M1 session. One more sweep on `./CLAUDE.local.md` before close: anything earned since the first compound — the ticket beat, the push-backs, the catch on the missing PR — that didn't land yet?

Ask Claude to sweep the session for anything earned since the first compound and integrate.

**Prompt** *(Claude Code)*

```
We're preparing to close this session. Anything more to learn and compound into ./CLAUDE.local.md since the first compound — refusals, push-backs, sequence catches, anything that earned a rule? Integrate into the existing file, don't append. Tell me in 2–3 lines what you added, or "nothing new" if nothing did.
```

The loop ran. The PR is open, the rules file was born from session evidence, the ticket is updated where your team reads it. Setup in place.

You can now clear. What you stored may or may not help you in future sessions. Let's find out then.

