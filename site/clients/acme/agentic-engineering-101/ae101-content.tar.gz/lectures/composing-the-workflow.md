# Composing the workflow

## You drew a control loop

{{figure:student-closed-loop}}

## Eval

- An **eval** is a measurement. You hold agent-produced work against a fixed yardstick, across enough runs to get a number: a pass rate, a score, how often one drift shape shows up. One run tells you what happened. The measurement tells you what the system does.
- The yardstick stays put and the system learns against it. Add a rule, cut a rule, sharpen a check, and the number moves or it does not. That is how you know a change to the system was a change for the better.
- The checks you built are the instruments inside it. *Verifier* when deterministic: tests, lint, a hook that returns true or false. *Judge* when an LLM reads the work. *Gate* when the same check sits in CI and blocks the merge.

## The second loop

{{figure:double-loop-m6}}

## Dino Repo's skill stack

{{figure:dino-skill-stack}}

## Pocock's skill system

{{figure:pocock-skill-system}}

## The checking loop, drawn solid
<!--tier:2-->

{{figure:map-engine-filled}}

## Loop instead of you starting
<!--tier:3-->

- A kit skill can run on a schedule. Claude Code ships three ways to do it: local routines (from the Routines sidebar) for standing work on your laptop, `/loop` for in-session repetition, `/schedule` for cloud-backed remote Routines. The pattern is the same across all three: a skill from your kit is the thing the scheduled agent invokes.
- Left running, the loop squashes the recurring things. Add what each run taught to the kit, and the same loop starts cracking harder work.

## A skill's footprint is where its job lands
<!--tier:3-->

{{figure:skill-sea-passage}}

- A **skill** is a named move you reach for. Single purpose, reusable, invoked by name.
- One move takes a single fix at a turning point. Another carries a whole leg. A third runs at the pier, before the first leg. You never size a skill in advance. The job sizes it.

## From skills to a workflow
<!--tier:3-->

- The field wires kits more ways than one; no way has won. Pocock ships a public kit with no orchestrator: you call each skill by hand. Klaassen ships one slash command per stage, and the last one writes the lesson to disk for the next agent. Some workflows have a pilot; many do not.
- A **workflow** is skills composed around one task.
- Each skill carries the best instructions for its one step, and nothing else's.
- Which skills are in, and in what order, is composed per task and recomposed when the task changes.
- Your job moves from reading every intermediate output to choosing the skills, their order, and the instructions each one carries.

