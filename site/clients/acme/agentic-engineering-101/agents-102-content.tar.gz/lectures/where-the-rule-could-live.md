# Where the rule could live

You have a `.md` file with three to five rules about how multi-file tasks want to be factored on your codebase. Three shapes for what happens to a file like this in practice. Each is real; each is downstream of where you are today.

## Slack-triage shape

A request lands in a Slack thread. Typically, either `@Claude` routes it into Claude Code on the web, or a Slack app listens for the message and passes it to an agent runtime. The agent reads the thread plus your `.md` file, then replies with the suggested slice or next question: *this is a one-liner, ship it from main; this is a feature slice, here's how it splits; this is an epic, here are the three shippable pieces.*

The `.md` file is the steady part. The agent is the moving part. The triage gets sharper because the file gets sharper, not because the agent gets bigger.

## Issue-webhook shape

A teammate opens, edits, or labels a GitHub issue. Typically, a GitHub Actions workflow or GitHub App picks it up. The usual go-to agents in GitHub are Claude Code through its GitHub app and GitHub Copilot. The agent reads the issue against your `.md` file, proposes labels, asks for missing info, or splits it into shippable sub-issues. Your `.md` file decides what counts as shippable.

The `.md` file is the policy. The issue event is the trigger. You change the policy by editing the file; nothing else moves.

## Scheduled-read shape

Once a sprint, an agent reads your backlog top-to-bottom against the `.md` file and proposes a re-shape: which items want to merge, which want to split, which want to die. You arrive to a proposal, not a queue.

The `.md` file is the spec. The schedule is the cadence. A fixed spec the agent re-reads at run start so it can't drift mid-task.

Claude Code scheduled tasks are one natural runtime for this shape. You give the scheduled task the backlog source, the `.md` file, and the cadence. It returns a proposal you read before anything changes.

## What this means today

Three different shapes; one common piece. The `.md` file. Once you have it, you have a guardrail. From there, you choose the trigger and runtime that fit your team: Slack thread, issue event, sprint cadence; Claude Code on the web, GitHub Actions, a Slack app, a scheduled agent, or something else. The file travels.

If you reverse-engineered one ticket after the exercise, those field-use rules sit beside the same `.md` file. A backlog-refinement agent reads both: task-shaping rules for what counts as a good slice, field-use rules for how your team expresses work in the tracker.

Agents build agents. The agent that reads the `.md` file and splits a backlog can be built by another agent that reads a different `.md` file: yours about how *you* author skills, how *you* test them, how *you* ship them. M3 starts there. Today the file exists.

M3 starts with a feature you're shipping.

