---
key: personal-agent-homework-1
dest: Claude Code
runtime: any
---
Look at my company's website, or another site I name. I'll give you a URL or paste a key page when you ask. Extract the visual pattern: primary and accent colours (with hex codes), font families, header shape, spacing, overall tone of voice. Write it to ./style.md at the training-directory root, in plain language (not a CSS file). Short and practical: a designer reading ./style.md should be able to produce something that looks like our site without visiting it.

Then append one line to my root {{artifact:root-instructions}} under a new "Styling" heading: "When producing HTML output, follow style.md."

Show me both files before saving.
