# Sharpen the plan with *two reads*

**Time:** 57 minutes.

**What you do:** push back twice on your plan, run a second-pass grilling, then approve and **stop**.

**What you build:** paired reads on one plan: your two push-backs, then a walk-down three questions at a time.

**The point:** the first pass is plausible, and usually not good enough.

---

## Phase 1: Bring a real task

*5 min*

- Bring a task that spans a few files, with enough execution depth to make plan mode worth using. A feature slice, a small migration, a targeted refactor: something where touching the wrong file matters. **A one-line fix is too small for plan mode; a refactor whose outcome you can't hold in your head is too big.**
- If nothing fits, ask Claude to surface three candidates from recent issues, PRs, or TODO comments. Pick the one you'd ship today if you had an hour.

## Phase 2: Ask for the plan

*15 min*

- In plan mode, name the task, why it matters, and the one constraint you care about most.
- Plan mode explores the codebase and writes a plan; your job starts when it pauses for approval.

Drop your task after the colon.

{{prompt:push-back-on-the-plan-1}}

Plan mode takes minutes on real codebases. Eight to twelve isn't unusual. Use the wait to chat with colleagues about what you're building.

## Scan the plan before you push back

- A plan deserves more attention than ordinary agent output; not every line is equally important.
- Open the plan file (descriptive name, e.g. `migrate-auth-hash-calm-otter.md`); the chat summary is secondary. Scan it against the five things a good plan has, and start where a sharper answer would most change execution.
- Two push-backs forming in your head? Move on.

## Phase 3: Push back twice

*12 min*

- At the approval prompt, pick **No, keep planning**. Send two push-backs on two different axes: one soft item, and one of (assumption · alternative). Your own words, your own concerns.
- **Soft items:** the step that reads clean but skips over something. *"Update the config"* without which keys. The vagueness isn't a drafting slip; it's where the agent hasn't decided yet. Stuck picking one? Ask Claude which step it's least confident about. **The agent finds; you judge.**
- **Assumptions:** something the plan is carrying silently that it shouldn't. A library version, a schema shape, a teammate's recent change the agent hasn't seen.
- **Alternatives:** not just a flag; the change you'd make. Merge two steps that belong together. Reorder two steps whose sequence matters.

> **Two messages, then move on.** Two push-backs on two axes, plus one check that the regeneration held: read the flagged steps in the revised plan, not the agent's report of them, and if the vagueness survived, push back again on that line. A third push-back may be forming. That is fine; it is the second-pass read's job to catch the rest.

## Phase 4: Walk down the unresolved branches

*15 min*

- The second read runs in this same session and still in plan mode, working through the plan file differently from the way you did.
- The prompt asks Claude to walk every unresolved branch, three questions at a time, with a recommendation for each. Take the questions that sharpen the plan; you remain the stop gate.

{{prompt:push-back-on-the-plan-2}}

> **If it feels slow, ask why.** Stop the turn, ask Claude what's making it crawl, then relax that requirement. The prompt is a starting recipe, not a contract.

## Answer the branches that change what "done" means

- The second read asks three questions at a time. Some will feel trivial (*"which logger should step 2 use?"*); answer and move on. Some will reach into something you hadn't considered (*"step 4 touches the shared cache; what's the invalidation story?"*); pause, think, answer. A few will surface decisions the plan was silently making for you; reject the recommended answer and give a different one.

> **Too many low-level questions? Steer up.** If Claude keeps asking about implementation detail (which helper, a variable name, error-message wording), tell it: ask me about requirements, not low-level design. The branches worth the time change what 'done' means; the rest you'd settle in verification.

## Switch to a picker if you prefer one
<!--tier:3-->

- If you would rather answer from a structured picker, ask Claude to switch to AskUserQuestion once the walk-down is rolling, and add any steering of your own.

{{prompt:push-back-on-the-plan-2-askuserquestion}}

## Stop when the plan is good enough to generate

- The decisions most likely to change execution are settled, and the questions coming back now are routine implementation detail, settled ground, or genuine non-goals. The agent can keep walking; you decide when another answer is no longer worth the working memory it costs. Approve when the plan reads like your plan.

> **Timebox check.** If branches are still surfacing when your time is up, approve the sharpened plan as it stands and move to Phase 5.

## Run the original grill-me if you want the full hour
<!--tier:3-->

*Credit: Matt Pocock for the original [`grill-me`](https://github.com/mattpocock/skills/blob/62f43a1/skills/productivity/grill-me/SKILL.md) skill. The walk-down prompt is abbreviated to fit the 15-minute slot. The original is fully relentless and can run an hour. Optional:*

{{prompt:push-back-on-the-plan-2-original}}

## Approve

Say *lock it in.* The agent writes the sharpened plan. Approve at the prompt.

Then just hit stop.

## Phase 5: Stop, then surface the patterns

*10 min*

- Don't execute the plan. The work of making it good is the exercise.
- Approving took you out of plan mode, so this last step runs in default mode.
- Ask Claude what the second-pass read surfaced that your two push-backs didn't.

{{prompt:push-back-on-the-plan-3}}

## Compare what each read caught

- The agent answers. You catch what a human catches (specificity, voice-of-experience, "I'd write that differently"). The second read catches what an agent walking a decision tree catches: branches you didn't notice, dependencies you didn't name, side-effects you didn't price.
- Neither read needs to be complete. Paired, they surface the sharpenings worth making before generation.
- **Plan-mode approval inflation** is the thing this pairing defeats: structured plans get rubber-stamped because they look like decisions.

