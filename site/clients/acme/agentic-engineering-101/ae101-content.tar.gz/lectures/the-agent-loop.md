# The agent loop

## The agent, the harness, the loop

- An **agent** is an LLM that runs in a loop, calling tools to take action. Each iteration the LLM receives context (system prompt, conversation, tool results), decides on the next step, and either responds to you or calls a tool.
- The **agent harness** is the surrounding code that runs the loop. It exposes tool definitions to the LLM, executes the tool calls, and feeds results back in. Claude Code is one harness; Cursor, Cline, Gemini CLI are others.
- The **agent loop** is that iteration itself. Prompt → reason → tool call → result → reason again, until the agent decides to stop.
- A long run is this same loop, iterated. Nothing new takes over when the run gets long; the loop keeps choosing the next step from context and tool results, hour after hour.

## See the loop in your live session

Three prompts to make the loop concrete in your current session.

Ask Claude to draw the loop as an ASCII diagram.

{{prompt:ae101-agent-loop-ascii}}

Get the tool list this session is actually carrying.

{{prompt:ae101-agent-loop-tools-list}}

Surface where the tool list comes from, then how MCP-connector tools land in the same set.

{{prompt:ae101-agent-loop-tool-injection}}

> Feel free to dive deeper on any aspect.

