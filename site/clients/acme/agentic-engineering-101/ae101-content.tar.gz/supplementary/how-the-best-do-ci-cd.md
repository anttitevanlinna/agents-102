# How the best do CI/CD: six moves that sharpen the loop

*Supplementary for AE101 Module 6. Read after you've shipped your second skill.*

You finished M6 owning the loop at your desk. Two runs of the same task, gap diagnosis, a second skill in `~/.claude/skills/`, one rule cut from `./CLAUDE.local.md`. The same loop, run at more people, more PRs, more customers, looks slightly different. Six moves recur in the engineers running it best. Each one sharpens the loop you already own. None require permission from above to start trying.

## 1. Treat CI as feedback into the loop, not a gate to pass

The reflex frame for CI is *"a wall I must pass before merge."* That frame burns every red build. A failing CI run is signal. About which memory rule should have caught the mistake upstream. About which verifier was too soft. About which skill ran on auto-pilot when it should have paused. The best route that signal back into the loop the way you route gap diagnosis back into skills and memory. Each red build sharpens the next run.

**Klaassen at Every** named the loop. Each unit of engineering work should make the next one cheaper. The mechanism lives in the artifacts the next agent reads — rules files, skill files, `AGENTS.md` — and the discipline is feeding lessons from one task back into them before the next task starts ([Compound Engineering: The Definitive Guide](https://every.to/source-code/compound-engineering-the-definitive-guide)).

**Cursor's Bugbot** runs a similar mechanism at platform scale. Review comments flagged as useful become learned rules that promote and demote over time. Resolution rate climbed from 52% to around 80% as the rule corpus grew across 110,000 repos to 44,000 learned rules. Cursor's own numbers ([Bugbot now self-improves with learned rules](https://cursor.com/blog/bugbot-learning)).

**Try this Monday.** Next CI failure you hit on agent-drafted code, ask Claude *"what rule in `./CLAUDE.local.md` would have caught this?"* before you fix the diff. If the answer is *none*, write the rule.

## 2. Fan out review; converge on the pattern

A single reviewer reading 30 agent-drafted PRs a day skims. The best refuse the trade. They run specialist reviewer agents in parallel: one for security, one for performance, one for architecture, one for style. Each finding spawns its own fix-agent. The human's job shifts. Read the pattern across findings, not the lines.

**Cloudflare engineering** runs seven specialist reviewers in CI through their internal stack, with a coordinator agent producing one structured review. The named specialties: security, performance, code quality, documentation, release management, AGENTS.md compliance, internal compliance. 131,246 review runs across 48,095 merge requests in 5,169 repos over 30 days. Median review time 3m39s. Human break-glass override fires on 0.6% of reviews. Cloudflare's own numbers ([Code review with our internal AI engineering stack](https://blog.cloudflare.com/ai-code-review/)).

The pattern named in their own write-up: specialized agents beat monolithic prompting because each agent has a narrow job and the coordinator deduplicates.

**Try this Monday.** On your next non-trivial PR, ask Claude to review it four times under four hats: *"as the security reviewer, what would you flag? as the perf reviewer? architecture? style?"* Read the four outputs side by side. Notice which hat caught what. That's a panel.

## 3. Tier by blast radius. Make the Tier-1 case on your own PRs

The naive answer is *"add more reviewers."* The best answer is *"not all PRs deserve the same gate."* A CSS tweak and an auth change want different review surfaces. Tiered gating sorts PRs by what could go wrong, not by who wrote them. Once the lowest-risk tier is clean enough that agent-drafted, verifier-green changes ride through with no human reading, the median cycle time falls for the whole team.

**Intercom** routes 19.2% of merges through a Tier-1 auto-approve path. Median cycle time on that path is 14.6 minutes against an org median of 75.8 minutes. 86% of those PRs are 20 lines or fewer. Intercom's own numbers ([Curran, *2x — nine months later*](https://ideas.fin.ai/p/2x-nine-months-later)).

**Stripe** is a different point on the same spectrum. Over 1,000 agent-produced PRs merge each week, all human-reviewed, none with human-written code. Stripe contains blast radius by running each agent in an isolated devbox instead of auto-merging the lowest-risk slice. Humans gate on what the agent did; the sandbox gates on what the agent could do ([Gray, *Minions: Stripe's one-shot, end-to-end coding agents*](https://stripe.dev/blog/minions-stripes-one-shot-end-to-end-coding-agents)).

Two different orgs, two different bets on where to put the human and where to put the silicon. The IC version of this — one engineer carving out their own auto-mergeable slice with a verifier they built — hasn't been published yet. That's a gap you can close on Monday.

**Try this Monday.** Pick one slice of your repo that's mostly safe (feature-flag toggles, copy changes, narrow refactors). Ask Claude *"what verifier would I need before this slice could auto-merge?"* Build that verifier. Run the slice through it. Show the cycle-time number to your tech lead.

## 4. Eval latency is part of the loop

A 15-minute CI run feels fine when a human steps away for coffee. When the agent is waiting, 15 minutes is idle compute plus context loss plus a forced switch to another task. The best treat eval latency as a direct tax on what their kit can do for them. They split fast lane from slow lane. Cheap deterministic checks run in seconds and verify the agent's next move. Judges and gates run in minutes, in the background, on the merged change.

**Husain** codifies the split as guardrails versus evaluators. Guardrails sit inline in the request/response path: fast, deterministic, milliseconds of latency budget, block the response. Evaluators run async or in batch: heavier compute, often LLM-as-judge, run after the agent has moved on. You almost never use a slow LLM-as-judge as a synchronous guardrail ([Evals FAQ — Guardrails vs Evaluators](https://hamel.dev/blog/posts/evals-faq/whats-the-difference-between-guardrails-evaluators.html), Aug 2025).

**Cherny on Claude Code** pairs a deterministic Stop hook with a background verifying agent — the fast check blocks the next move, the slow check runs after. He calls the verify-your-work move the one that 2-3x's the quality of the final result ([Anup Jadhav on Cherny, *35 Claude Code Tips From the Guy Who Built It*](https://www.anup.io/35-claude-code-tips-from-the-guy-who-built-it/)).

**Try this Monday.** Time your slowest CI step. If the agent has to wait on it before its next move, ask Claude *"which 20% of these checks catches 80% of the regressions, and how do I run only those on PR-open?"*

## 5. Skills don't just live in your kit. Promote them into the CI surface

The naive view of a skill: a helpful prompt you might invoke. The sharper view: a verifier-in-waiting. Each skill you author catches a pattern. That pattern is what your next PR's review (or your CI check, or your pre-commit hook, or the next plan agent reading rules) needs to see. The best engineers don't keep skills isolated in `~/.claude/skills/`. They promote them into AGENTS.md, into rules files committed back to the repo, into pre-commit hooks. Author once, fires on every next PR.

**Shapira at Elementor** runs a CI workflow that grabs human review comments, hands them to a Cursor CLI agent, extracts patterns, and commits the rules file back to master. Every merged PR sharpens the next review against the same rules ([The Self-Learning Code Review](https://medium.com/elementor-engineers/the-self-learning-code-review-teaching-ai-cursor-to-learn-from-human-feedback-454df64c98cc)).

**Larson at Imprint** consults the same shape of artifact at plan time. The agent reads AGENTS.md and the skills wiki *"by future iterations of the plan pattern"* — the skill catalogue becomes the loop's working memory ([Learning from Every's Compound Engineering](https://lethain.com/everyinc-compound-engineering/)).

**Charles runs Ramp's Dojo** as the team-scale version: 350+ shared skills, 99.5% of employees actively using AI, 84% on coding agents weekly. The marketplace pulls personal moves into shared standards. Charles's own numbers, from his April 2026 thread ([Peter Yang's *Inside Ramp* interview](https://creatoreconomy.so/p/inside-ramp-the-32b-company-ai-agents-geoff-charles) is the readable write-up).

**Try this Monday.** Look at your `~/.claude/skills/`. Find a skill that catches something your CI doesn't. Propose it as a pre-commit rule or PR-review check in your repo. The path from personal skill to team-enforced check is shorter than it looks.

## 6. Get out fast. Learn from real customers safely

The loop doesn't stop at merge. Customer signal in production is the outermost feedback ring. The best invest in safe, fast deployment so customer reality feeds back into memory and skills the same way CI failures do. Feature flags, fast revert, observability dashboards, gradual rollouts. These aren't infrastructure niceties. They're what makes the outer loop fast enough to learn from. Slow deploys with painful rollbacks force teams to gold-plate pre-merge. Fast deploys with cheap rollback let teams ship hot and correct from real signal.

The arrow most orgs get backwards: feel the speed, panic, invest in more pre-merge gates. Slower pipeline, no safer prod. The sweet pace is not *as fast as possible.* It's *fast enough that correction cost stays low.* Two conditions: reverts are trivial, observability catches bad merges in minutes. If both hold, you run hot.

**Majors at Honeycomb** names the agent-era stake plainly: *"How do you expect your agents to validate each change, if the consequences of each change cannot be found?"* Agentic work makes production observability more load-bearing, not less. Agents need fast, context-rich production signal to validate their own changes the same way you needed it to validate yours ([Your data is made powerful by context](https://charity.wtf/2026/03/09/your-data-is-made-powerful-by-context-so-stop-destroying-it-already-xpost/)).

**Wolff on the Claude Code team** named the operating principle bluntly at QCon: *"when the implementation cost goes to zero, the feedback loop becomes everything."* The team ships SQLite persistence behind a feature flag, watches the production signal turn bad, removes it within two weeks. Reversibility is the prerequisite for shipping fast, not the consolation prize for shipping wrong ([Engineering at AI Speed: Lessons from the First Agentically Accelerated Software Project](https://www.infoq.com/presentations/engineering-ai/)).

**Try this Monday.** Time how long it takes to revert a bad merge in your repo, end to end. If the number is more than 10 minutes, that's the problem worth surfacing to your team. The other five moves wait on this one.

## Where this fits in your AE101 arc

The loop at your desk is the one this training closed: spot the gap, build the eval, close the loop on your own code. This piece is the same loop, run by engineers who've been at it longer. The shift is not conceptual. The reader is still you. The shift is what each move makes possible once you stop treating CI, review, deploy, and customer signal as separate stages and start treating them as one loop with six tunable surfaces.

Pick one move. Run it this week.

## Sources

Practitioner-direct writings cited in this piece, in order of appearance:

- Kieran Klaassen, [*Compound Engineering: The Definitive Guide*](https://every.to/source-code/compound-engineering-the-definitive-guide) — naming the loop: each unit of engineering work should make the next one cheaper.
- Cursor, [*Bugbot now self-improves with learned rules*](https://cursor.com/blog/bugbot-learning) — promote/demote learned rules across 110,000 repos.
- Cloudflare engineering, [*Code review with our internal AI engineering stack*](https://blog.cloudflare.com/ai-code-review/) — seven specialist reviewers + coordinator, instrumented at scale.
- Darragh Curran, [*2x — nine months later*](https://ideas.fin.ai/p/2x-nine-months-later) — Intercom Tier 1/2/3 auto-merge with measured cycle-time deltas.
- Alistair Gray, [*Minions: Stripe's one-shot, end-to-end coding agents*](https://stripe.dev/blog/minions-stripes-one-shot-end-to-end-coding-agents) — over 1,000 agent-produced PRs per week, human-reviewed, isolated devboxes.
- Hamel Husain, [*Evals FAQ — Guardrails vs Evaluators*](https://hamel.dev/blog/posts/evals-faq/whats-the-difference-between-guardrails-evaluators.html) — fast-lane / slow-lane eval taxonomy.
- Anup Jadhav on Boris Cherny, [*35 Claude Code Tips From the Guy Who Built It*](https://www.anup.io/35-claude-code-tips-from-the-guy-who-built-it/) — deterministic Stop hook + background verifying agent, 2-3x quality move.
- Ofer Shapira, [*The Self-Learning Code Review*](https://medium.com/elementor-engineers/the-self-learning-code-review-teaching-ai-cursor-to-learn-from-human-feedback-454df64c98cc) — CI agent extracts patterns from review comments, commits rules file back to master.
- Will Larson, [*Learning from Every's Compound Engineering*](https://lethain.com/everyinc-compound-engineering/) — `AGENTS.md` and skills wiki consulted by the next plan iteration.
- Peter Yang on Geoff Charles, [*Inside Ramp: how a $32B company runs on AI agents*](https://creatoreconomy.so/p/inside-ramp-the-32b-company-ai-agents-geoff-charles) — 350+ shared skills, team-scale marketplace; 99.5% AI-active, 84% on coding agents weekly (numbers are Charles's own, from his April 2026 thread).
- Charity Majors, [*Your data is made powerful by context*](https://charity.wtf/2026/03/09/your-data-is-made-powerful-by-context-so-stop-destroying-it-already-xpost/) — agents need fast production observability to validate their own changes.
- Adam Wolff (QCon SF 2025), [*Engineering at AI Speed: Lessons from the First Agentically Accelerated Software Project*](https://www.infoq.com/presentations/engineering-ai/) — feature flag + reverse-by-moving-a-pointer; SQLite shipped and removed in two weeks.

