---
key: personal-agent-homework-3
dest: Agent workspace
runtime: any
---
Read module-2/morning-agent/morning.md and run the job. Read the current state of memory/ as context. Follow the rules in that file and in the root {{artifact:root-instructions}}. Write the output to module-2/morning-agent/latest.html.
