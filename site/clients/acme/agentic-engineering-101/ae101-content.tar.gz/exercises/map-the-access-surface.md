# Exercise: Map the access surface

**Time:** 20 minutes.

**Window:** the main quest window (*m3-security*).

**What you do:** Invoke the curated access-control analysis skill on the small feature you brought to Module 3. Read what the skill surfaces. Decide, on the record in your repo, which surface it called out harder than you would have, and which surface you know matters that the skill didn't catch. Ship the delta as notes the STRIDE exercise will consume next.

**The point:** STRIDE without an access-surface map is pub-quiz threat modeling. Before you threat-model, you map what you're protecting. The curated skill does the breadth; you own the codebase-specific judgment that the skill can't have.

---

## Phase 1: invoke the skill

The `access-control-analysis` skill was installed as a personal skill during prework, so Claude Code auto-discovers it by name in the m3-security session.

First, see what skills your Claude has loaded. In the Claude Code chat, type:

```
/skills
```

You should see `access-control-analysis` and `stride` listed under **User**. (If they're missing, check prework Step 4.) The Project list is whatever this repo ships; User is your personal skills. Skills you author later in Module 3 will land in User too.

Then ask Claude to fill in what `/skills` doesn't show.

{{prompt:map-the-access-surface-1}}

Worth a moment of looking, these are the moves Claude has on hand for the rest of this module, and the load-on-invoke behavior matters for context economy later.

Ask Claude to invoke the access-control-analysis skill on the feature you'll name after the colon, and save the surface map to a temp directory.

{{prompt:map-the-access-surface-2}}


Paste a plan path, a ticket link, a design-doc path, or the feature description, Claude reads whatever you give it. Then send. Claude will narrate what the skill is doing before the map appears; skip past the opening and look for the saved path when it lands. The skill walks the surfaces and produces the map. You watch.

## Phase 2: walk the map in conversation

Ask Claude to walk you through the surface map in chat (categories, key findings, ambiguous spots) so you've seen the structured read before deciding your deltas in Phase 3.

{{prompt:map-the-access-surface-3}}

## Phase 3: write the delta

Now you decide which surface goes on each side of the delta. Two reads:

- Where did the map flag something you'd have under-weighted? Lower-risk in your read, higher-risk in the skill's.
- What's missing that you know matters? Often the "weird bit" of your feature, the part you'd describe as not-quite-standard.

If neither is obvious from a quick scan, ask Claude in chat to propose two or three candidates per side with a one-line reason each. Pick from those, push back if the reasons read generic.

Ask Claude to integrate the surface the skill called out harder than you would have into the map.

{{prompt:map-the-access-surface-4}}

Then ask Claude to add the surface the skill missed but you know matters.

{{prompt:map-the-access-surface-5}}


Answer. Push back on the sharpening question until the reason names something specific to your codebase. *"The billing webhook re-hits the queue on retry, so the same event gets reprocessed"* beats *"webhooks need auth."*

## Phase 4: handoff check

You're about to hand this map to the STRIDE skill. Glance at it. If a teammate landing on this file cold would miss something the map assumes you know, add a one-line context header. If it reads, close.

Most people skip this. Some want the pause. Your call.

---

**What happened:** You ended with a short delta-note in your repo: the surfaces the skill called out harder than you would have, and the surfaces you knew mattered that the skill didn't catch. The delta is the artifact, not the raw skill output.

## What this sets up

The STRIDE exercise invokes the curated STRIDE skill on the map you just built. The surface map IS the input. If you rushed Phase 2, STRIDE will threat-model a thin map; if you sat with it, STRIDE has something real to chew on.

