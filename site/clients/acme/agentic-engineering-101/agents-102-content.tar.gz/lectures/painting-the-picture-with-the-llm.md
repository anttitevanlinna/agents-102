# Painting the picture with the LLM

Three things about the tool you just used.

## The wizard is dead

The wizard typing in neat Perl syntax is dead. Auto-complete was a thing. Auto-complete is no longer a thing. A part of high-end engineering skill has been taken on by the LLM.

## The LLM is an infinite chameleon

The LLM can do good work and bad work. It will be what fits the session. It flatters. It progresses. It mirrors your stance.

Seth Godin has been making the same argument about tools for decades: the tool is not the thing. The taste behind the tool is the thing. The LLM is the infinite version of that argument. Whatever stance walks into the session, the LLM bends toward.

That is the design, not a flaw. What walks in sets the ceiling.

## You prime, the LLM scales

The stance and the approach matter more now, not less. The session bends to what sits in the context window. You prime it. The LLM scales it.

The rules file. The prompt. What sits on disk for the agent to read. Whatever you put in front of the LLM is what the LLM scales.

If you want a shotgun, you have a shotgun. If you want a cannon, you have that too. The smart ones stay smart.

## Two frontiers

Two questions out in front. Neither has a settled answer.

How can a system like this learn faster than a human practitioner can write things down?

And once it can learn fast, how does it learn the right things, and not just any things?

Let's go.

