# Where the rule could live

You have a `.md` file with three to five rules about how multi-file tasks want to be factored on your codebase. Three shapes for what happens to a file like this in real use.

## Three shapes for the file

- **Slack triage.** A request lands in a thread; `@Claude` routes it into Claude Code on the web, or a Slack app hands the thread to an agent runtime. The agent reads the thread plus your `.md` file and replies with the suggested slice or the next question: this is a one-liner, this is a feature slice and here is how it splits, this is an epic in three shippable pieces.
- **Issue webhook.** A teammate opens, edits, or labels a GitHub issue; a GitHub Actions workflow or GitHub App picks it up. The agent reads the issue against your `.md` file, proposes labels, asks for missing info, or splits it into shippable sub-issues. Your file decides what counts as shippable.
- **Scheduled read.** Once a sprint, a scheduled agent reads the backlog top-to-bottom against the `.md` file and proposes a re-shape: which items want to merge, which want to split, which want to die. You arrive to a proposal, not a queue.

## The file is steady; the agent moves

- **The `.md` file is the steady part; the agent is the moving part.** In all three shapes, the triage gets sharper because the file gets sharper, not because the agent gets bigger. Improvement invested in the durable artifact carries; the agent under it can be swapped without losing a thing.
- **The file travels.** Slack thread, issue event, sprint cadence; Claude Code on the web, GitHub Actions, a scheduled agent. Trigger and runtime are wiring choices; the file rides along unchanged. Once it exists, you have the guardrail, and every shape above is a deployment decision, not a rewrite.
- **Agents build agents.** The agent that reads your `.md` file and splits a backlog can itself be built by another agent reading a different `.md` file: yours about how *you* author skills, how *you* test them, how *you* ship them. Today the file exists.

