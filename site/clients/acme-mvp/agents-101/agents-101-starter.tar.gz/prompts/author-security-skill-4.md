---
key: author-security-skill-4
dest: Claude Code
runtime: code
---
Install the authored skill at module-4/skills/agent-audit/ as a project skill at {{artifact:project-skills}}/agent-audit/. Confirm the installed path so I can verify it.
