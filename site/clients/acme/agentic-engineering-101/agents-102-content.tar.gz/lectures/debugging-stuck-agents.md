# Debugging Stuck Agents

Agents get stuck. They use the wrong source. They average three views into mush. They write the file you asked for, but not the one the next agent needed. They sound confident right before the handoff fails.

Do not start by tracing everything by hand.

Start by prompting the system to find the root cause.

{{prompt:debugging-stuck-agents-1}}

This is rather long. Make your own variant. The important move is not the wording; it is asking Claude to diagnose whether the bug lives in the sources, the processing, or the boundary before you start fixing things.

Then use the answer.

1. **If it is the sources, fix the sources.** Add the missing file. Remove the stale one. Split contradictory material so the agent can see the conflict instead of smoothing it. Do not write a cleverer prompt to compensate for bad ground.

2. **If it is the processing, fix the processing.** Rewrite the prompt, the role, the handoff, or the output shape. If one agent was doing two jobs, split it. If three agents were pretending to be different, collapse them.

3. **If it is the boundary, fix the boundary.** Narrow the agent's job. Remove the tool. Add a human gate. Move the risky step from "do" to "propose."

4. **Shrink the rerun.** Do not rerun the whole system first. Rerun the smallest step that should now behave differently: one retriever, one stance, one synthesis, one file.

5. **Write down the lesson.** If the same failure could happen again, add a rule to `./CLAUDE.md`: what to read first, what not to smooth over, what file shape the next agent must produce, or when to stop and ask.

Start with diagnosis before repair. That's the habit.

The agent is part of the debugging loop too.

