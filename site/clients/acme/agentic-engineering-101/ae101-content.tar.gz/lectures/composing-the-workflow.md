# Composing the workflow


---

By now you've shipped enough on your own that the next question stops being one a prompt can answer for you. You have a kit: a test-strategy skill, a verifier, a second skill. How practitioners compose kits like this into workflows is a conversation the field is having right now. Not one converged shape. At least five live lineages, each disagreeing with the others on load-bearing details, plus a strong counter-voice arguing composition is mostly throttling. There is no prompt to drill at this point. The move is to read.

Klaassen wires composition by file paths between subagents, with hard gates at every seam. Cherny runs specialised subagents in parallel across worktrees. Pocock keeps the toolkit weakly coupled and lets the human pick the chain at runtime. Cognition argues for a single writer surrounded by advisor agents that contribute intelligence, not actions. Amp ships composition primitives like `/handoff` as vendor-shipped built-ins. Ronacher, the counter-voice, argues composition is mostly throttling, not multiplication, and keeps his own skills disposable. These lineages disagree about what *subagent* even means, where memory closes, and whether the human should be doing the chaining or the chain should be doing the human.

The reading walks each lineage with what's distinctive, the canonical URL, and where a practitioner running that lineage actually starts. Two or three practitioners is enough to track. Pick across the lineages whose shape resembles your day. The conversation will keep moving. The slower-moving signal is the shape of work each lineage handles.

This is one level higher in abstraction and composition. Compound engineering already ships as a plugin you can install. Your Claude Code can build the kit you need once it finds the right thread to pull. Choice in the world is approaching infinite. This is one of those places that calls for intuition and taste. Your intuition.

[Workflow composition lineages](trainings/agentic-engineering-101/supplementary/workflow-composition-lineages.md)

