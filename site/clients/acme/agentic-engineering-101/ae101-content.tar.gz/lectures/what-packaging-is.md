# What packaging is

The packaged re-send is running and the laptop is closed again. What you assembled to get there has names.

## One session, plotted

One long session, drawn as a sea passage.

<figure class="diagram">
<svg viewBox="0 0 1200 560" role="img" aria-label="One agent session plotted as a sea passage: drift cones widen between position fixes and collapse at each fix; guardrails fence the reef; an unchecked twin session drifts across the no-go line into the rocks and arrives at the wrong harbor." style="display:block;width:100%;height:auto;background:#efe6d2;border:1px solid #c5b68d;border-radius:7px;">
<defs>
 <pattern id="ps-reefhatch" width="7" height="7" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
 <line x1="0" y1="0" x2="0" y2="7" stroke="#a05a2c" stroke-width="1" opacity="0.45"/>
 </pattern>
</defs>
<rect x="0.5" y="0.5" width="1199" height="559" rx="7" fill="#efe6d2"/>
<!-- ======= open-water furniture: soundings + compass ======= -->
<g font-family="ui-monospace, Menlo, Consolas, monospace" font-size="8.5" fill="#786c56" opacity="0.5" text-anchor="middle">
 <text x="250" y="388">14</text>
 <text x="330" y="448">18</text>
 <text x="390" y="252">9</text>
 <text x="300" y="330">12</text>
 <text x="900" y="312">21</text>
 <text x="1140" y="252">16</text>
 <text x="600" y="182">4</text>
 <text x="540" y="430">3</text>
 <text x="655" y="410">2</text>
</g>
<g fill="#786c56" opacity="0.35">
 <circle cx="280" cy="470" r="0.9"/><circle cx="450" cy="512" r="0.9"/>
 <circle cx="700" cy="178" r="0.9"/><circle cx="985" cy="332" r="0.9"/>
 <circle cx="530" cy="132" r="0.9"/><circle cx="1120" cy="330" r="0.9"/>
</g>
<!-- compass rose -->
<g stroke="#786c56" fill="none" opacity="0.5">
 <circle cx="190" cy="468" r="28" stroke-width="1"/>
 <circle cx="190" cy="468" r="3" stroke-width="1"/>
 <line x1="190" y1="436" x2="190" y2="500" stroke-width="0.8"/>
 <line x1="158" y1="468" x2="222" y2="468" stroke-width="0.8"/>
 <line x1="170" y1="448" x2="210" y2="488" stroke-width="0.5"/>
 <line x1="210" y1="448" x2="170" y2="488" stroke-width="0.5"/>
</g>
<polygon points="190,440 186,452 194,452" fill="#786c56" opacity="0.6"/>
<text x="190" y="430" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="8.5" letter-spacing="1.5" fill="#786c56" opacity="0.6">N</text>
<!-- ======= reef + no-go line (the guardrails) ======= -->
<path d="M470,560 C480,520 495,485 520,462 C560,428 600,450 640,445 C700,438 722,428 760,418 C800,408 840,424 880,428 C930,433 960,430 1000,430 C1040,430 1080,427 1120,426 C1150,425 1175,424 1200,424 L1200,560 Z" fill="url(#ps-reefhatch)" stroke="#a05a2c" stroke-width="1" opacity="0.9" stroke-opacity="0.5"/>
<!-- rock symbols -->
<g stroke="#a05a2c" stroke-width="1" opacity="0.55">
 <path d="M556,496 l8,8 M564,496 l-8,8 M560,494 l0,12"/>
 <path d="M646,478 l8,8 M654,478 l-8,8 M650,476 l0,12"/>
 <path d="M756,456 l8,8 M764,456 l-8,8 M760,454 l0,12"/>
 <path d="M896,466 l8,8 M904,466 l-8,8 M900,464 l0,12"/>
 <path d="M1046,452 l8,8 M1054,452 l-8,8 M1050,450 l0,12"/>
 <path d="M1146,466 l8,8 M1154,466 l-8,8 M1150,464 l0,12"/>
 <path d="M616,528 l8,8 M624,528 l-8,8 M620,526 l0,12"/>
 <path d="M976,506 l8,8 M984,506 l-8,8 M980,504 l0,12"/>
</g>
<!-- no-go line -->
<path d="M470,545 C480,505 492,470 516,446 C556,414 600,434 642,428 C700,421 722,410 762,400 C802,392 842,404 882,412 C932,417 962,414 1002,414 C1042,414 1082,411 1122,410 C1152,409 1176,408 1198,408" fill="none" stroke="#a05a2c" stroke-width="1.3" stroke-dasharray="6 5" opacity="0.8"/>
<g stroke="#a05a2c" stroke-width="1" opacity="0.6">
 <line x1="540" y1="438" x2="545" y2="446"/>
 <line x1="620" y1="430" x2="625" y2="438"/>
 <line x1="700" y1="416" x2="705" y2="424"/>
 <line x1="780" y1="398" x2="785" y2="406"/>
 <line x1="860" y1="408" x2="865" y2="416"/>
 <line x1="940" y1="415" x2="945" y2="423"/>
 <line x1="1020" y1="413" x2="1025" y2="421"/>
 <line x1="1100" y1="411" x2="1105" y2="419"/>
 <line x1="1180" y1="408" x2="1185" y2="416"/>
</g>
<!-- ======= ghost twin: no fixes, one giant cone ======= -->
<path d="M115,168 L987,600 Q1182,522 1073,344 Z" fill="#786c56" fill-opacity="0.09" stroke="#786c56" stroke-width="1" stroke-dasharray="4 6" opacity="0.45"/>
<path d="M115,168 C420,248 720,348 1030,472" fill="none" stroke="#786c56" stroke-width="1.8" stroke-dasharray="5 7" stroke-linecap="round" opacity="0.5"/>
<polygon points="496,278 482,279 485,270" fill="#786c56" opacity="0.55"/>
<!-- wrong-harbor X -->
<g stroke="#8a3a2a" stroke-width="2.2" opacity="0.85" stroke-linecap="round">
 <line x1="1022" y1="464" x2="1038" y2="480"/>
 <line x1="1038" y1="464" x2="1022" y2="480"/>
</g>
<!-- ======= the drift cones (dead reckoning: constant wedge angle) ======= -->
<g fill="#2f6b6b" fill-opacity="0.12" stroke="#2f6b6b" stroke-opacity="0.25" stroke-width="0.7">
 <path d="M115,168 L290,264 Q331,250 310,212 Z"/>
 <path d="M300,238 L474,215 Q496,184 462,169 Z"/>
 <path d="M758,352 L966,248 Q979,200 930,196 Z"/>
 <path d="M948,222 L1091,148 Q1099,115 1065,112 Z"/>
</g>
<!-- the long leg: same angle, more distance, wide cone -->
<path d="M468,192 L736,392 Q806,379 780,312 Z" fill="#2f6b6b" fill-opacity="0.16" stroke="#2f6b6b" stroke-opacity="0.35" stroke-width="0.8"/>
<!-- ======= the plotted passage ======= -->
<path d="M115,168 L300,238 L468,192 L758,352 L948,222 L1078,130" fill="none" stroke="#2f6b6b" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" opacity="0.95"/>
<!-- leg direction arrows -->
<g fill="#2f6b6b" opacity="0.9">
 <polygon points="218,207 203,208 207,197"/>
 <polygon points="398,211 387,219 384,210"/>
 <polygon points="617,274 603,272 608,263"/>
 <polygon points="862,281 854,293 848,285"/>
 <polygon points="1020,171 1012,183 1006,175"/>
</g>
<!-- dead-reckoning ticks along legs -->
<g stroke="#2f6b6b" stroke-width="1.1" opacity="0.55">
 <line x1="176" y1="195" x2="178" y2="187"/>
 <line x1="411" y1="203" x2="413" y2="211"/>
 <line x1="563" y1="249" x2="567" y2="242"/>
 <line x1="661" y1="303" x2="665" y2="296"/>
 <line x1="819" y1="306" x2="823" y2="312"/>
 <line x1="1028" y1="165" x2="1032" y2="171"/>
</g>
<!-- start -->
<circle cx="115" cy="168" r="8" fill="none" stroke="#2f6b6b" stroke-width="1.2" opacity="0.5"/>
<circle cx="115" cy="168" r="4" fill="#2f6b6b"/>
<!-- fixes: circle + tick -->
<g>
 <g fill="#efe6d2" stroke="#2f6b6b" stroke-width="1.8">
 <circle cx="300" cy="238" r="5.5"/>
 <circle cx="468" cy="192" r="5.5"/>
 <circle cx="758" cy="352" r="5.5"/>
 <circle cx="948" cy="222" r="5.5"/>
 </g>
 <g fill="#2f6b6b">
 <circle cx="300" cy="238" r="1.5"/><circle cx="468" cy="192" r="1.5"/>
 <circle cx="758" cy="352" r="1.5"/><circle cx="948" cy="222" r="1.5"/>
 </g>
 <g stroke="#2f6b6b" stroke-width="1.3" opacity="0.8">
 <line x1="291" y1="229" x2="296" y2="234"/><line x1="304" y1="242" x2="309" y2="247"/>
 <line x1="459" y1="183" x2="464" y2="188"/><line x1="472" y1="196" x2="477" y2="201"/>
 <line x1="749" y1="343" x2="754" y2="348"/><line x1="762" y1="356" x2="767" y2="361"/>
 <line x1="939" y1="213" x2="944" y2="218"/><line x1="952" y1="226" x2="957" y2="231"/>
 </g>
 <!-- the fix that saved the long leg -->
 <circle cx="758" cy="352" r="9.5" fill="none" stroke="#a05a2c" stroke-width="1.2" opacity="0.8"/>
</g>
<!-- ======= lighthouse: the standing check at the edge ======= -->
<g opacity="0.9">
 <polygon points="832,440 844,440 841,424 835,424" fill="#a05a2c" opacity="0.85"/>
 <circle cx="838" cy="419" r="2.5" fill="#a05a2c"/>
 <g stroke="#a05a2c" stroke-width="1" opacity="0.8">
 <line x1="829" y1="414" x2="824" y2="410"/>
 <line x1="847" y1="414" x2="852" y2="410"/>
 <line x1="838" y1="409" x2="838" y2="403"/>
 </g>
</g>
<!-- ======= land last: coastline covers cone spill ======= -->
<path d="M0,150 C60,146 90,143 115,140 C170,132 240,122 300,114 C350,108 390,108 430,112 C470,116 500,100 525,96 C555,92 572,99 588,105 C620,117 645,120 665,117 C705,112 735,104 762,97 C795,89 822,77 852,75 C885,73 915,86 945,94 C975,102 1010,124 1042,148 L1054,148 C1058,128 1062,114 1078,110 C1094,114 1098,128 1102,148 L1114,148 C1140,150 1170,146 1200,142 L1200,0 L0,0 Z" fill="#e5dcc3" stroke="#786c56" stroke-width="1" stroke-opacity="0.55"/>
<!-- coast hachure echo -->
<path d="M0,155 C60,151 90,148 115,145 C170,137 240,127 300,119 C350,113 390,113 430,117 C470,121 500,105 525,101 C555,97 572,104 588,110 C620,122 645,125 665,122 C705,117 735,109 762,102 C795,94 822,82 852,80 C885,78 915,91 945,99 C975,107 1010,129 1042,153" fill="none" stroke="#786c56" stroke-width="0.7" opacity="0.25"/>
<!-- coastal shoal patch: the other fenced edge -->
<path d="M585,104 Q640,152 700,154 Q762,154 790,99 C762,102 735,109 705,112 C665,117 645,120 620,117 C606,114 594,109 585,104 Z" fill="url(#ps-reefhatch)" stroke="none" opacity="0.8"/>
<path d="M585,104 Q640,152 700,154 Q762,154 790,99" fill="none" stroke="#a05a2c" stroke-width="1.1" stroke-dasharray="6 5" opacity="0.7"/>
<!-- pier at the start -->
<g stroke="#786c56" stroke-width="1.6" opacity="0.7">
 <line x1="113" y1="142" x2="115" y2="162"/>
</g>
<!-- harbor: the spot -->
<circle cx="1078" cy="130" r="6" fill="#efe6d2" stroke="#a05a2c" stroke-width="2"/>
<circle cx="1078" cy="130" r="2" fill="#a05a2c"/>
<!-- ======= cartouche ======= -->
<rect x="42" y="24" width="286" height="74" fill="none" stroke="#cbbd98" stroke-width="1"/>
<text x="56" y="45" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="3" fill="#8a3a2a" opacity="0.85">ONE SESSION, PLOTTED</text>
<text x="56" y="67" font-family="Roboto Slab, Georgia, serif" font-size="15.5" fill="#1f1a13">The passage</text>
<text x="56" y="85" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234">drift grows between checks. a fix resets it.</text>
<!-- ======= labels ======= -->
<!-- start -->
<text x="138" y="158" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10" letter-spacing="2.5" fill="#2f6b6b">START</text>
<!-- drift explainer on the first cone -->
<line x1="205" y1="290" x2="240" y2="240" stroke="#786c56" stroke-width="0.8" opacity="0.55"/>
<text x="170" y="302" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="12" letter-spacing="2.5" fill="#1f1a13" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">DRIFT SINCE LAST CHECK</text>
<text x="170" y="318" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">the wedge: everywhere the session might be</text>
<!-- a fix is a check -->
<line x1="468" y1="166" x2="468" y2="184" stroke="#786c56" stroke-width="0.8" opacity="0.55"/>
<text x="468" y="144" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#2f6b6b" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">A FIX · A CHECK</text>
<text x="468" y="159" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">position known again. the wedge collapses.</text>
<!-- the long leg -->
<text x="662" y="236" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="12" letter-spacing="2.5" fill="#1f1a13" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">TOO LONG BETWEEN CHECKS</text>
<text x="662" y="252" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">the wedge nearly reaches the rocks</text>
<line x1="662" y1="258" x2="680" y2="288" stroke="#786c56" stroke-width="0.8" opacity="0.55"/>
<!-- the save -->
<text x="868" y="345" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#2f6b6b" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">CAUGHT AT THE CHECK</text>
<text x="868" y="361" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">re-aimed at the spot</text>
<!-- lighthouse -->
<text x="838" y="462" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9.5" letter-spacing="2.5" fill="#a05a2c" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">STANDING CHECK</text>
<text x="838" y="476" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">always lit at the edge</text>
<!-- the guardrails -->
<text x="600" y="505" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="11" letter-spacing="2.5" fill="#a05a2c" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">GUARDRAILS</text>
<text x="600" y="521" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">fenced where damage can't be undone</text>
<!-- ghost -->
<text x="1000" y="382" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#786c56" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">THE SAME SESSION, UNCHECKED</text>
<text x="1000" y="397" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#786c56" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">no fixes. one wedge, all the way.</text>
<!-- wrong harbor -->
<text x="1030" y="500" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10" letter-spacing="2.5" fill="#8a3a2a" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">WRONG HARBOR</text>
<text x="1030" y="518" text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="14" fill="#786c56" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">Confident, and wrong.</text>
<!-- the spot -->
<text x="1078" y="66" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#a05a2c">THE SPOT</text>
<text x="1078" y="90" text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="17" fill="#1f1a13">Done, defined.</text>
<!-- chart-edge furniture -->
<text x="1188" y="548" text-anchor="end" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="8" letter-spacing="2" fill="#8a3a2a" opacity="0.7" paint-order="stroke" stroke="#efe6d2" stroke-width="2.5" stroke-linejoin="round">SOUNDINGS IN METERS · DRIFT DRAWN TO SCALE</text>
</svg>
</figure>

- Drift grows with distance since the last check. The agent steers each step from its own previous step, so small errors compound silently until something outside the session measures position. On the chart that is the wedge: everywhere the session might be.
- **A check is a position fix**. At a fix the wedge of possible states collapses to a point, and the next leg starts from a known position instead of an assumption. The diagnose-and-re-send you just ran was exactly this move: measure where the session actually is, then aim the next leg from there.
- Guardrails belong where damage cannot be undone. Fence the reef, not the open water. At an irreversible edge a standing check stays lit whether anyone remembers to look or not; where redo is cheap, let the session sail.
- An unchecked session arrives confident, and wrong. Same start, no fixes, one wedge widening the whole way. The success report comes from the wrong harbor.

Packaging decides what catches problems during the handoff.

A standing check pushes back before the next wrong step builds on the last one. That is the difference between a final review and feedback inside the passage.

## Reference and plan

- Each piece turns up on its own across practitioner write-ups. This training combined them into one kit and gave them names. Geoffrey Huntley's Ralph is the one published practice that runs all three at once. Armin Ronacher's January 2026 MiniJinja port ran two of them and named neither. You built all three today off your own failures, which beats a citation. On the map, the kit is what stands in for you at Verification.
- **Reference artefact**, against goal drift. A spec the agent reads and re-reads: success criteria, pointers at the relevant memory, named constraints. The spec on disk stays readable mid-session when the buried instructions in the conversation no longer are. In Ronacher's MiniJinja port, the original Rust snapshot tests played this role; in your re-send, the reference you assembled plays it.
- **plan.md** the agent owns and mutates, against context rot. A working document that holds durable state across the task: the agent reads it at every session boot, updates it as decisions land, re-reads it when the working window fills. What got ruled out an hour ago is written down, not remembered. Ralph leans on exactly this primitive to bootstrap entire greenfield projects.

## The verifier completes the three-pattern

- **External verifier**, against plausible-but-wrong. An automated check that decides whether a piece of agent-produced work meets a quality bar. You don't have to be the one to spot it.
- The menu you picked from is practitioner-lived. Kim's writeup of Boris Cherny has him reaching for all three shapes in his long-running practice; the menu form is Kim's synthesis. You built one against your dominant failure. The other two sit alongside the three-pattern for next time.

Three failures you named, three pieces, one each.

## The model has read the field

- The weights hold the written record: the setup posts, the plan-file templates, the verifier write-ups, the reversals that followed them. More of the field than you will read in a career.
- Ask for best practice and that is what answers: a well-read average of what other people published about other repos, frozen at a cutoff while the consensus keeps moving. Steer it as hard as you like: what it holds about your next run is a forecast.
- Whether this field ever settles into a real best practice is an open question. What is not open: today's playbooks are **candidates**.

## The evidence did not exist yet

- Much of what shapes your setup is on the record, and the agent can survey it: the test suite's shape, the merge rules in CI, the age of everything in git.
- What no survey returns: how this task, this model, this repository and this setup behave together in a run. No document holds it because, until the run, there is nothing to document. Asked ahead, the model predicts. **A prediction is not a measurement.**
- So a playbook stays a candidate until something tests it here, and nothing published can run that test for you.

## Two bearings make a candidate, not an optimum

- The contrast is two bearings on the same water: the task without the kit, then with it. Where the sessions disagree, you have something local to test: which failure recurs, and whether the check catches it again.
- A two-bearing fix is a start, wide by design. It narrows as more runs cross it; the optimum stays ahead, moving when your stack moves.
- The agent makes the evidence cheap: it runs the task, reads its own transcript, diffs the returns. **The engineer decides**: what counts, what the evidence means, what earns promotion into durable practice.
- A grounded candidate holds in review: *"measured here, this catches it, watch."*

## Hooks always fire

- A **hook** fires on a named event, and the agent has no say in whether it runs. Session start, prompt submit, before each tool call, after each tool call, on stop, plus a few more. The runtime fires the script whether or not the model remembers it exists.
- Hooks exist because the LLM is forgetful. Drift, half-remembered rules: the longer the session runs, the less you can trust the agent to hit a step that "should" happen every time. Hooks don't forget.

## Hooks for must-happen, prompts for taste

- **Must happen goes in a hook**; recommended stays in a prompt or rule. Anything that breaks the work if it skips belongs in a hook: the verifier you just wrote, a pre-commit guard, a session-start context loader. Anything taste-shaped or context-dependent stays in a prompt where the LLM weighs it. Hooks are the runtime's "I will not forget," bought at the cost of flexibility.
- Your repo has demands that don't show up in someone else's article. The verifier you built was one hook against one failure; the same primitive maps to more. Ask Claude to propose five hooks tied to this repo, beyond formatting and linting.

{{prompt:what-packaging-is-1}}

The ones worth keeping are tied to a specific file, convention, or failure mode in this repo, not a generic team-could-want-this.

## Every re-feed pass starts a fresh session

- Each pass is a new session, not a continuation of the last one. The loop re-sends the same prompt, and what carries over is what sits on disk: the work the previous pass wrote, and the check that judged it. Nothing from the conversation survives.
- That is why it catches drift. Drift lives in the conversation, and the conversation is what the loop throws away. Re-run inside the same session and you compound the drift; re-feed and the next pass reads the goal cold.
- The check is the stopping condition, so a verifier that can never fail makes an infinite loop. Every pass also pays to re-read its context from scratch. That cost is the point: it buys a session with no drift in it.

