# Agents that build agents

The closer named the flywheel in one line. *Agents that build agents.* This lecture is the unfolding of that line.

You authored two skills in this training. The first one at Module 3 packaged a piece of judgement you had carried for years (how to write a good test). The second one at Module 6 packaged a piece of judgement you had earned over two runs of the same task. Different sources, same move. Each skill made the next run cheaper.

The flywheel turns one more time when the agent itself starts proposing the skill.

## The move

Open a fresh Claude Code session in the repo you have been running. Hand it the same evidence you handed yourself at Phase 1 (the un-packaged Module 4 artefacts, the packaged Module 5 artefacts, the second skill you just shipped). Ask it to enter plan mode and design the next iteration of the loop.

Not "design a new skill." Not "improve my setup." Design the next iteration of the loop. What gap in the kit would the next run want closed? What rule would have prevented the subtler miss you have not yet seen? What shape of skill is missing from the menu of three you just chose from?

The plan that comes back is a candidate. You read it the way you read any plan from any agent. Judgement, push-back, taste. Some of it will be obvious. Some of it will be wrong. One or two items will be moves you would not have generated on your own.

That is the flywheel. The agent reads the evidence the loop produced, proposes the next scaffolding, and you decide which proposals earn their place in the kit.

## What this is not

This is not the agent writing its own skills without you in the room. At the start of this training, you might have hoped that was the destination. At the close of Module 6, you know it is not. Agents that build agents is a collaboration in the same shape every other beat in this training has been a collaboration. Claude proposes, you steer.

The reason is plain. Claude can read the artefacts the loop produced. It cannot read the codebase knowledge in your head, the political situation around the team kit, the next quarter's roadmap, the bug your tech lead lost three days to last sprint. The plan it generates is grounded in the evidence on disk. The decision about which proposals to act on is grounded in evidence the agent does not have.

Build a flywheel that lets the agent run as far as it can on its own evidence, and stops at the moment your judgement is the input that matters. That is the practitioner shape. Anything further pretends the agent has access it does not have.

## A prompt to try

This one is for after the cohort, on a quiet half-hour. New prompt, no rehearsal.

Ask Claude Code to enter plan mode, read the evidence from the two runs and the second skill, and propose the next iteration of the kit.

**Prompt** *(Claude Code, fresh session in the same repo)*

```
Enable plan mode.

Read these artefacts end to end:

- ./CLAUDE.local.md
- .claude/memory/
- the most recent un-packaged run's commit history and modified files
- the most recent packaged run's commit history and modified files
- the SKILL.md of the skill you authored at Module 6, in `~/.claude/skills/`

Then design the next iteration of the kit. Three questions:

1. What gap in the kit would the next run want closed? Name it as a memory rule, a sharper verifier, or a third skill. Pick the home; do not split.
2. What rule already in memory has gone stale across the two runs? Name one to subtract.
3. What shape of skill is missing from the menu of verifier / judge / gap-finder? If none is missing, say so. Do not invent.

Return a plan with the three answers. No preamble.
```

Read what comes back the way you read any plan. Push back where the proposals miss the codebase situation Claude cannot see. Approve the one or two that earn their place. Author them.

## Where the loop ends

There is no last turn. Each run surfaces the next gap. Each gap proposes the next move. Each move makes the next run cheaper. The kit grows, the rules sharpen, the skills accumulate, and the model underneath gets replaced every few months without changing the move.

The training closes. The flywheel does not.

