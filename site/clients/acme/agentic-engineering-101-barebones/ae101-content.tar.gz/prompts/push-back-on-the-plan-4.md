---
key: push-back-on-the-plan-4
dest: Claude Code
runtime: any
---
are these rules auto-loaded to each session context?
