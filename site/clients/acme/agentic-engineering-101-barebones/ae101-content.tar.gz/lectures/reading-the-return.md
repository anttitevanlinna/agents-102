# Reading the return

## What would have caught this earlier?

- Whatever came back is the artefact. You stepped away with the agent working. The session finished, hit its budget, or was stopped because enough was seen. All three are readable results.
- The closing summary is not the artefact. The machine would rather produce something than admit nothing: a stuck session invents a plausible way forward, and a thin result arrives described as progress.
- The question that drives the read: *what would have caught this earlier in the session?* Not *did the task succeed*. Not *should I have spec'd it tighter*.

## Three failure modes you'll use to read

- Practitioners hit the same three. Use them as lenses, not boxes.
- **Goal drift.** The instructions get buried as the conversation grows, and before long the agent is solving an adjacent problem with confidence. The LLM reasons from what fills the window now, and the original ask competes with everything generated since. Hard to spot until you compare what was asked against what was done.
- **Context rot.** Signal-to-noise drops as the working window fills. The agent rehashes approaches it already ruled out two hours ago, because "ruled out two hours ago" no longer fits in the working window.
- **Plausible-but-wrong.** Outputs look reasonable in isolation and don't match the original spec. The LLM produces the next likely word, not the next true one, so fluent and confident is its default finish whether the work is right or not. The most expensive to find: no obvious tell.
- Your rules file is in that window too. Dex Horthy, on the failure: *"The longer your file gets, the more Claude seems to treat individual sections as optional."*
## Diagnose first, fix later

- When an agent gets something wrong, the reflex is to fix it immediately: edit the prompt, add a constraint, reach for the next tool. The failures earn the validation that catches them.
- The arc is *test → learn → encode*. The un-packaged send-off was the test. The encode turns what the read finds into durable checks.

