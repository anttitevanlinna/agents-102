# Cookbook for Agent System Design

*This is how you do it.* A practitioner's cookbook, the moves, in sequence, that take someone from a chat conversation to a real agent system they can stake their reputation on. Not theory. Recipes you can run on Monday.

The first three recipes are the Bootstrap training's spine, written out as standalone how-to. After Bootstrap, you own them. New recipes get added as they mature, cloud deployment, team sharing, cross-org promotion, the rest.

Read any recipe in order or any recipe standalone. They stand alone; together they compose.

## Recipe 1, A piece of output that is genuinely yours

*Referenced from: Module 1 (getting-going).*

**What you end with:** one artifact, a site, a memo, a profile page, a pitch, that sounds like you, not like Claude. Specific to your situation, written in your voice, correct on the facts only you know.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 1 exercise file is the seed. Pattern: baseline without context → the differentiation frame (colleague-as-buyer, StoryBrand-adjacent) → strengths that serve them → look back at the baseline to find the fabrication → anti-branding via mirror → free iteration until "this is me." Store learnings as a `CLAUDE.md` guardrails file. The guardrails file is the first durable artifact.)*

**The test:** a colleague who knows you reads it and says "yeah, that's you." Not "that's impressive", "that's you."

**Why this is recipe 1:** you are the one evaluator you can't fool on your own content. Learning to spot fabrication on something you know cold is the foundation skill for everything that follows.

---

## Recipe 2, A compounding system around one live challenge

*Referenced from: Module 2 (building-agent-systems).*

**What you end with:** a text-on-disk memory for one real decision you're making, curated from three source zones (internal wiki, internal collab suite, curated internet), served by a custom agent that cites back to sources, and a daily scheduled touch that renders in your company's house style.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 2 exercise + homework files are the seed. Pattern: pick a live challenge (prework) → curate three sources with Claude's help → load into a memory with plan-mode review → build a custom agent as a markdown file with rules → add sources, watch pages sharpen not grow → let the memory audit itself → schedule a daily touch → extract the house style into `style.md` → every HTML output inherits it. The root `CLAUDE.md` grows across the whole training, one rule at a time.)*

**The test:** a week after training, you're still reading the morning output, and the memory is noticeably sharper than the day you built it.

**Why this is recipe 2:** persistence + automation = system. A chat can't compound. A folder of markdown can.

***Worked example, a program manager agent.*** A program manager at a multi-team Nordic software org built one of these over a fortnight in 2026 (Claude Code Desktop, macOS). Three source zones: weekly leadership-and-team meeting transcripts dropped into `sources/transcripts/`, the team's Jira read through the connector, and the active plan files in Confluence. The memory at `memory/program-state.md` got rewritten daily, *what's moving, what's stuck, what's promised, what's slipping*, citing back to the source each claim came from. A custom agent at `agents/program-manager.md` ran every morning on a schedule: scan for TODOs that had drifted past the owner's committed date, draft a one-line Slack nudge, and queue it for human approval before sending. (The gate is Recipe 4 layered on Recipe 2, an outbound action never leaves the agent unreviewed.) The surprise wasn't that the agent caught the slipping TODOs, the PM already did that by hand. The surprise was the drafts came back *better than her own*: softer, more specific, and harder to ignore, because the memory had read the meeting where the commitment was actually made.

---

## Recipe 3, A multi-agent system that answers a strategic question

*Referenced from: Module 3 (multi-agent-systems).*

**What you end with:** a fan-in pipeline that retrieves from three source zones in parallel (three Claude Code sessions on shared files), then synthesises through three subagent stances in one session (backward-from-end planner, Martin's *what would have to be true?*, Sutherland-style reframer), guardrailed by a strategic framework (Rumelt's kernel by default). Output is a framework-shaped answer to your real strategic question, and a plain note of what about the answer you're not sure about.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 3 exercise file is the seed. Pattern: write the strategic question → open four Claude Code sessions on the shared directory → paste three retriever prompts (one per source zone) → let them run in parallel, answer their confirmations → main session spawns three subagent stances → stances return, then synthesiser combines against the framework → note the uneasy distance in `module-3/wonder.md`. The uneasy distance is the feature, not the bug, Recipe 5 picks it up.)*

**The test:** the answer is specific enough that you'd bring it to your CEO as a starting draft, and plain enough that you know which sentence you wouldn't stake your reputation on yet.

**Why this is recipe 3:** some work genuinely needs more than one agent, when access, dialect, or stance differ, coordination earns its keep. Most work doesn't. Learn the move; respect the default.

***Worked example, the continuous research system in this repo.*** `continuous-research/` is a Recipe 3 in production. The standing strategic question: *what are practitioners actually doing in the agentic space, and which patterns have converged enough to bet on?* Three source zones run in parallel, practitioner-direct (own blogs, X.com, GitHub, conference talks), practitioner-analysis (technical teardowns, specialist-journalist interviews), academic (university research, benchmarks). A synthesis stance combines the retrievals against an explicit evidence ladder (Level 0 commercial → Level 4 cross-domain meta-pattern). Findings live as dated markdown; a synthesis index threads convergence. The framework guardrail is the ladder itself plus three gates per finding (truly agentic? independent evidence? specific outcome?). Every claim carries a source-type label and a URL; freshness window is six months. (The four review personas, source-type-auditor, zombie-stat-detector, freshness-checker, evidence-ladder-classifier, are Recipe 6 layered on Recipe 3: fixed judges that re-fire on every modified file.) The surprise wasn't the convergence patterns the system surfaced. The surprise was how often the gates *rejected* sources that look credible at first scan: round-number failure stats with no methodology behind them, customer-success pages on supplier sites, journalist write-ups attributed as if the practitioner authored them.

---

## Recipe 4, A scoped agent your organisation can trust

*Referenced from: Module 4 (security).*

**What you end with:** a working agent audited against two lenses (your company's policy + named agent-risk patterns), a reusable security check authored as a personal skill, a security report with residuals named, not solved, and 1–5 short security operating rules compounded into your root `./CLAUDE.md` so future sessions remember the boundaries.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 4 exercise files are the seed. Pattern: run customer policy reference files raw once → package the useful check as a personal skill carrying two lenses (policy + agent-risk with named attack classes) → install the skill in your runtime → load it against your agent system → audit returns compliant / violating / "I can't tell" rows per rule → pick one risk and apply a mitigation (scope, split, filter, gate, review) → name the residual risk plainly → compound 1–5 short security rules into root `./CLAUDE.md`. The five named agent-risk patterns are: prompt injection direct, prompt injection indirect, secrets-in-context, tool-confusion, skill supply-chain.)*

**The test:** the security report names a residual risk you can't yet remove, and the operating rules in `./CLAUDE.md` would tell a future session exactly what to check before touching this system again. "I can't tell" appears at least once, plainly, and you don't try to flatten it.

**Why this is recipe 4:** certainty about agent safety is a fantasy. The discipline is running the check, not waiting for the check to come back clean. A scoped agent isn't one with no risk; it's one whose residual risk is named, owned, and visible to the next session.

***Worked example, incoming email triage.*** A customer-support team at a B2B SaaS company built one of these in early 2026 (Claude Code, scheduled execution on macOS). The agent reads incoming email from a shared inbox every 15 minutes. Two lenses run on each message: a policy lens (what counts as P1, outage signal, security report, named-customer escalation, churn-risk language), and an agent-risk lens (prompt injection in the email body, sender spoofing, attachment-only context, urgent-sounding marketing dressed as a real escalation). Critical ones get routed to one Slack channel with a one-line summary, original sender, and a link back to the thread. Non-critical ones stay in the inbox untouched. The scope is read-only on email and write-only-to-one-Slack-channel; nothing else. The surprise wasn't that the agent caught the obvious P1s. The surprise was the *"I can't tell"* column, the agent flagged five emails per week as ambiguous, and three of them turned out to be the most important threads to escalate, *exactly because* they didn't fit the established policy patterns yet. Residual owned plainly: the policy lens drifts as the business changes; without quarterly re-scoping, the false-negative rate climbs.

---

## Recipe 5, A judge you've earned by benchmarking

*Referenced from: Module 5 (output-quality).*

**What you end with:** a 30-claim benchmark you wrote yourself against your own output, four candidate detection methods scored against it, a winning method synthesised into a reusable judge file at `judges/groundedness-judge.md` with stated scope and one named "known limit", a judge you can defend in production because you measured it, not because someone authoritative recommended it.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 5 exercise files are the seed. Pattern: take Module 3's synthesised briefing as the test corpus → write a 30-claim benchmark with verdicts grounded in retrieval evidence → run four detection methods in parallel against the benchmark → score each method's agreement with your verdicts → declare a winner with stated reasoning → package the winning method as `judges/groundedness-judge.md` carrying its scope and one named "known limit" → keep the scoreboard as the explanation. Three Claude sessions plus a scorer is the typical fan-out shape.)*

**The test:** you can hand a colleague the scoreboard and the judge file, and they understand both why this method won AND what it can't reach, without you in the room to explain.

**Why this is recipe 5:** quality-method selection in agent work is empirical, not authoritative. A judge picked from a scoreboard you ran is one you'd defend; a judge picked because someone authoritative said so isn't.

---

## Recipe 6, A self-improving generator under a fixed judge

*Referenced from: Module 6 (evaluations).*

**What you end with:** a re-runnable eval loop on disk where the judge from Recipe 5 stays unchanged across rounds, a generation tactic file (`./generation-tactic.md`) rewritten between rounds from per-claim judge feedback, and a score trajectory you can read off the artefacts, same yardstick, sharper output each cycle.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 6 exercise files are the seed. Pattern: open `judges/groundedness-judge.md` as the fixed yardstick → main session orchestrates the loop, generation and judging happen in separate agents → round 1: generate with current tactic → judge produces per-claim feedback → main session rewrites `./generation-tactic.md` from the feedback → round 2: generate again under same judge → repeat for N rounds → keep all run artifacts under `module-6/` so the trajectory is readable. The judge is sacred; it does not move. The generator is what tightens.)*

**The test:** you can walk away during the loop and come back to a sharper generator the same yardstick still can't fault, and the per-round tactic diffs read like a record of what the system actually learned.

**Why this is recipe 6:** this is where the human moves up a level. You stop reviewing every output and start designing the loop, the standards, and what "better" means. The fixed judge is your delegated taste; the self-improving generator is the work you no longer have to do by hand.

---

## Recipe 7, Sharing a slice of your system that absorbs

*Referenced from: Module 7 (personal-to-team).*

**What you end with:** an outcome statement for the job your teammate is trying to get done (interviewed agentic-JTBD style, not guessed), a chosen sharing surface from the four that work, share *context*, share a *skill*, share the *output*, or share an *interface*, a technical plan AND a people plan covering ownership, governance, operating, accountability, propagation, and a named likely adoption failure with the social part visible.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 7 exercise files are the seed. Pattern: name the teammate and the job they're trying to get done → run an agentic JTBD interview where the agent reads your memory, drafts a hypothesis, then asks targeted questions → write the outcome statement → choose the smallest sharing surface that moves the outcome (context / skill / output / interface) → produce the technical plan → produce the people plan → run a switch-test with the teammate to surface the assumptions they'd have to absorb → name the likely failure before it happens. "Share the whole agent" is not on the list. The four that work are slices, each one absorbable; whole-agent isn't.)*

**The test:** the teammate could read your sharing artefact, take the smallest surface you offered, and use it next week, without you sitting next to them, without a training session, and without rebuilding their workflow.

**Why this is recipe 7:** access is the easy half of sharing; absorption is the hard half. The bottleneck isn't *can they reach it?* but *can they fit it into their existing work fast enough that they keep using it?* Picking the smallest surface that moves the outcome, not the largest one your infrastructure allows, is how you cross that gap.

---

## Recipe 8, A flywheel that builds the next agent

*Referenced from: Module 8 (agents-building-agents).*

**What you end with:** a strategy kernel (Rumelt-shape: diagnosis, guiding policy, coherent actions) grounded in your real agent system and your real company question, a suggested agent set to add over the next two weeks, and a two-week plan that names what you'll test, what you'll learn, and which assumption breaks first, produced through three thinking disciplines run at room scale: Rumelt on *crux*, Martin on *what would have to be true?*, Klein-and-Kahneman on *pre-mortem*.

**The moves, in order:**

*(To be written out as Pass 3 completes. Current Module 8 exercise files are the seed. Pattern: connect the shared deliberation folder → buyer/sponsor seeds `challenge.md` → each participant gets a folder named after them → main session reads the full agent system, the Module 7 next-step file, and the sponsor challenge → three thinking-discipline subagent stances run against the question (crux / what-would-have-to-be-true / pre-mortem) → one or two central synthesizer agents write the kernel, the agent set, and the two-week plan to the shared root → student leaves with a flywheel they can run again next month on a new question.)*

**The test:** the kernel passes the *no-puff* test, it actually disagrees with at least one obvious option, names a real obstacle, picks a coherent set of moves. The agent set is sized to be built in two weeks. The plan names which assumption would break the strategy if false.

**Why this is recipe 8:** the cycle that just sharpened the kernel is the same cycle that sharpens it again next month. Code-generating agents are the meta-tool, the only category where building one tool genuinely makes the next one faster to build. The flywheel is not metaphor; it is what the artefacts actually do.

---

## Index of agent shapes

Escoffier-flavoured. Indicative shapes a practitioner would recognise, each is a real archetype many companies build; specifics vary by company. The three full worked examples earlier are real-build evidence; this index is the wider catalogue. Each entry names sources, action, and which recipes it composes.

**Sales prospect outreach drafter.** Reads the target list, each prospect's public footprint (LinkedIn, news, hires, fundraises), and the team's prior-converted touches. Drafts one personalised first-touch per account citing a real hook, not a generic *"loved your article"* opener. Composes R2 + R6.

**RFP / proposal response drafter.** Pulls from prior winning proposals, the product knowledge base, and pricing rules. Drafts response sections; flags clauses needing legal review. Composes R3 + R6.

**Contract clause-review.** Reads incoming vendor contracts against standard MSA terms (policy lens) and ambiguity-as-risk patterns (auto-renewal, indemnity scope, jurisdiction shifts). Returns *standard / non-standard / "I can't tell"* per clause with policy citation. Composes R4 + R5.

**Customer-onboarding kickoff brief.** Reads the signed contract, the statement of work, the customer's website, and recent sales calls. Produces a kickoff brief grounded in actuals, not the CSM's intuition. Composes R2 + R5.

**Quarterly business review (QBR) brief.** Reads usage telemetry, support history, prior QBR commitments, and the customer's stated objectives. Drafts a QBR narrative the CSM edits, then shares as the deliverable, the brief itself is the share surface. Composes R2 + R5 + R7.

**Monthly-close variance commentary.** Reads the ledger, the budget, and prior-period commentary. Surfaces variances over threshold and drafts the narrative: *why this variance, what changed, what to watch next month.* Composes R2 + R5.

**Knowledge-base curator.** Watches Slack channels, Confluence edits, and recent decisions. Decides what should become permanent KB entries vs. ephemeral chatter, drafts the entry, queues for review. Composes R2 + R7.

**Customer-support reply drafter.** Reads the incoming ticket, prior similar tickets, product docs, and recent fixes. Drafts a reply for the support agent to review and send. Composes R2 + R6.

**Board / leadership weekly narrative briefing.** Reads dashboards, project trackers, and recent decisions. Drafts the *narrative* of the week, not the numbers, the story, under a fixed editorial judge that holds the voice steady. Composes R2 + R6.

**Agent-build coach (the flywheel).** Reads your existing agent system, your active business question, and your Module 7 sharing plans. Drafts a strategy kernel, a suggested agent set for the next two weeks, and a pre-mortem on what would break first. Composes R8.

---

### Recipes beyond the training

Written as they stabilise:

- **Cloud deployment.** Moving a working local system to a hosted runtime (Cowork / Routines / equivalent). What changes, what breaks, what becomes easier.
- **Team sharing.** Promoting memorys and agents from personal scope to shared scope, without the usual collaboration-software rot.
- **Cross-org reuse.** Pattern libraries, agent marketplaces, the sensible portions of each.
- **Integration with existing enterprise systems.** ERP, CRM, data warehouse, iPaaS.
- **Observability and cost control.** Watching what the agent actually does and what it costs when it does.
- **Handoffs to non-agent systems.** The seams where automation ends and human work begins, by design, not by accident.

Add a recipe when the move is reliable enough that a working practitioner would recommend it to another without caveats. Not before.

