---
key: agent-loop-raw-3
dest: Claude Code
runtime: any
---
You write text. How does that text become actions in other systems?
