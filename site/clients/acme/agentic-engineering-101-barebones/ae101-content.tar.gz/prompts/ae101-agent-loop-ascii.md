---
key: ae101-agent-loop-ascii
dest: Claude Code
runtime: any
---
Draw the agent loop as an ASCII diagram. Name the harness, the LLM, the tool-call step, and how tool results feed back to the LLM.
