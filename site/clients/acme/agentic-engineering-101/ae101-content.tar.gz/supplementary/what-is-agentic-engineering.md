# What is agentic engineering

**Agents engineering, engineers steering.** The work relocated. Learning amplified.

**Agents inventing and building the engineering sequence.** Klaassen's compound loop, Cherny's parallel worktrees, your authored test-strategy skill. So can you.

**Attempt the work you wouldn't have attempted.** Not yesterday's work 10× faster. Ambition stays your job.

**Agentic engineering is the discipline of noticing.** The agent learns from your steering. You learn from its drift. The loop amplifies.

**OODA at its sharpest.** Agents collapse Act. Judgment is the ceiling, not your keystrokes.

**Compounding builds.** One cycle is a fix. Ten is a memory file. A hundred is a skill the team uses on Tuesday. A thousand is a system that learns faster than the field moves. Cycles amplify.

**Three frontiers stay open.**


Making systems that learn.


Giving the system a persistent memory.


Working towards a system that can self-sense for real-life success and failure.

