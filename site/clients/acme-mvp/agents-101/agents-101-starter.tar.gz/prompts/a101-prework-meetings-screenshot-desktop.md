---
key: a101-prework-meetings-screenshot-desktop
dest: Claude Code
runtime: desktop
---
I just attached a screenshot of my calendar week view to this message. Read it, list my main meetings this week, and summarize the shape of the week in 5 lines. Save the summary as `prework/meetings.md`.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#5-summarize-your-week-in-meetings-10-min
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#6-read-the-mental-frame-10-min

End your reply with [Read the mental frame](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#6-read-the-mental-frame-10-min). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.
