# Map the gaps, cut the rule

**Time:** 20 minutes.

**Session** *(new, "Module 6 worktree session")*

Open a new Claude Code session in the existing M5 worktree (`../<repo-name>-m5`), no fork. M5's session may still be running the re-send. Before this module edits files or cuts rules, decide whether it is done enough, should be stopped, or counts as the partial artefact.

**What you do:** diff two sessions of the same task.

**What you build:** a ranked gap map and one stale rule cut.

**The point:** two sessions are enough to place every lesson.

---

## Diff the two sessions, rank the gaps

- You hold two sessions of the same task. The un-packaged session sits on the `m4/<slug>` branch recorded in `task.md`; the packaged re-send sits on the `m5/<slug>` branch recorded in `plan.md`.
- Read from the recorded coordinates, not a branch or transcript search. Both sessions recorded their transcript paths: M4 in `task.md`, M5 in the protected `Run coordinates` block at the top of `plan.md`.

Ask Claude to read both sessions and walk the diff between them.

{{prompt:spot-gaps-build-the-loop-1}}

## Read the contrast, push back where it generalises

- Skim past the opening plan. The agent will likely open with a four-dimension plan summary (*"I'll start with repo state across the m4/ branch, then..."*) before any quoted evidence lands. The contrast moments are what you're reading for.
- Push back where the agent generalises. If the agent writes *"the agent drifted on goal"* without naming which commit, which file, which scrollback line, re-run the prompt with the quote rule re-asserted.
- Expect over-credit on the packaging. A fair push-back is *"name one thing the verifier missed, concretely."*

## Cut one stale rule the diagnosis killed

- Two sessions of the same task were the first real stress-test of `./CLAUDE.local.md`. Diagnosis surfaced rules that turned out wrong, never fired when they should have, or fired and made the session worse.
- Rules-files have a half-life. Adding rules is only half of it; subtracting the dead ones is the other half.

Ask Claude to read your rules file against the diagnosis and cut the one rule it killed.

{{prompt:spot-gaps-build-the-loop-2}}

## Approve, unless the cut spreads past the one rule

- The agent may pause before editing `./CLAUDE.local.md`. If it asks, approve.
- Push back if the diff touches more than the one rule you flagged. *"In place"* is loose wording, and the agent may rewrite more than the one stale rule. One rule cut, no more.

