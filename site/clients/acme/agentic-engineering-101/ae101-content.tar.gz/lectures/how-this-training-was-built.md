# How this training was built

At start, this training was bulletpoints. A strategy doc. Seven headings, thirty bullets, the sort of list that makes you feel like you understand something and then realise you don't.

The bullets became module prototypes. Little drafts of what the training might be. Storylines. First lectures. All of them wrong.

Not wrong in the way a bad draft is wrong, where someone missed the point. Wrong in the way any first version is wrong. Plausible, coherent, reading fine until you hold it next to what the training was actually for. Then the gap showed up. Every time.

That gap turned out to be the valuable part.

## Wrong is how steering gets in

If the first draft had been right, there would have been nothing to push on. The drafts were wrong in specific, namable ways. A phrase that smuggled consultancy-voice into an engineering lecture. An exercise that asked a real engineer to do something insulting. A module that wanted to feel tidy where the feeling should have been unease.

Each wrongness was a thing to point at. And each thing pointed at turned into a rule.

"Don't end a module with three scripted questions."
"Every prompt block gets a one-sentence lead-in with a command verb."
"Every claim about Claude Code must have been verified within the last month."

The rules were not right the first time either. Some were overscoped. Some fired on the wrong surface. Some only held for one kind of content and broke for another. They got sharpened the same way the drafts did: used, corrected, rewritten.

## The rules started doing the work

Once the rules lived in a file Claude Code could read, they stopped being reminders and started being load-bearing. Claude Code opens a session, loads the rules, plans inside them. A subagent dispatched to check a draft is handed them in its brief by the session that dispatched it. The rules cross the boundary between the person writing them and the agents using them.

This is the move. A rule written down is a thing one person knows. A rule in `./CLAUDE.md` is a thing every session inherits. A rule in a shared checklist is a thing every dispatched subagent is handed before it writes a word.

The rules compounded. Learning compounded to make better rules. More rules, more pointed. The strategy doc that started as bulletpoints now has a companion checklist for every writing surface: student-facing, sales copy, pedagogy, writing, research claims, platform claims. Each fires at the moment it matters and no other moment.

## Then the agents started checking the agents

Somewhere along the way, the changes got bigger. What used to be one person fixing one line became plan mode reshaping a whole file, then a subagent auditing that file against a compendium in the background, then four agents in parallel auditing a file against four compendiums while a fifth checked the neighbours. The work-per-session went up. The care-per-line went up. Sweeping changes that would have taken a week got made in an afternoon because the rules were tight enough to hand off.

Every session got better. Every session reached for better scale. The next session inherited what the last one figured out.

## What you just did

That shape you just heard, told as a story over five minutes, is the shape you just ran on your own repo. Over ninety minutes, not a year. On a trivial bug, not a whole training.

You let Claude read your repo. The first read was partly wrong. You saw the wrongness, named it, corrected it. That correction turned into a rule. The rule sits in a file called `./CLAUDE.local.md`, which is yours, gitignored, alongside you. The next module will extend it. The module after that will extend it again.

By the end of the training, you will have a rules file shaped by how you actually worked. Not a rules file written from a blank page. Not a template the trainer handed you. Yours, grown from evidence.

The pattern has a name. Kieran Klaassen at Every calls it *compound engineering*. The retro you just ran was step four of his loop: plan, work, review, compound.

**Mental models only come from doing.** You just did. Compound engineering an hour ago was a name. Now it's a loop you ran on your own repo.

The loop is the shape. The bug today was the excuse.

