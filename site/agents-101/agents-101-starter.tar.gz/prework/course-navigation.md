# Agents 101 workbook navigation

Workbook: https://agents102.bosser.consulting/agents-101/

Use this file for navigation and local progress. The workbook holds the teaching and exercise instructions. Help with the learner's current request; let the learner supply the material, make decisions, and choose when to continue.

## Returning to the workbook

After completing a request whose text matches a file in `prompts/` (search that folder for a distinctive line of the request), save its place at `prework/learning-position.md`: the prompt file's name and its workbook link. The link for `prompts/<name>.md` is `https://agents102.bosser.consulting/agents-101/#p-<name>`. Record what the request produced and any unfinished learner action. Do not mention the save in your reply. Preserve existing revision notes. A written file does not establish that the learner played, compared, inspected, or accepted it.

Adding the course files is complete once the archive is unpacked, the reading cue is in place, and you have read this guide. Record that step as complete and save the calendar exercise as the next link.

When the request also matches a row under Workbook returns below, save that row's current and return links too, and end the reply with the row's return link and its readable label. Keep helping with revisions when asked. Wait for the learner to choose the next activity.

The training-folder `CLAUDE.md` starts with a course-navigation reading cue. Preserve it when the learner develops their own working rules in the Module 2 debrief. Navigation supplies no personal context or generation rules. Do not add those on the learner's behalf.

## Back to the handbook

When the learner asks to go back to the handbook or the workbook, in any words ("Back to the handbook", "let's get back to the workbook"), read `prework/learning-position.md` and answer in at most two lines: what they last did, in a few plain words, and the saved link. Give that one link only, with no file names and no mention of this guide. Do not start the next activity. With no saved place, follow Resuming below.

## Pausing

Save a short position note at `prework/learning-position.md`: current section, its exact workbook link if known in the conversation, finished work, unfinished work, and next action. Use a section title when the exact link is unknown; do not invent a link. Preserve unfinished work rather than treating a generated output as completion.

Keep this note local and limited to navigation and work status. Exclude names, companies, and source-document contents. Leave exercise outputs and root instructions unchanged. Finish with the workbook's [Resume learning](https://agents102.bosser.consulting/agents-101/#resume-learning) link.

## Resuming

Read the position note if it exists. Check only the exercise files it names. Files outside the note do not create a conflict. Briefly describe the recorded progress and next action. Give one workbook destination. When work remains, give only the saved current link and omit later-section links, including conditional previews.

- Work remains: give the saved current link.
- Current activity explicitly complete: give the saved next link.
- Section title without an exact link: give the workbook base link and that title; ask the learner to find it in the workbook.
- No note: link to [Prework](https://agents102.bosser.consulting/agents-101/#prework) and ask which section the learner reached. Existing output files do not prove completion.
- Conflicting or unclear evidence: ask one question about where the learner stopped and wait.

Resume only recovers position. Do not run an exercise, regenerate an output, or change root instructions. Do not transmit progress or request account details.

## Workbook returns

| Completed request | Current section | Return after request |
| --- | --- | --- |
| Extract the starter archive | [Current section](https://agents102.bosser.consulting/agents-101/#3-install-the-training-folder-3-min) | [Summarize your week in meetings](https://agents102.bosser.consulting/agents-101/#make-your-calendar-briefing) |
| Build the snake game at prework/snake.html | [Current section](https://agents102.bosser.consulting/agents-101/#4-build-a-snake-game-10-min) | [Open and play your snake game, then continue Prework](https://agents102.bosser.consulting/agents-101/#4-build-a-snake-game-10-min) |
| Summarize meetings at prework/meetings.md | [Current section](https://agents102.bosser.consulting/agents-101/#5-summarize-your-week-in-meetings-10-min) | [See what makes this an agent](https://agents102.bosser.consulting/agents-101/#6-read-the-mental-frame-10-min) |
| Build the initial personal page from LinkedIn | [Current section](https://agents102.bosser.consulting/agents-101/#phase-1-the-boring-baseline) | [Apply a framework you know](https://agents102.bosser.consulting/agents-101/#phase-2-apply-a-framework-you-know) |
| Write module-1/personal-brand-generation.md | [Current section](https://agents102.bosser.consulting/agents-101/#phase-7-close-package-what-you-learned) | [See the mechanism repeat in every phase](https://agents102.bosser.consulting/agents-101/#see-the-mechanism-repeat-in-every-phase) |
| Get a cold read of module-1/site.html | [Current section](https://agents102.bosser.consulting/agents-101/#get-a-cold-read) | [Compare the cold read and finish Module 1](https://agents102.bosser.consulting/agents-101/#get-a-cold-read) |
| Run the Module 2 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#building-agent-systems) | [Start Module 3: Multi-agent systems](https://agents102.bosser.consulting/agents-101/#multi-agent-systems) |
| Run the Module 3 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#multi-agent-systems) | [Start Module 4: Security](https://agents102.bosser.consulting/agents-101/#security) |
| Run the Module 4 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#security) | [Start Module 5: Output quality](https://agents102.bosser.consulting/agents-101/#output-quality) |
| Run the Module 5 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#output-quality) | [Start Module 6: Evaluations](https://agents102.bosser.consulting/agents-101/#evaluations) |
| Run the Module 6 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#evaluations) | [Start Module 7: Agents building agents](https://agents102.bosser.consulting/agents-101/#agents-building-agents-solo) |
| Run the solo Module 7 debrief | [Current section](https://agents102.bosser.consulting/agents-101/#agents-building-agents-solo) | [Finish Module 7 and the course](https://agents102.bosser.consulting/agents-101/#agents-building-agents-solo) |
