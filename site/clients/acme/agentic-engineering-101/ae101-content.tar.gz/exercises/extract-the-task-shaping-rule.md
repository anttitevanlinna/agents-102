# Codify the rules, place the file

**Time:** 15 minutes.

**What you do:** surface task-shaping rules from the session you just ran, then read more off one story ticket.

**What you build:** one rules file from two sources: how you shaped this task, and how your team writes stories.

**The point:** find a place for your rules.

---

## Phase 1: Codify the rules from this session

*8 min*

- The rules are already in the session, unwritten; codifying them is the work. Each decision in the plan read carries indirect information about the rules you already work by.
- The agent reads the scrollback; you react to what it proposes. The scrollback is the right source here: the question is how you worked, not what is on disk.

Ask Claude for the rules.

{{prompt:extract-the-task-shaping-rule-1}}


## Reject or rewrite the generic rule

- The rule that arrives generic, like "pick tasks that span multiple files," is the one to rewrite in your words, or reject.

## Read more rules off one story ticket

- The same move you ran at M1 on a bug ticket, pointed at a story. How your team writes stories is a rule the tracker has been keeping, same as the bug fields were.
- If the task you brought came from your tracker, its own ticket is the one to read. Otherwise any real story works. One the agent just wrote carries none of your team's conventions.
- No tracker this session can reach? Paste the fields instead of the link.

Drop a story ticket link after the colon.

{{prompt:extract-the-task-shaping-rule-4}}

## Phase 2: Save the file where you want it

*4 min*

- Every session on this laptop (user-level), or only sessions in this repo (repo-personal).
- Claude knows the paths; the choice is yours.

Decide the location with Claude.

{{prompt:extract-the-task-shaping-rule-2}}


## Where rules can live, and when they load

| What | Where | Loads | To wire |
|---|---|---|---|
| CLAUDE.md files | user-level, repo, repo-local (gitignored) | every session | |
| Claude rules | `.claude/rules/` (repo) · `~/.claude/rules/` (personal) | every session; `paths:`-scoped ones on matching file reads | `paths:` frontmatter |
| Auto memory | `~/.claude/projects/<project>/memory/` | `MEMORY.md` index every session; topic files as needed | Claude writes it; *"memorize X"* to store, `/memory` to inspect |
| Skills | personal or repo skills folder | name and description every session; full body on invocation | author or install from a plugin marketplace |
| Roll your own | any path: a notes folder, an ADR directory | only when a prompt names it or Claude reads it | an `@import` line in an auto-loaded CLAUDE.md upgrades it to every session |

Roll your own is often facilitated by hooks and router skills: a hook injects it at session start, a router skill reads it when the work calls for it.

- If the picked path only loads when named, ask for the `@import` line before you move on. Without it the file sits unread.
- [Claude Code for engineers](../trainings/agentic-engineering-101/reference/claude-code-for-engineers.md) is the long form: precedence, walk-up, the managed layer.

## Phase 3: What this file could automate later

*3 min*

Ask Claude what this file could drive later.

{{prompt:extract-the-task-shaping-rule-3}}


## Read the shapes

- A shape you could use has a trigger and a place for your file in the loop. If Claude offers only one, ask for two more.
- Want the machinery? Ask about GitHub Actions, the Claude Code action, and Routines by name.

