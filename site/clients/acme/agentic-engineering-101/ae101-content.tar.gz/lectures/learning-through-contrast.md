# Read the session before you fix it

## Diagnose first, fix later

- The session may have stopped, finished, or run out of credit. Whatever came back is data.
- **Diagnose first. Fix later.** The move cuts against most engineering instinct. When an agent gets something wrong, the reflex is to fix it immediately: edit the prompt, add a constraint, reach for the next tool. This module holds that reflex off. The failures earn the validation that catches them.
- The arc is *test → learn → encode*. The un-packaged send-off was the test. This is the learn. The encode turns what the read finds into durable checks.

This session shows how the agent handled your task and codebase.

## Three failure lenses

- **Goal drift.** The agent solved an adjacent problem with confidence: the instruction got buried or the scope got redirected, and the session kept going.
- **Context rot.** Signal-to-noise dropped as the working window filled; the agent rehashed approaches it had already ruled out an hour ago.
- **Plausible-but-wrong.** Outputs look reasonable in isolation and don't match the spec. The most expensive failure to find, because nothing about it looks broken.
- Every artefact gets read through all three. One lens usually dominates; the read still walks each one, because the lens you skip is the failure you can't name.

## Managing the window

- **Never trust the window** to hold over a long session. Compact early and manually if you like: `/compact focus on the failure modes and the validation I'm sketching` keeps what you choose, where a bare `/compact` keeps whatever the summariser guessed mattered. Some good engineers just let auto-compact fire. No winning strategy here, and no percentage worth memorising.
- Manual compaction works because you're at the keyboard. The diagnosis is bounded keyboard work. If you've specified a large enough task well, the re-send at the end of this module can run for hours while you're away. A session nobody is watching can't be manually compacted.
- Hands-off option one: trust auto-compact. The model decides what to keep when its window fills. Sometimes useful, sometimes wrong; better than dropping context entirely.
- Hands-off option two: give the agent something durable to re-read. A working document the agent owns and updates. A reference it diffs its output against. An automated check that fires on produced work. Files on disk survive compaction; conversation-only instructions may not. Once those exist, auto-compact can fire and the agent re-anchors from what survives.
- Option two is what the exercise builds. `/compact` is session management, not packaging. The whole point of packaging is that the session can continue without you at the keyboard.

