# Prove the bug, then ship the fix

**Time:** 25 minutes.

**What you do:** fix the bug you brought from prework, tests-first. Ship the PR.

**What you build:** a failing test that proves the bug, the smallest fix that passes it, and a shipped PR.

**The point:** pushing back is core work.

---

## Write the failing test and fix the root cause

- **Tests-first, root-cause-driven.** The failing test is what makes the fix checkable. Without it, the fix is a guess that happens to compile. Write the test first, watch it fail, then fix the cause, not the symptom.
- No plan mode here. On a trivial bug, plan mode is overhead.

> **Small fix, small test.** A trivial bug wants one failing test and a tight fix, not a suite and a refactor. If Claude starts spinning up plenty of tests, or the change creeps past the bug, that's sprawl. Steer it back to one test that proves the bug and the smallest fix that passes it.

Drop your bug after the colon.

{{prompt:fix-tests-first-1}}

## Read the diff and push back on a line

- The agent runs the loop; you read the result. The agent writes the failing test, watches it fail, fixes the code, watches it pass. Read the diff. If a line isn't what you'd have written, push back. Quote the line and say why. The agent yields if you push hard enough, so its agreement settles nothing. Whether your argument was actually better is your call.
- Your own wording matters. No pre-made prompt for the pushback. The compound step reads this session's scrollback, so your push-back is what becomes a rule.

## Interrogate the fix for a deeper layer

- When the agent says done, ask whether the change is the root cause or a layer above it. The first cut usually fixes what makes the test pass; the deeper cut asks whether the test was pointing at the right thing. Name what a deeper edit would touch and see what Claude defends. The exchange is where root-cause discipline shows up, not in the fix itself.

**Optional.** Skip if your test already pins the right behaviour and the fix does exactly that, nothing deeper to interrogate. Otherwise, ask Claude to interrogate the fix and name what's still surface.

{{prompt:fix-tests-first-2}}

**Optional.** Send only if the interrogation surfaced a deeper layer worth a second TDD pass.

{{prompt:fix-tests-first-3}}

**Optional.** Once the fix is in, dig into Claude's view of code quality and structure. Ask Claude: *did you make it better? Why yes. Why no.* You steer; might take a few nudges.

## There is always a next plausible answer

- You can always dig deeper on the root cause with the LLM. There will be a next plausible answer, because the LLM will always try to find what you asked for. A passing test you trust is what makes a layer real; when to stop digging is your call.

## Ship the PR

- How far you let Claude drive Git is your choice. Ask Claude to commit, push a branch, and open the PR.

**What happened:** A real PR shipped. A failing test landed in the codebase before the fix did. The diff got read, at least one line got pushback, and the root-cause interrogation ran before the second TDD pass.

*For those finishing early: chatter about making sure the LLM doesn't fake tests or write tests that just pass. How do you catch that efficiently?*

