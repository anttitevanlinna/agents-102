---
key: ae101-m2-name-what-moves
dest: Claude Code
runtime: any
---
Check out ./CLAUDE.local.md and the repository ./CLAUDE.md. If any parts appear that would be better moved into a skill, name the parts. Or none, if nothing appears that way.
