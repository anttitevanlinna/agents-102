---
key: agent-loop-raw-2
dest: Claude Code
runtime: any
---
How do you, as an LLM, know what tools to use?
