---
key: close-the-ticket-3
dest: Claude Code
runtime: any
origin: exercises/close-the-ticket
requires:
  - id: ticket-summary
    source: prompt:close-the-ticket-1
  - id: shipped-bug-fix
    source: external (shipped by body prose at exercises/fix-tests-first § Ship the PR, which runs on every path; both fenced TDD prompts above it are Optional)
produces:
  - id: ticket-close-out
    location: external (ticket updated by the agent where it can reach the tracker, otherwise pasted by the student)
    consumed-by: []
    note: terminal artifact — the closed ticket lives in the team's tracker, not the training corpus
---
Update the ticket: short close-out note naming what the root cause was and how we fixed it, link to the PR if you opened one (otherwise link the branch). If we needed to create the ticket just now, create it first, then update. Tell me what you wrote.
