---
key: ae101-m5-rerun-packaged
dest: Claude Code
context: final move of the module
runtime: any
---
Before you start, write a protected block at the top of `plan.md` headed `Run coordinates (do not rewrite or remove)`, holding this session's `m5/` branch exactly as `git branch --show-current` reports it (read it back from git — don't retype it from memory) and this session's transcript path (under `~/.claude/projects/`, keyed by the `CLAUDE_CODE_SESSION_ID` environment variable). You'll mutate the rest of plan.md as you run; leave that block alone. Confirm the `.jsonl` exists before writing it; if you can't determine the path, stop and tell me rather than guessing.

Then ask for or write anything else you want for the session.

Run the task at `./task.md` using the packaging in this worktree: the reference, plan.md, and the verifier. The reference and plan.md sit together in a task-scoped folder; find them by listing the worktree. plan.md names how to invoke the verifier.

Rules: run the verifier per plan.md cadence; don't paper over failures; if you get stuck, write into RUN-NOTES.md and try a different angle; I'm walking away.

Report back as three lists, no narrative, no hedging:
  shipped — each artefact + path
  did NOT ship — each item, no "partial" / "mostly" / "in progress"
  verifier — last output line of each run, pasted verbatim
If any list is empty, say "none."
