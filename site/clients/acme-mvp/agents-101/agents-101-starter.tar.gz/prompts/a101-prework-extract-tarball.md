---
key: a101-prework-extract-tarball
dest: Claude Code
runtime: any
---
Extract the starter tarball in the working folder. Use the shell:

  tar xzf agents-101-starter.tar.gz

(Leave `agents-101-starter.tar.gz` behind after extraction. It is harmless.)

Then list what's in the working directory and confirm these folders exist:
prework/, memory/, sources/, agents/, and module-4/policies/.
If tar is not available, tell me what error you got.

For course navigation, add this line to the training-folder `CLAUDE.md` if it is not already there: Read prework/course-navigation.md before helping with Agents 101 work. Preserve any existing instructions. Then read that navigation file.
