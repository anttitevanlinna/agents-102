# Compound and *close the loop*

**Time:** 15 minutes.

**What you do:** let Claude review the whole session and write your `./CLAUDE.local.md` from session evidence. Push back where it misread.

**What you build:** a rules file written from session evidence. Concrete, specific, yours, and read at the top of every future session in this repo.

**The point:** every push-back is a hint toward your own rules.

The PR shipped and the ticket is closed. Now compound the session, the closing step of compound engineering. No retro questionnaire: the session is the evidence.

## Write your rules file from the session

- Claude reviews the whole scrollback in one shot and drafts your rules from how you actually worked.
- You are not drafting from a blank page. The agent reads the session for you.
- The tracker conventions count as evidence too. The field rules you read off your own ticket are in this scrollback, and this is where they land on disk.

> **Long session, long read.** If the review stalls or runs past a couple of minutes, interrupt with `Esc`, narrow to the orient and introspect phases first, and say `continue`. It fails the other way too: a summary that arrives fast and reads clean has usually covered the last few turns and skipped the rest. If nothing in it comes from the early part of the session, a `"there's more here"`-prompt buys another pass.

{{prompt:compound-and-close-1}}


## Push back where the summary misreads

- Read Claude's summary. Push back where it misreads. Quote the specific session moment back at Claude.
- The rules file is yours now. Born from the session, evolved over time.

## Keep or revert the `.gitignore` edit

- If `CLAUDE.local.md` wasn't already ignored, the compound step added it to your `.gitignore`. That is an uncommitted change now; commit it, or drop it.

## Sweep the session into your rules file one more time

- One more pass before close. Anything earned since the first compound pass at the top of this exercise (the push-backs, the rules you rewrote) that didn't land yet?
- A heads-up that you are about to compact or end the session flushes out work in progress. Claude writes down what it was still holding.

Ask Claude to sweep the session for anything earned since the first compound and integrate.

{{prompt:compound-and-close-4}}

> **The escape hatch is deliberate.** The closing `or "nothing new" if nothing did` allows Claude to report an empty sweep. Ask only what it added, and the agent finds something to have added.

## Close the session

**What happened:** One rules file, written from how you actually worked rather than from a template.

Whether it earns its keep shows up the next time a session reads it.

