# When a plan is good

**Session** *(new, "Module 2 - Plan mode done right")*

```
/rename m2-plan-mode
```

## Ask plan mode what changed

Enter plan mode, then put the question to your own session:

{{prompt:when-a-plan-is-good-1}}

## Five things a good plan has

- **A specific file list.** Not "update the config." *Which* config, *which* keys. A plan that names three files has made three decisions. A plan that says "the relevant files" has made zero.
- **An early runnable slice.** Find the first step after which something runs end-to-end. A plan that builds layer by layer (data, then services, then UI) answers "the last one," and every wrong guess stays hidden until then. A plan that stands up a thin end-to-end slice early gets checked by reality from step two onward.
- **A verification step** that could actually fail. *"Run the tests"* is cosmetic; *"run `pytest tests/auth/ -k hash` and expect 14 passing, 0 failing"* is a gate. The test is whether, reading the step alone, you could tell Claude it failed and Claude would know what to fix.
- **Named assumptions.** Good plans flag what they're assuming (library versions, schema shapes, whether a teammate's migration ran last week). A plan without assumptions isn't assumption-free; it's just assumption-silent.
- **A list of non-goals.** What the plan will *not* touch. Every adjacent improvement looks helpful, so the agent does the ones you never ruled out. (Dex Horthy)

## Three pressures that make bad plans look good

- **Structure is persuasive.** A 7-item plan with section headers and bold text looks like a decision. It's often just a draft formatted like a decision.
- **Reasonableness passes for rightness.** Each step sounds reasonable, so the plan sounds right. But reasonable steps in the wrong order, or with one missing, still ship a bug. Judge what the steps add up to, not how each one reads.
- **You already agree with it.** The plan matches what you'd have written, which feels like alignment. But it was written from a partial read of the codebase, and your instinct is not a check on it. Read it assuming something in there is wrong; there usually is.

## Plan review is a high-leverage gate
<!--tier:2-->

- A plan is a check before implementation. One correction can redirect every step that follows before the agent turns the plan into code.
- What the plan doesn't decide, the agent decides mid-run, inside work in flight, and you will not notice. A wrong call propagates across files, and the wrongness tangles with everything built after it: what would have been a line edit in the plan becomes an untangling job in the code.
- Aim the read at the unknown that teaches you the most. The branches worth walking are the ones that change what done means. The rest you'd settle in verification anyway.

## What you can test and check sets your complexity ceiling
<!--tier:2-->

{{figure:delegation-frontier}}

- Every task you hand off sits on two axes. Reach is how much you delegated: the size of the task, the distance between checks. Calibration is whether your trust in what came back was earned by a check you have verified.
- The plan read is a calibration move. It is cheap, it runs before anything is built, and its cost does not grow with the size of what you approved.
- Reach without calibration is what the three pressures produce: a plan that reads well, approved at a scope your read never actually covered.
- Push reach past what you can check and you have not delegated more. You are checking less.
- The ceiling is not fixed. Every check you make cheap and repeatable raises it, so building a better check buys you more than approving a bigger plan.

