# Lecture: Self-consistency after the scoreboard

The benchmark you just ran asked one question: *is this claim grounded in the evidence?*

Self-consistency asks a different question: *if the agent writes the briefing again from the same evidence, what stays stable and what drifts?*

That is useful, but it is not the yardstick. A claim can be stable and still unsupported if both runs repeat the same bad assumption. A claim can be grounded and still be phrased differently. Drift is a warning signal, not proof of fabrication.

This is why self-consistency sits after the scoring, not inside the scoring panel. The scoreboard tells you which groundedness detector earned the judge file. Self-consistency is a teacher demo that shows another shape of uncertainty: the model's answer may not be reproducible even when the evidence surface stays fixed.

The trainer can demo this live. Students can run the prompts too, but they do not need the artifact to complete Module 5.

**Prompt: regenerate the briefing** *(Claude Code)*

```
Spawn one subagent to generate a second briefing from the same evidence surface.

The subagent reads:
- `./crux.md`
- `module-5/evidence-roster.md`
- the rostered evidence files named in `module-5/evidence-roster.md`

The subagent must NOT read:
- `module-5/briefing.md`
- `module-5/claim-pool.md`
- `module-5/adjudicated-claims.md`
- `module-5/scoreboard.md`
- anything in `module-5/detectors/`

Write a one-page briefing on the same challenge to `module-5/briefing-second-run.md`.

When the subagent finishes, do not summarize the briefing in chat. Only confirm that `module-5/briefing-second-run.md` exists.
```

**Prompt: compare the two runs** *(Claude Code)*

```
Compare the first and second briefing.

Read:
- `module-5/briefing.md`
- `module-5/briefing-second-run.md`
- `module-5/claim-pool.md`
- `module-5/adjudicated-claims.md`

Write `module-5/self-consistency-demo.md` with these sections:

1. Stable claims: claims or recommendations that appear in both briefings and are supported by the adjudicated claims.
2. Drifted claims: same topic, but different number, named entity, recommendation, causal explanation, or framing.
3. First-run-only claims: claims from the first briefing that disappeared in the second.
4. Second-run-only claims: claims from the second briefing that did not appear in the first.
5. Self-consistency issues: claims that are both unsupported or partly grounded AND unstable across runs.

End with three lines:
- What self-consistency caught that the groundedness detectors did not.
- What self-consistency cannot prove.
- Whether the winning groundedness judge should change. Default answer should be no unless the demo shows a concrete failure class the judge can actually detect.
```

The take-home move is not "always run self-consistency." The take-home move is: benchmark the check before you trust it. Point the same benchmark shape at a customer email, a pricing memo, a positioning draft, anything about to ship.

**Prompt: reuse the benchmark shape** *(Claude Code)*

```
I have output I want to quality-control against fabrication. Set up a benchmarking system for me using these four techniques:

- Source triangulation: does every specific claim appear in at least one evidence file?
- Entailment: does the output say more than the evidence supports?
- Citation integrity: when a citation is made, does the evidence file actually contain the claim?
- Counter-evidence search: actively look for sources that contradict each claim, not just ones that support.

Keep the techniques that fit my output; swap any that don't for methods that catch my output's specific failure modes.

Ask me what output I want to check, where my evidence lives, and what short filename to use under `judges/`. Then build me a 30-claim pool, four detectors, and a scorer that adjudicates the claims and picks a winner. Save the final judge under the filename I gave you in `judges/`.
```

**Time:** 8-10 minutes if demoed live; 3 minutes if taught as contrast only.

