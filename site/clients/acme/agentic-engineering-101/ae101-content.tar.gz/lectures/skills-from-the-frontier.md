# Skills from the frontier, skills of your own


---

Two moves today. You're going to INVOKE two curated skills this module: one for access-control analysis, one for STRIDE threat modeling. Then you're going to AUTHOR one skill yourself: a test-strategy skill tuned to your codebase. Not written for you. Written by you, in conversation with Claude.

That split isn't accidental. It's a claim about what you can produce well on a Tuesday afternoon and what you can't.

## What's a skill, one breath

A skill in Claude Code is a named, scoped capability the agent can invoke. A markdown file with a frontmatter header and a set of instructions, living in `.claude/skills/<name>/SKILL.md` (or equivalent team-kit home). The second-pass walk-down you ran in Module 2, where Claude asked you one question at a time about unresolved branches, was patterned on Matt Pocock's `grill-me` skill (Socratic requirement elicitation, MIT-licensed, on his GitHub). It landed as a plain prompt in M2 because skills hadn't been introduced yet as a primitive. Today you invoke two more curated ones and author one of your own.

Skills are how agentic knowledge compounds across teammates. A Slack thread about "how to threat-model our webhook paths" dies in 48 hours. A STRIDE skill tuned to your stack lives as long as the repo.

## The three voices in play today

**Voice one: security practitioners.** The two security skills you'll invoke didn't spring from nowhere. STRIDE is Loren Kohnfelder and Praerit Garg's 1999 Microsoft memo (yes, that old; threat modeling predates most web frameworks you use). Adam Shostack sharpened it into a discipline in *Threat Modeling: Designing for Security* (2014); if you buy one security book this year, it's that. Access-control analysis threads back further. Saltzer & Schroeder's 1975 paper on the least-privilege principle is still the most-cited piece of computer security writing for a reason.

You invoke both on a feature you're shipping today. The judgement these skills compress doesn't have to be in your head for it to be in your hands.

**Voice two: you, right now.** The test-strategy skill you'll author has no curated version. Here's why: a good test strategy on your codebase depends on what you already know: which framework you use, where the flaky tests actually fail, what a "unit test" means in a system that talks to five external services, which regressions have historically slipped through review. Nobody outside your team can write that skill well. Curating it would be theatre.

You can. Because you'll author it the way the training authors everything: through conversation with Claude, not by hand-crafting markdown. Claude asks you what it needs to encode the skill. You push back where your codebase doesn't fit the default. The skill comes out tuned to your system because YOU fed it your system.

**Voice three: your skills folder, starting today.** The skill you author at the end of this module ships to your personal `~/.claude/skills/test-strategy/`. Auto-discovered in every session you run. That's the ship. Personal-first is the through-line: M1 was `CLAUDE.local.md` (personal, gitignored), M3 is your first authored skill in your personal kit. Promotion to a team home is the next move, not this one: a conversation with teammates, then a PR (to your repo's `.claude/skills/`, to a shared Git repo, to whichever home your team picks now or later). Intercom's 267-skill plugin repo (153 contributors, 31% of R&D, as of April 2026) was born that way: one engineer's personal skill, then a teammate's, then accretion. Not a platform-team design document.

## Why this proportion matters

Two curated, one authored. The ratio tracks a deliberate claim: *frontier practitioner moves are curated for you; you build what you know best, which is your own system.* Flipped the other way (three authored skills) and you'd be reinventing STRIDE on a Tuesday. Flipped the other way again (three curated skills) and you'd leave with no authored skills of your own, and the team kit wouldn't be born here. This proportion is deliberate.

## What "earn the trust" means

The module title isn't rhetorical. By the end of 1h45, you'll have three things your staff engineer and your CISO would actually read:

- A mapped access surface for the feature you're shipping (from access-control analysis skill)
- An ADR naming one hardening decision under STRIDE pressure (from STRIDE skill)
- A test-strategy skill that codifies how testing actually works on your system, shipped to the team kit

None of those are compliance artifacts. They're the thinking, written down. The word "trust" here doesn't mean "we followed a checklist." It means "the next engineer who touches this feature can see the thinking."

## What to watch for while you work

- **Exercise 1:** the access-control skill will flag surfaces. Your job isn't to agree; your job is to decide what it got right, what it underweighted, what it missed that you know matters.
- **Exercise 2:** STRIDE does the breadth, you make one call. Resist the urge to harden against everything. Pick one. Write the ADR.
- **Exercise 3:** when you author the test-strategy skill, Claude will offer you a generic test-pyramid default. Your codebase is not a pyramid. Push back until the skill reflects how your tests actually work.
- **Across all three:** skills live in specific places. The curated ones were installed as personal skills at prework, so Claude Code auto-discovers them by name. You don't point at a path. The one you author lands at the team-kit path your sponsor named. Don't invent new homes.

**Don't make general what you don't practice yourself.** That's the principle underneath the curate-vs-author split. The curated skills come from people who did the work; the one you author covers what only you do.

Go.

