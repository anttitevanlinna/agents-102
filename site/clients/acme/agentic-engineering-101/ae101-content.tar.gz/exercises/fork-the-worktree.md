# Fork the worktree, *carry the evidence*

**Time:** 15 minutes.

**Session** *(continue or new, "original repo")*

Run this from your original repo. If the session you sent off from is still open, ask it there. Otherwise open a fresh one in the same place.

**What you do:** fork a sibling worktree from the commit your un-packaged run started at.

**What you build:** a worktree holding the same code and the same rules the first run had.

**The point:** a worktree lets you run the same task twice as a split test.

---

## Phase 1: Fork it

*15 min*

- This module's work (diagnosis, verifier, reference, plan.md, and the re-send) runs in the worktree, so the second session starts from the same code state as the first.
- Gitignored files (your `CLAUDE.local.md`, `observations/`) don't ride into a worktree, because git doesn't see them. The setup prompt copies them across, so what you built in Module 1 and Module 4 comes with you. From there the worktree's copies compound separately. After Module 6 you decide what to merge back.
- Claude works out `<repo-name>` from the working directory. If it picks the wrong repo or path, steer it in chat.

Ask Claude to fork the worktree and copy your gitignored files across.

{{prompt:ae101-m5-worktree-setup}}

- Claude usually opens with a plan summary, then runs it. Skim past it.

## Check the copy landed

- The output should name both `CLAUDE.local.md` and `observations/` at the worktree path. A rules file that didn't copy changes two variables instead of one, and the contrast stops meaning anything.
- Look at the worktree yourself: `ls ../<repo-name>-m5/CLAUDE.local.md ../<repo-name>-m5/observations/`. A copy that silently skipped still reports as done.
- If your rules live somewhere other than the two paths Claude checked, ask it to copy that one across too.

## Anchor the fork to the run coordinates

- The agent normally reads the protected `Run coordinates` block in `task.md`, uses the `m4/<slug>` branch named there, and forks from that branch's "M4 starting point" commit.
- If that block is gone or the commit message was rewritten, use the starting-point SHA Claude reported before the send-off rather than guessing from branch names.
- If you never captured that either, ask Claude to run `git merge-base m4/<slug> <the branch you cut it from>`. That is where the branch left the trunk, a commit or two before the run started, carrying the same code.

