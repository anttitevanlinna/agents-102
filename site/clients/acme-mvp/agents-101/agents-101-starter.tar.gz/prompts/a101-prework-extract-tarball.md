---
key: a101-prework-extract-tarball
dest: Claude Code
runtime: any
---
Download the starter tarball into the working folder and extract it. Use the shell:

  curl -fLO <CONTENT_URL>
  tar xzf agents-101-starter.tar.gz

If `agents-101-starter.tar.gz` is already in the folder, skip the download. If curl gets a 401, ask me for the username and password and retry. If curl cannot reach the internet, say so in one line and wait: I will download it in my browser and drag it into this folder.

(Leave `agents-101-starter.tar.gz` behind after extraction. It is harmless.)

Then list what's in the working directory and confirm these folders exist:
prework/, memory/, sources/, agents/, and module-4/policies/.
If tar is not available, tell me what error you got.

For course navigation, add this line to the training-folder `CLAUDE.md` if it is not already there: Read prework/course-navigation.md before helping with Agents 101 work. Preserve any existing instructions. Then read that navigation file.
