# Workflow composition lineages

Five live lineages of practitioner thinking on how to compose agentic workflows. They diverge on the load-bearing details, even when the surface vocabulary looks similar. This walk names what's distinctive about each, where to start reading, and what a practitioner running each lineage actually ships.

The field is mid-evolution. Treat this as a map of conversations to track, not a ranking. Most practitioners running real work today are picking up moves from two or three of these lineages and ignoring the others.

## Klaassen lineage: file paths as the contract

Distinctive move: composition is wired by file paths, not by in-context handoffs. The plugin's composite chains `ce-plan` → `ce-work` → `ce-code-review` → `ce-compound`. Each step writes its output to disk (`docs/plans/<slug>.md`, `docs/solutions/<slug>.md`). The composite records the path and passes it as a literal argument to the next step. Progress lives in git; the orchestrator never re-reads contents into its own context. Every seam between steps is a hard gate: *"STOP. Verify that the plan file exists in `docs/plans/`."* The gate is implemented as a file-existence or `git status` check.

The closure step is explicit. `ce-compound` writes structured docs with YAML frontmatter validated against a schema. Klaassen frames `ce-compound`'s job as recording the lesson so the next agent uses it, not re-derives it.

What's missing or contested: Klaassen's own byline is thin in the last six months. Current write-ups are mostly third-party. The plugin itself carries the load.

**Read:**
- [Compound Engineering plugin (`EveryInc/compound-engineering-plugin`)](https://github.com/EveryInc/compound-engineering-plugin) — start with the README's named slash commands (`/ce-plan`, `/ce-work`, `/ce-code-review`, `/ce-compound`), then walk the corresponding skill files. The plugin ships dozens of skills and review agents; the wiring shape repeats.

## Cherny lineage: phase pipeline across worktrees

Distinctive move: subagents per phase, run in parallel across multiple git worktrees. Named subagents like `code-simplifier`, `verify-app`, `code-architect`, `build-validator`, `oncall-guide` live in `.claude/agents/`. A composite slash command (`/go`) calls them in sequence: spec → draft → simplify → verify. Cherny frames it as coding-as-a-pipeline-of-phases, each phase served by a different specialised mind. He runs five tabs, each its own git checkout, plus a handful of web Claudes with `teleport` to hand work between web and local.

The closure step is informal. Each successful loop refines `CLAUDE.md` by hand. Lower formality than Klaassen.

What's missing: the actual `/go` and subagent files are not public. The canonical page names them and describes what they do, but doesn't show them. Community forks carry approximations. If you want a verbatim Cherny kit, it doesn't exist yet.

**Read:**
- [How Boris uses Claude Code](https://howborisusesclaudecode.com/) — the canonical document; names the subagents and describes the `/go` composite.

## Pocock lineage: weakly coupled toolkit

Distinctive move: small skills, no orchestrator, no DSL, no required chaining. The human picks which skills to invoke and in what order. Composition happens at runtime in the chat, not in a composite skill file. Pocock's framing is rails not chains: each skill stays standalone and copy-pasteable, the human picks the chain at runtime. Each skill is 50 to 200 lines of plain English. Copy one into a different agent and it still works.

The closure step is per-repo, not per-session. `setup-matt-pocock-skills` runs once per repo and writes config files (`docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`) that other skills read. The memory is the repo-shape config, not the session lesson.

What's contested: Pocock is the explicit anti-position on heavy composition frameworks. If your work pulls you toward orchestrators and DSLs, his stance is *don't*. Worth reading even if you end up rejecting it.

**Read:**
- [mattpocock/skills](https://github.com/mattpocock/skills) — read `to-prd`, `to-issues`, `handoff`, `write-a-skill`. Notice what's missing: no `compose` skill, no orchestrator, no main entry point.
- [setup-matt-pocock-skills](https://github.com/mattpocock/skills/blob/main/skills/engineering/setup-matt-pocock-skills/SKILL.md) — the per-repo config scaffolder; other skills read what this writes.

## Cognition lineage: single writer with advisor agents

Distinctive move: only one agent writes. Other agents advise. The orchestrator integrates advice into the single writer's next turn. This is a hard evolution from Cognition's 2025 *Don't Build Multi-Agents* stance, restated by Walden Yan in April 2026's *Multi-Agents: What's Actually Working*. They tried parallel writers; conflicting implicit choices (style, edge cases) broke the work. Parallel reviewers feeding a single writer did not.

The closure step: advisor agents return *intelligence contributions*, not actions. Yan reports *"Devin Review catches an average of 2 bugs per PR, of which roughly 58% are severe"* — logic errors and missing edge cases the writer agent would otherwise ship. The single writer integrates. Closure happens in the writer's working memory; no separate compound skill.

What's distinctive about the lineage stance: tightly-coupled, sequential, and shared-state work is named as anti-pattern for multi-agent. The work the advisor agents handle is research and review. Distribution of writing is what broke.

**Read:**
- [Multi-Agents: What's Actually Working](https://cognition.ai/blog/multi-agents-working) — the evolved 2026 position.
- [Don't Build Multi-Agents](https://cognition.ai/blog/dont-build-multi-agents) — the original 2025 stance; pair with the evolved post for the trajectory.

## Amp lineage: composition primitives as built-ins

Distinctive move: the composition primitives are vendor-shipped, not user-authored. Sourcegraph's Amp ships `/handoff`, Feedback Loopable, and sub-agents as first-class. `/handoff` analyses the current thread, generates a goal-specific prompt for a new thread, identifies relevant files, and presents an editable draft. Compaction was the previous move; handoff replaces it because compaction is lossy. Feedback Loopable is three-part: Playground (shared agent-human env) + Experiments (URL-encoded reproducible state) + Verification Loop (headless CLI text feedback over screenshots).

What's distinctive: this lineage trusts the vendor with the primitive design. If Amp ships a better `/handoff` next month, the user gets the upgrade. The Klaassen and Pocock lineages keep their primitives in their own Git; Amp asks you not to.

What's contested: the lineage is platform-specific. Most of the moves don't translate cleanly to Claude Code or Cursor. Read it for the architectural shape, not the verbatim primitives.

**Read:**
- [Handoff](https://ampcode.com/news/handoff) — the canonical post on replacing compaction with goal-specific thread handoffs.
- [Feedback Loopable](https://ampcode.com/notes/feedback-loopable) — three-part composition: Playground + Experiments + Verification Loop.

## Ronacher, the counter-voice

Ronacher is not running a composition lineage. He's arguing against one. His core claim, from *The Final Bottleneck*: *"If the machine writes the code, the machine better review the code at the same time."* But review bandwidth is a human constraint, and composing more primitives doesn't relax it. Composition throttles inflow; it doesn't multiply throughput.

Ronacher keeps his own skills disposable. *"I throw skills away if I don't need them."* No marketplace, no Git-checked-in kit, no orchestrator. The artefact of his work is the shipped code, not the rules that produced it.

The reason Ronacher matters: any composition teaching that doesn't carry his argument alongside is teaching the move and silently teaching its decay. Composition fluency erodes review discipline. Willison flagged the same pattern, calling it *normalization of deviance*. If you're going to compose, the question Ronacher forces is *what's your review bandwidth?* If the answer is *the same as last year*, composition is not yet a multiplier.

**Read:**
- [The Final Bottleneck](https://lucumr.pocoo.org/2026/2/13/the-final-bottleneck/) — review bandwidth as the constraint composition can't relax.
- [Agent Psychosis: Are We Going Insane?](https://lucumr.pocoo.org/2026/1/18/agent-psychosis/) — Ronacher's stance on unstructured composition loops.
- [Pi: The Minimal Agent Within OpenClaw](https://lucumr.pocoo.org/2026/1/31/pi/) — where the "throw skills away" posture is named directly.

## How to pick what to study

Three filters that work better than ranking:

1. **What shape is your real work?** If you're shipping multi-file engineering changes with clear phases, Klaassen or Cherny lineage will resemble your day. If you're doing research and review, Cognition. If you're building lots of small things and want the kit to stay light, Pocock. If your team has standardised on Amp's runtime, that lineage by default.

2. **How much orchestration do you want to author?** Klaassen is heavy on orchestration (gates, schemas, composite skills). Pocock is light (human picks the chain). Cognition is somewhere in between. Pick the load you'll actually maintain.

3. **What review bandwidth do you have?** Read Ronacher first if the answer is *not much*. Composition without review is the failure mode he names.

Two or three practitioners is enough to track. Watch what they ship, not what they prescribe. The composition conversation will keep moving. The shape of work each lineage handles is the slower-moving signal.

