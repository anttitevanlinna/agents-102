# Exercise: Map the access surface

**Session** *(new, "Module 3 - Earn the trust")*

Start a new Claude Code session at your repo root.

```
/rename m3-access-surface
```

**What you do:** Invoke the curated access-control analysis skill on the small feature you brought to Module 3. Read what the skill surfaces. Decide, on the record in your repo, which surface it called out harder than you would have, and which surface you know matters that the skill didn't catch. Ship the delta as notes the STRIDE exercise will consume next.

**What happened:** The access-control analysis skill runs a structured pass across the feature: user boundaries, trust boundaries, data flows, tool/connector calls, external integration points, authorization checkpoints. It produces a surface map. You read it against your own knowledge of the feature and decide what's missing or wrong. Your delta is the artifact, not the raw skill output.

**The point:** STRIDE without an access-surface map is pub-quiz threat modeling. Before you threat-model, you map what you're protecting. The curated skill does the breadth; you own the codebase-specific judgment that the skill can't have.

**Time:** 20 minutes.

---

## Phase 1: invoke the skill

Start a new Claude Code session at your repo root. The `access-control-analysis` skill was installed as a personal skill during prework, so Claude Code auto-discovers it by name.

First, see what skills your Claude has loaded. In the Claude Code chat, type:

```
/skills
```

You should see `access-control-analysis` and `stride` listed under **User**. (If they don't, the prework install didn't land, see prework Step 4.) The Project list is whatever this repo ships; User is your personal skills. Skills you author later in M3 will land in User too.

Then ask Claude to fill in what `/skills` doesn't show.

**Prompt** *(Claude Code)*

```
List my installed skills. Tell me also their storage location and whether or not they are loaded onto context.
```

Worth a moment of looking, these are the moves Claude has on hand for the rest of this module, and the load-on-invoke behavior matters for context economy later.

Ask Claude to invoke the access-control-analysis skill on the feature you'll name after the colon, and save the surface map to a temp directory.

**Prompt** *(Claude Code)*

```
Invoke the access-control-analysis skill on the feature I'll name. Save the surface map to a temp directory and tell me the path. Use the skill's default output shape; don't prompt me to customize.

The feature is:
```


Answer the one-sentence feature question. Let the skill run. It'll read the code, walk the surfaces, and produce the map. You watch.

## Phase 2: walk the map in conversation

Ask Claude to walk you through the surface map in chat (categories, key findings, ambiguous spots) so you've seen the structured read before deciding your deltas in Phase 3.

**Prompt** *(Claude Code)*

```
Read the surface map you wrote at the path you told me. Walk me through it in chat: what categories of surface you found, the two or three findings that stood out most, and any surface you flagged as ambiguous. Concise — this primes me for the deltas I'll tell you in the next phase.
```

## Phase 3: write the delta

Now you decide.

Ask Claude to integrate the surface the skill called out harder than you would have into the map.

**Prompt** *(Claude Code)*

```
Update the surface-map file in the temp directory to integrate the delta below — pull the item to the top of its category and explain in one line why this codebase's deployment model elevates it. Show me the diff.

The surface the skill called out harder than I would have:
```

Then ask Claude to add the surface the skill missed but you know matters.

**Prompt** *(Claude Code)*

```
Add a new surface to the map that the skill didn't catch but matters in this codebase. One sentence on what it is, one sentence on why the skill missed it (likely codebase-specific: framework, deployment model, team convention). Show me the diff.

The surface the skill missed that I know matters is:
```


Answer. Push back on the sharpening question until the reason names something specific to your codebase. *"The billing webhook re-hits the queue on retry, so the same event gets reprocessed"* beats *"webhooks need auth."*

## Phase 4: handoff check

You're about to hand this map to the STRIDE skill. Glance at it. If a teammate landing on this file cold would miss something the map assumes you know, add a one-line context header. If it reads, close.

Most people skip this. Some want the pause. Your call.

---

## What this sets up

The STRIDE exercise invokes the curated STRIDE skill on the map you just built. The surface map IS the input. If you rushed Phase 2, STRIDE will threat-model a thin map; if you sat with it, STRIDE has something real to chew on.

