---
key: eval-loop-6
dest: Builder Claude
runtime: any
origin: exercises/eval-loop
requires:
  - id: eval-loop-inputs
    source: student-input
produces:
  - id: reusable-eval-loop
    location: student-selected working folder
---
Set up a fixed-judge loop for one of my outputs.

Run the loop end to end:
1. Write a generation tactic file that a generator subagent can read.
2. Dispatch a generator subagent to produce the output from that tactic.
3. Dispatch a separate judge subagent to run the fixed judge and write per-claim or per-item feedback alongside the score.
4. The main session reads the judgment and rewrites the same generation tactic file in place before the next round. Do not create versioned copies.

Run at least three rounds. After round 3, keep going until improvement is no longer significant.

Never edit the judge file. At the end, write notes with the score trajectory, the generation-tactic changes, the judge-integrity check, why the loop stopped, and the next boundary case to test.

Use these inputs; no preamble, start by writing the first generation tactic file:
