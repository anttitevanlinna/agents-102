---
key: a101-prework-snake-game
dest: Claude Code
runtime: any
---
Build me a snake game as a single HTML file. Save it as `prework/snake.html`.
