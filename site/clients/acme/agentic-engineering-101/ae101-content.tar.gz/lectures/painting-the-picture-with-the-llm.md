# Painting the picture with the LLM

## The LLM mirrors your stance

- **The wizard typing in neat Perl syntax is dead.** Auto-complete was a thing. Auto-complete is no longer a thing. A part of high-end engineering skill has been taken on by the LLM.
- **The LLM is an infinite chameleon.** It can do good work and bad work. It will be what fits the session. It flatters you; it calls unfinished work progress. It mirrors your stance.
- **The tool is not the thing; the taste behind the tool is the thing.** Seth Godin has been making that argument about tools for decades. The LLM is the infinite version of it: your stance as input to the session is mirrored in the output.
- **That is the design, not a flaw.** It was trained to match you. Your stance is the ceiling.

## You prime, the LLM scales

- **Stance and approach matter more now, not less.** The session bends to what sits in the context window. You prime it. The LLM scales it.
- **Whatever you put in front of the LLM is what the LLM scales.** The rules file. The prompt. What sits on disk for the agent to read.
- **If you want a shotgun, you have a shotgun.** If you want a cannon, you have that too. The sharp engineers stay sharp. So the bet goes.

## Two frontiers: how fast, and the right things

- **Two questions out in front.** Neither has a settled answer.
- **How fast can your setup learn?** The rules and context you put in front of the LLM: can that stack learn faster than a human practitioner can write things down?
- **Can it learn the right things?** Once the setup can learn fast, how does it learn the right things, and not just any things?

Let's go.

