# The wizard move

**Time:** 10 minutes.

You've already done the hard part. You found this training because you use Claude Code regularly and you want to get further with it. That's who this training is for. Nobody here needs the "agents can write code" setup.

So this training won't.

## Context is King

The same question. Two answers. What makes the difference?

Two Claude chat windows.

In one, the first prompt is *"What is the capital of Italy?"* Claude answers *Rome.* Then the second prompt: *"What should we have for dinner?"* Claude suggests something Italian: pasta, osso buco, risotto.

In the other window, the first prompt is *"What is the largest lake in Finland?"* Claude answers *Saimaa.* Then the same second prompt as before. Claude suggests something Finnish: salmon, rye bread, meatballs.

Same words. Different answer. The first exchange became context, and the context colored everything after.

Before you watch the second session run, take a guess. What will it suggest? Your guess reveals what you already know about how this works, and what you're about to learn.

One more window. The first prompt: *"I'm a cardiologist preparing dinner for my patients."* Then the same second prompt about dinner. The suggestion shifts again. Heart-healthy. Low-sodium. Vegetable-forward. Not because Claude knows medicine better than Italian cooking. You told it who you are, and every answer after took that into account.

Context is whatever you tell it. A fact. A role. A preference. A constraint. All of it colors what comes next. You, in a way, compel the right output by having the right stuff in the context.

That's the move. Not a clever prompt, not a slash command you didn't know. Loading the right context before the question. Everything else in this training is about how to earn the second window on any codebase, any Monday.

You'll watch what's *possible*. Not what's missing. That's the posture of this training.

## Where you're starting

You found your way to Claude Code by yourself. Maybe a colleague pointed you at it. Maybe you watched a video. Mostly you just typed something, watched what came back, and kept the prompts that worked. You picked up tricks nobody taught you. The slash command that saves keystrokes. The `CLAUDE.md` shape that produced output you liked. The weird thing you tell Claude at the start of every session.

Every engineer who sat down with this tool did some version of that. The trick you brought to Connections is your slice of partial; everyone else's slice is different. This training pools partial into a shared floor, then raises the ceiling. The people building this are partial too. Six months ahead of you on some moves, six months behind on others.

## What you'll do today

Fix one trivial bug from your own backlog, end-to-end, with plan mode used deliberately. Log one decision. Seed a rules file your next session reads first. The bug is the vehicle; the loop is the cargo.

You become the Claude wizard by running the loop on real work and letting the habit sharpen. Not by reading about it.

