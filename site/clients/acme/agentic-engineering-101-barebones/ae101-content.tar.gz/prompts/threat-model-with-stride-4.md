---
key: threat-model-with-stride-4
dest: Claude Code
runtime: any
---
Will ADRs auto-load to future sessions?
