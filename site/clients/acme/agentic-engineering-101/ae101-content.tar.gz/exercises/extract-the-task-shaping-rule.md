# Codify the rules, place the file

**Time:** 20 minutes.

**What you do:** surface task-shaping rules from the session you just ran, then read more off one story ticket.

**What you build:** rules and guardrails for future agents that shape tasks the way you would.

**The point:** find a place for your rules.

---

## Phase 1: Codify the rules from this session

*8 min*

- The rules are already in the session, unwritten; codifying them is the work.
- The agent reads the scrollback; you react to what it proposes. The scrollback is the right source here: the question is how you worked, not what is on disk.

Ask Claude for the rules.

{{prompt:extract-the-task-shaping-rule-1}}


## Reject or rewrite the generic rule

- The rule that arrives generic, like "pick tasks that span multiple files," is the one to rewrite in your words, or reject.

## Read more rules off one story ticket

- The same move you ran at M1 on a bug ticket, pointed at a story. How your team writes stories is a rule the tracker has been keeping, same as the bug fields were.
- If the task you brought came from your tracker, its own ticket is the one to read. Otherwise any real story works. One the agent just wrote carries none of your team's conventions.
- No tracker this session can reach? Paste the fields instead of the link.

Drop a story ticket link after the colon.

{{prompt:extract-the-task-shaping-rule-4}}

## Phase 2: Save the file where you want it

*4 min*

- Every session on this laptop (user-level), or only sessions in this repo (repo-personal).
- Claude knows the paths; the choice is yours.

Decide the location with Claude.

{{prompt:extract-the-task-shaping-rule-2}}


## Where rules can live, and when they load

| What | Where | Loads | To wire |
|---|---|---|---|
| CLAUDE.md files | user-level, repo, repo-local (gitignored) | every session | |
| Claude rules | `.claude/rules/` (repo) · `~/.claude/rules/` (personal) | every session; `paths:`-scoped ones on matching file reads | `paths:` frontmatter |
| Auto memory | `~/.claude/projects/<project>/memory/` | `MEMORY.md` index every session; topic files as needed | Claude writes it; *"memorize X"* to store, `/memory` to inspect |
| Skills | personal or repo skills folder | name and description every session; full body on invocation | author or install from a plugin marketplace |
| Roll your own | any path: a notes folder, an ADR directory | only when a prompt names it or Claude reads it | an `@import` line in an auto-loaded CLAUDE.md upgrades it to every session |

Roll your own is often facilitated by hooks and router skills: a hook injects it at session start, a router skill reads it when the work calls for it.

- If the picked path only loads when named, ask for the `@import` line before you move on. Without it the file sits unread.
- [Claude Code for engineers](../trainings/agentic-engineering-101/reference/claude-code-for-engineers.md) is the long form: precedence, walk-up, the managed layer.

## Phase 3: What this file could automate later

*3 min*

Ask Claude what this file could drive later.

{{prompt:extract-the-task-shaping-rule-3}}


## Read the shapes

- A shape you could use has a trigger and a place for your file in the loop. If Claude offers only one, ask for two more.
- Want the machinery? Ask about GitHub Actions, the Claude Code action, and Routines by name.

## Phase 4: Save the rule if it earned itself

*3 min*

Ask Claude whether these rules are auto-loaded into each session.

{{prompt:push-back-on-the-plan-4}}

If a branch from the second-pass read sharpened how plans get made in this codebase, ask Claude to integrate that one branch into your personal `./CLAUDE.local.md`. If no branch changed how you'd read the next plan, ask Claude to say so and stop.

{{prompt:ae101-m2-integrate-branch}}

> This prompt is fair to read as replacing the file with only this rule, which would nuke the old rules. After it runs, ask Claude to confirm it added the rule and kept the old ones rather than overwrote `./CLAUDE.local.md`. Precise prompting is harder than it looks. If it did overwrite, the old rules are still in this session's scrollback; ask Claude to restore them.

> Claude may reframe the session into a smart-sounding general rule. If the saved rule could apply to any codebase, ask for one specific to this session.

Feel free to jump straight to the diff in `./CLAUDE.local.md`; Claude's preamble is optional reading.

## Phase 5: Leave the repo tidier than you found it

*2 min*

The Boy Scout rule: leave the campground tidier than you found it. A rule in your file is one way to compound a session. Anything the plan tripped on is another, and it fixes things for everyone with nothing loaded.

- **Planning gaps.** A file the agent didn't know about, a convention it guessed. Write it down where the next planner will read it: the README, an ADR, the module's own doc.
- **Conflicting information.** Two docs that disagree, a comment that contradicts the code, an ADR nobody retired. Pick the truth and delete the rest.
- **Other context.** A missing test, a misleading name, a script with no usage line. The agent will trip on it again; so will a colleague.

Ask Claude whether it met any of these.

{{prompt:ae101-m2-tidier}}

