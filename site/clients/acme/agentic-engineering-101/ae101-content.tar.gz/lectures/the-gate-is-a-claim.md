# The gate is a claim too

Say the re-send comes back green. The verifier you built reads the work and passes it. That green is worth exactly as much as the gate behind it, and the gate is a claim too. On the map it sits in the far half, the last check before the work ships. It can lie in five ways.

## Passing is not proof

- A gate only means what the gate can see. Green is a claim about the check, not a fact about the work. A result passes for three different reasons that look identical from outside: the judge is miscalibrated, the gate got gamed, or the session was a lucky sample.
- The check you built is itself a claim that wants verifying. The same scrutiny you point at the agent's work points at the thing that judges the work. A gate nobody has verified is a gate trusted on vibes.
- Each way a gate lies has its own countermove, and each is cheap. Hand-labels for the miscalibrated judge, a hold-out for the gamed gate, repeated sessions for the lucky sample. All three cost less than the failure they hide.

## The judge needs calibrating against your labels

- A judge has an unknown floor until you measure it. A judge is a claim that its bar and your bar agree. Until that is checked against your own labels, a judge-gated pipeline passes work at an agreement rate no one has ever seen.
- The move is hand-label a sample, measure agreement, sharpen, repeat. A few dozen outputs is enough to start; you are looking for disagreement patterns, not a significance test. Grade them yourself, compare against the judge's verdicts, sharpen the judge prompt until the two converge, and re-check when the model or the task shifts. Hamel Husain reports better than 90% agreement after three iterations of exactly this loop.
- A good gate starts from real traces, not imagined failures. Read sessions that actually happened, sort the real failures into buckets, and write the first check for the biggest bucket. A gate built from the armchair catches the failures you pictured and misses the ones you have.

## Gates decay

- A measure that becomes a target stops measuring. **Goodhart's law**, and the agent is an optimizer aimed straight at your gate. Tests get special-cased, judge prompts get keyword-stuffed, asserts get edited into agreement. No malice needed: optimization pressure finds the cheapest path to green.
- Passing while missing the intent is a signature, not bad luck. When work clears the gate and still is not what you meant, the gate has decayed into a target. That is a reason to refresh the gate, not to shrug.
- The countermoves are a hold-out and an integrity check. Keep a check the agent never sees, so nothing can optimize against it. After a suspicious pass, inspect the gate itself (the test file, the judge prompt, the asserts), not only its verdict.

## One session is a sample

- The agent's behavior is a distribution, not a property. One green session is an anecdote with survivorship bias. Reachable and dependable are different claims: passing once shows the task is reachable, passing again and again shows it is dependable. The second collapses far faster than the first.
- Before crediting an improvement, run it repeatedly. A new rule, a new prompt, a new gate: judge it on pass rates across several sessions, not on the one session that followed the change. On a single session you cannot separate the change from ordinary session-to-session variance.
- A demo is pass-once evidence. An impressive session someone shows you proves the task is reachable, not that it is dependable. File it there.

## Change on recurrence, not on noise

- One stochastic miss is not a process failure. A system with session-to-session variance produces the odd miss even when nothing is wrong. Rewriting a rule after every single miss does not tighten the process, it churns it. W. Edwards Deming called this **tampering**: chasing ordinary variance case by case adds noise of its own.
- React on recurrence. The same failure shape returning is signal. That is when the rule changes, the gate refreshes, or the skill ships.
- Watch the regression-to-the-mean trap. After a bad session, the next session is usually better with no change at all. A tweak made right after a failure looks effective even when it did nothing.

A gate is one more claim in the system. Build it, then hold it to the same bar it holds the work to.

## The delegation frontier

<figure class="diagram">
<svg viewBox="0 0 1200 560" role="img" aria-label="A two-by-two map of delegated work. Horizontal axis: reach, how much you hand off. Vertical axis: calibration, whether trust was earned by a measured gate. Four states: chat-shaped work bottom-left, controlled assistance top-left, reckless autonomy bottom-right, calibrated agency top-right. A dashed ochre curve labelled the frontier rises from low reach at low calibration to high reach at high calibration, and moves outward as fast as the gates behind it." style="display:block;width:100%;height:auto;background:#efe6d2;border:1px solid #c5b68d;border-radius:7px;">
<rect x="0.5" y="0.5" width="1199" height="559" rx="7" fill="#efe6d2"/>
<rect x="12" y="12" width="1176" height="536" fill="none" stroke="#d6c8a3" stroke-width="1" opacity="0.9"/>
<rect x="650" y="270" width="500" height="200" fill="rgba(138,58,42,0.05)"/>
<g stroke="#d6c8a3" stroke-width="1" stroke-dasharray="2 8" opacity="0.8">
<line x1="650" y1="70" x2="650" y2="470"/>
<line x1="150" y1="270" x2="1150" y2="270"/>
</g>
<g stroke="#786c56" stroke-width="1.6" stroke-linecap="round">
<line x1="150" y1="470" x2="1140" y2="470"/>
<line x1="150" y1="470" x2="150" y2="80"/>
</g>
<g fill="#786c56">
<polygon points="1150,470 1138,464 1138,476"/>
<polygon points="150,70 144,82 156,82"/>
</g>
<text x="650" y="505" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#786c56">REACH · HOW MUCH YOU HAND OFF →</text>
<text x="125" y="270" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="10.5" letter-spacing="2.5" fill="#786c56" transform="rotate(-90 125 270)">CALIBRATION · TRUST, MEASURED ↑</text>
<g text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="12.5" letter-spacing="2">
<text x="400" y="150" fill="#2f6b6b">CONTROLLED ASSISTANCE</text>
<text x="400" y="400" fill="#2f6b6b">CHAT-SHAPED WORK</text>
<text x="800" y="150" fill="#2f6b6b">CALIBRATED AGENCY</text>
<text x="960" y="400" fill="#8a3a2a">RECKLESS AUTONOMY</text>
</g>
<g text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234">
<text x="400" y="168">small handoffs, tight review</text>
<text x="400" y="418">you read everything</text>
<text x="800" y="168">long leash, measured gates</text>
<text x="960" y="418">long leash, unmeasured green</text>
</g>
<path d="M 480,470 C 640,420 760,330 850,240 S 980,120 1020,70" fill="none" stroke="#a05a2c" stroke-width="2.4" stroke-dasharray="7 7" opacity="0.85"/>
<text x="935" y="205" text-anchor="middle" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="11" letter-spacing="2.5" fill="#a05a2c" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">THE FRONTIER</text>
<text x="935" y="221" text-anchor="middle" font-family="Inter, -apple-system, sans-serif" font-size="11" fill="#4a4234" paint-order="stroke" stroke="#efe6d2" stroke-width="3" stroke-linejoin="round">moves as fast as the gates behind it</text>
<line x1="880" y1="250" x2="945" y2="250" stroke="#a05a2c" stroke-width="1.8" stroke-linecap="round"/>
<polygon points="955,250 943,244 943,256" fill="#a05a2c"/>
<text x="650" y="533" text-anchor="middle" font-family="EB Garamond, Georgia, serif" font-style="italic" font-size="15.5" fill="#4a4234">The frontier: the largest task you can hand off and still trust the result.</text>
<text x="1176" y="36" text-anchor="end" font-family="ui-monospace, Menlo, Consolas, monospace" font-size="9" letter-spacing="2" fill="#8a3a2a">TWO AXES · FOUR STATES</text>
</svg>
</figure>

- Every task you hand off sits on two axes. Reach is how much you delegated: the size of the task, the length of the leash. Calibration is whether your trust in what came back was earned by a check you have verified.
- Four states fall out. Low reach is chat-shaped work or controlled assistance: you read everything, so trust is not the question yet. High reach splits on calibration alone. Calibrated agency when the gates behind the green are ones you have measured, reckless autonomy when they are not. From outside, the two look identical. The five ways a gate lies are the whole difference.
- The frontier moves outward only as fast as the gates behind it. Push reach past your calibration and you are not delegating more. You are checking less.

