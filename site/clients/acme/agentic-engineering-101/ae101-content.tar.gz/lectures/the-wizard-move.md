# The wizard move

## Context is King

Two fresh Claude Code sessions get the same dinner question and answer it differently. The first session opens with *"What is the capital of Italy?"* Claude answers *Rome.* The second prompt is *"What should we have for dinner?"* Claude suggests something Italian: pasta, osso buco, risotto.

The other session opens with *"What is the largest lake in Finland?"* Claude answers *Saimaa.* Then the same dinner prompt. Guess what Claude suggests before reading on.

Something Finnish: salmon, rye bread, meatballs. But not as reliably. The first exchange became part of context, and the context colored everything after.

## You steer the answer by loading context

Context is whatever you have told the session so far. A fact. A role. A preference. A constraint. All of it colors what comes next. You, in a way, compel the right output by having the right stuff in the context.

The move is loading the right context before the question, not a clever prompt or a slash command you didn't know.

