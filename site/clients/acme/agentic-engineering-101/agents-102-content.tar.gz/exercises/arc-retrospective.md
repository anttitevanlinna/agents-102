# Arc retrospective

**What you do:** Ask an agent to read everything you've authored across the training and write a one-page note on what changed. The agent names the arc from your own evidence, not a template.

**What happens:** You end with a short written note in your repo (ADR-shaped or a loose memo, your call) that names how your practice changed across the modules. Not a self-congratulation round, not a trainer monologue. A reading of your own artefacts by a fresh agent who has the patience to look at all of them at once.

**The point:** The throughline of the training is that everything is scaling of learning. Each module's loop is the same loop at a wider scope. That's only visible retrospectively, and only from your own artefacts. The agent's job here is to name the arc so you see it too.

**Time:** 15–20 minutes.

> **Quick timebox note.** The read across M1–M6 artefacts is wide; the beat stays short. One arc-reading pass, one push-back, save or drop. If the agent's note reads true, save. If it reads thin after one re-draft, drop. Dropping is not the soft option; it is a signal your artefacts did not carry the density the read needed. Note that and move on. No perfect note to chase. The arc is yours; the note is just the agent helping you see it.

---

Open a new Claude Code session in the M5 worktree (the same one M6 Phase 1 + 2 ran in). A fresh session, so there's no scrollback coloring the read. The artefacts across all six modules, `CLAUDE.local.md`, `.claude/memory/`, ADRs, both authored skills, both runs' commits and transcripts, are accessible via git refs and the worktree state. Ask the agent to walk them and write the arc from them.

**Prompt** *(Claude Code)*

```
Read my work across this repo. Specifically:

- My team `CLAUDE.md` (if present) and my personal `CLAUDE.local.md`.
- Everything at `.claude/memory/` (three-block memory: observations/hypotheses/rules, decisions, quality criteria).
- The ADRs in this repo — wherever our convention puts them (`docs/adr/` or equivalent).
- Both skills I authored at `~/.claude/skills/` (the test-strategy skill from earlier, and the skill I authored today).
- The M4 un-packaged run artefact (commits, files, the session transcript under `~/.claude/projects/` in a folder matching this repo — the earliest long-running run).
- The M5 packaged re-run artefact (commits, files, the session transcript from the re-send of the same task).

Run this audit in a fresh sub-task via the Task tool so you have the cold-read view, then combine those findings with insights you have from this session's scrollback. I want both viewpoints: the fresh read uncoloured by our conversation, and what you noticed while we worked together.

Write a one-page note on what changed across this body of work. Not a changelog. What shape did my practice have at the start, what shape does it have now, what specific artefacts show the shift. Quote from my files. Name the pattern that you see recurring across modules if you see one. Don't invent a pattern to make the note tidy; if the arc is uneven, say so and show where.

Propose where the note should live in my repo (ADR, memo in `.claude/memory/`, or a standalone file). Show me the note before you save it. I'll push back, then we save.
```


If the read runs ten minutes plus, interrupt with *"enough. just tell me now."*, you have what the agent has assembled so far, and that's the read.

Read the note. That's the read of your six modules from outside the work.

If the note reads true, save it. You'll have your agent re-read it when the next long task stalls.

