# Fix tests-first

**Time:** 25 minutes.

**What you do:** fix the bug you brought from prework, tests-first. Ship the PR.

**The point:** tests-first and root-cause-driven is one discipline. Running it with an agent is a second discipline: reading the diff, pushing back when a line is not what you would have written. Both get practised here. The compound move (writing down what you learned) lives in the next exercise.

You know what's loaded and what isn't. Now fix the bug.

No plan mode here. Plan mode pays off at Module 2 on multi-file work; on a trivial bug, it's overhead. The move is tests-first, root-cause-driven.

Ask Claude to write the failing test, fix the root cause, and show the diff. Drop your bug after the colon.

{{prompt:fix-tests-first-1}}


Claude writes the failing test, watches it fail, fixes the code, watches it pass. Read the diff. If a line isn't what you'd have written, push back. Quote the line and say why. Whoever has the better argument wins.

Your own wording and viewpoint is important here. Hence no pre-made prompt. You'll return to this at the compound step.

When Claude says done, push once on the depth. Ask whether the change is the root cause or a layer above it. The first cut usually fixes what makes the test pass; the deeper cut asks whether the test was pointing at the right thing. Name what a deeper edit would touch and see what Claude defends. The exchange is where root-cause discipline shows up, not in the fix itself.

**Optional.** Skip if the test you wrote already names the contract and the fix is the contract, no deeper layer to interrogate. Otherwise, ask Claude to interrogate the fix and name what's still surface.

{{prompt:fix-tests-first-2}}

**Optional.** Send only if the interrogation surfaced a deeper layer worth a second TDD pass.

{{prompt:fix-tests-first-3}}

Dig into code quality and structure. Ask Claude: *did you make it better? Why yes. Why no.* The goal is to make a neat and clean fix. Might need a number of nudges. You steer.

Ask Claude to commit, push a branch, and open the PR. How far you let Claude drive Git is your call.

**What happened:** A real PR shipped. A failing test landed in the codebase before the fix did. You read the diff, pushed back on at least one line, and ran the root-cause interrogation before the second TDD pass.

The PR is shipped. The move is warm. Hand off to the compound step.

*For those finishing early: chatter about making sure the LLM doesn't fake tests or write tests that just pass. How do you catch that efficiently?*

