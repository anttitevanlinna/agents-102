---
key: orient-and-introspect-2
dest: Claude Code
runtime: any
---
What did you read, and why those files? What didn't you read, and why not? Name the specific files or directories you skipped and the call you made on each.
