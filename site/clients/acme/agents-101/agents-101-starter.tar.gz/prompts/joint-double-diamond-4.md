---
key: joint-double-diamond-4
dest: Builder Claude
runtime: any
---
Reuse the exact participant subfolder where you wrote `context-manifest.md`. Read its `stance.md`, then read three to five neighbouring `stance.md` files from other participant subfolders in the shared folder.

Write `cross-check.md` in that same subfolder with:
- One thing another agent saw that my stance missed.
- One disagreement I keep after reading the neighbours.
- One evidence gap that appears across more than one stance.
- One idea I should carry into my proposal.
- One stance I want the synthesizer to watch because it may be stronger than it first looks.

Do not summarize every neighbour. Act like a serious peer reviewer with skin in the game.
