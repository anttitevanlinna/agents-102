---
key: ae101-m3-fork-quality-side
dest: Claude Code
runtime: any
---
Fork a sibling worktree. Default path `../<repo-name>-m3-quality`, default branch `m3/quality` off the current branch:

  git worktree add ../<repo-name>-m3-quality -b m3/quality

Copy the gitignored personal rules into the worktree so the new session inherits the same personal rules:
  cp ./CLAUDE.local.md ../<repo-name>-m3-quality/  (if it exists)

This won't sync back automatically. The worktree's copy is independent from this point.

Tell me the absolute path to the new worktree directory and which files copied across.
