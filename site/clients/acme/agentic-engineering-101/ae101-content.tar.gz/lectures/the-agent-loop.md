# The agent loop

## The agent, the harness, the loop

- An **agent** is an LLM calling tools in a loop. Four parts: the context it reads, the tools it can call, the goal it works toward, and the autonomy to pick its own next step. Each iteration the LLM receives context (system prompt, conversation, tool results) and either responds to you or uses tools.
- The **agent harness** is the surrounding code that runs the loop. It exposes tool definitions to the LLM, executes the tool calls, and feeds results back in. Claude Code is one harness; Cursor, Cline, Gemini CLI are others.
- The **agent loop** is that iteration itself. Prompt → reason → tool calls → results → reason again, until the agent decides to stop.
- A long-running session is this same loop, iterated. Out of the box, nothing new takes over when the session gets long; the loop keeps choosing the next step from context and tool results, hour after hour.

## See the loop in your live session

Three prompts. Dig into whatever catches you.

Ask for the loop as a diagram.

{{prompt:ae101-agent-loop-ascii}}

Ask what tools this session is carrying.

{{prompt:ae101-agent-loop-tools-list}}

Ask where that list comes from.

{{prompt:ae101-agent-loop-tool-injection}}

