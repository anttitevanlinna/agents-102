# Exercise: Extend your system

**Session** *(new, "Module 8 - Agents building agents")*

<span class="rt-code">Start a new Claude Code session at your training-directory root.</span><span class="rt-cowork">Start a new Cowork task with your training-directory root as the working folder.</span>

```
/rename m8-agents-building-agents
```

**What you do:**

You've been building agents for seven modules. Today you don't build one. You describe one, and the coding agent builds it. The tool that builds tools. The move stops being linear the moment you see it land.

Pick one extension to your system. Something you'd actually use from Tuesday onward. Not a demo. A real gap.

Three shapes to choose from (pick one):

- **New data source.** An agent that reads from somewhere your current system doesn't: a second wiki, a folder of PDFs, a connector you just enabled, a different team's `memory/`.
- **New output.** An agent that produces a shape you don't have yet: a one-page brief, a weekly digest, a pre-meeting prep note, a Slack-ready summary of something you usually write long-form.
- **New perspective.** An agent that reads the same memory but argues with it: a skeptic, a devil's advocate, a persona-agent that holds the view your own voice suppresses.

**Time:** 25 minutes. If you finish early, ship a second one.

**Phase 1. Describe (5 min).**

Open `module-8/extension-brief.md`. Write four lines, no more:

- The gap. One sentence. *"I don't have anything that does X."*
- The job it gets done. One sentence. *"On Mondays I need to Y; today I Z by hand."*
- What it reads. Which files, which `memory/` pages, which sources.
- What it writes. One file, named (or an output shape, described).

If the brief takes more than five minutes, your gap is too big. Narrow it.

**Phase 2. Generate (15 min).**

{{prompt:extend-your-system-1}}


**Phase 3. Run and judge (5 min).**

Claude ran your new agent. Look at the output. Don't read it to admire it. Read it to find the weakness.

Push back in chat:
- *"Cite the memory file for the second claim. That felt generic."*
- *"You used training data on line 4. Replace it or remove it."*
- *"The tone drifted from my other agents. Sharpen to match."*

One or two rounds of push-back. The artifact: a new agent in `agents/` that you trust enough to run again on Tuesday.

**What happened:**

You described. The tool built. You judged. The cycle took 25 minutes. The second agent next week will take ten. Same tool, less describing, because your vocabulary for what you want is sharper. That's the compound.

**The point:**

The seven modules taught you to be a builder. Module 8's first move is watching the builder disappear. You become the describer; the agent becomes the builder. Monday's new gap gets a new agent in 25 minutes, not a new sprint. The ceiling you raised just climbed again.

You just ran the meta-tool move at the heart of **Recipe 8**: agent generates agent, in 25 minutes, on a real gap. After Agents 101, when the next gap wants the same shape, the [Cookbook for Agent System Design](supplementary/cookbook-for-agent-system-design.md) is where the moves live, plus the rest of Recipe 8 (three thinking disciplines, strategy kernel, domain-readiness 3-test) for when the next move is bigger than one agent.

