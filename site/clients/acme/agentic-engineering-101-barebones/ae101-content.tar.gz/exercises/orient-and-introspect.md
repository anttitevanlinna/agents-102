# Orient and *map the window*

**Time:** 20 minutes.

**Session** *(new, "Module 1 - Orient and introspect")*

Start a new Claude Code session at your repo root. Renaming is optional, but helps you find the right window when several are open.

```
/rename m1-orient
```

**What you do:** have Claude read your repo, then interrogate what it read.

**What you build:** a picture of what landed in the context window and what didn't.

**The point:** the context window is not your codebase.

---

## Read your repo deliberately

- You steer what Claude loads: the repo's shape, its structure, what's load-bearing, what's gone stale. A cold agent reads whatever it stumbles into; you point it.

> **Big repo? The read can fan out.** If Claude starts reading dozens of files, interrupt with `Esc`, narrow to one feature or directory, and send a `continue`-prompt. It can also stop short, and that one is harder to catch because a confident answer arrives either way. If the read names only the files you'd have guessed at, a `"there's more here"`-prompt buys another pass.

Ask Claude to read your repo deliberately and report what it finds.

{{prompt:orient-and-introspect-1}}

## Ask what Claude skipped, and why

- Every read has a shadow: the files Claude didn't load. The skipped slice is where the surprises hide.
- Claude can introspect on what it did and why, including what it chose not to read.

Ask Claude what it read and what it skipped.

{{prompt:orient-and-introspect-2}}

## Read the self-report, then spot-check it

- The account is a reconstruction, not ground truth. The LLM confabulates its actions as well as its reasons. Assume about 10% of what it says or does is made up. Could be more or less than this heuristic suggests.
- You can spot-check it. Quote a specific file or function back and ask Claude to confirm it read what it claims.

## Check how full the window is

- The context window has a ceiling. `/context` is the slash command that shows how full it is: total used, and the breakdown by category (system prompt, messages, memory, skills).

Run `/context` to see how much of the window is used and what fills it.

{{prompt:orient-and-introspect-3}}

(`/context` is oldskool; a status line shows the same thing continuously. Use [ccstatusline](https://github.com/sirmalloc/ccstatusline), or ask Claude to build your own with `/statusline`.)

## The slice Claude didn't load

- What you want is the least context that holds exactly what the task needs. `/context` tells you what you are carrying; accuracy on the next task tells you whether it is the right load.
- The slice Claude didn't load stays real. The window holds only so much; going forward, you choose what fills it.

