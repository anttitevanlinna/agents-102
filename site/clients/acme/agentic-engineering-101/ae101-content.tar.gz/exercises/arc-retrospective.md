# Arc retrospective

**Time:** 15–20 minutes.

**What you do:** Ask an agent to read everything you've authored across the training and write a one-page note on what changed. The agent names the arc from your own evidence, not a template.

**The point:** The throughline of the training is that everything is scaling of learning. Each module's loop is the same loop at a wider scope. That's only visible retrospectively, and only from your own artefacts. The agent's job here is to name the arc so you see it too.

> **Quick timebox note.** The read across Modules 1–6 artefacts is wide; the beat stays short. One arc-reading pass, one push-back, save or drop. If the agent's note reads true, save. If it reads thin after one re-draft, drop. Dropping is not the soft option; it is a signal your artefacts did not carry the density the read needed. Note that and move on. No perfect note to chase. The arc is yours; the note is just the agent helping you see it.

---

**Note** This continues in the same session that ran the Module 6 Phase 1 + 2 work, in the Module 5 worktree. No new session. The fresh, uncoloured view comes from the sub-task the prompt spawns.

The artefacts across all six modules, `CLAUDE.local.md`, `observations/`, ADRs, both authored skills, both runs' commits, are accessible via git refs and the worktree state. Both runs' branch names and transcript paths are recorded on disk: M4 in `task.md`, M5 in `plan.md`'s protected `Run coordinates` block. Ask the agent to walk them and write the arc from them.

{{prompt:arc-retrospective-1}}

Claude will likely open with a plan-summary paragraph (*"I'll dispatch the sub-task, then combine findings..."*) before any read happens. Skim past the opening; the note is what you're reading for.

If the read runs ten minutes plus, interrupt with *"enough. just tell me now."*, you have what the agent has assembled so far, and that's the read.

Read the note. That's the read of your six modules from outside the work.

If the note reads true, save it. You'll have your agent re-read it when the next long task stalls.

**What happened:** You ended with a short written note in your repo (ADR-shaped or a loose memo, your call) that named how your practice changed across the modules. The agent read across all six modules' artefacts and wrote the arc from your own evidence, not a template.

