# Agents that build agents

The closer named the flywheel in one line. *Agents that build agents.* This lecture is the unfolding of that line.

You authored two skills in this training. The first one at Module 3 packaged a piece of judgement you had carried for years (how to write a good test). The second one at Module 6 packaged a piece of judgement you had earned over two runs of the same task. Different sources, same move. Each skill made the next run cheaper.

The flywheel turns one more time when the agent writes the prompt that builds the next skills.

## The move

You authored one skill from one task's evidence. The flywheel turns once more when you hand the agent the move itself and ask it to write you the prompt that builds the rest.

Not "write me a skill." Not "improve my setup." Ask it for a handoff prompt: one you paste into a fresh session later, that studies your work across your repos for the shapes you repeat, draws the ones worth packaging, and authors a skill for each. The same move you just practiced, widened to everything you do.

What comes back is a candidate. You read it the way you read any prompt the agent drafts. Judgement, push-back, taste. Some of it will be obvious. Some of it will be off. One or two lines will be moves you would not have written on your own.

That is the flywheel. The agent writes the prompt that builds the next skills, and you decide whether it earns a place in your kit before you ever run it.

## What this is not

This is not the agent writing its own skills without you in the room. At the start of this training, you might have hoped that was the destination. At the close of Module 6, you know it is not. Agents that build agents is a collaboration in the same shape every other beat in this training has been a collaboration. Claude proposes, you steer.

The reason is plain. Claude can read the artefacts the loop produced. It cannot read the codebase knowledge in your head, the political situation around the team kit, the next quarter's roadmap, the bug your tech lead lost three days to last sprint. The plan it generates is grounded in the evidence on disk. The decision about which proposals to act on is grounded in evidence the agent does not have.

Build a flywheel that lets the agent run as far as it can on its own evidence, and stops at the moment your judgement is the input that matters. That is the practitioner shape. Anything further pretends the agent has access it does not have.

## A prompt to try

This one closes the module. The shapes you drew and the skill you shipped are still in the session. Ask the agent to turn them into a prompt that builds the rest of the kit.

{{prompt:agents-that-build-agents-handoff}}

What comes back is a prompt, not a plan. Read it the way you read any prompt the agent drafts. Save it where you will find it. The kit you grow on your own is the one that counts.

## Ralph

Geoffrey Huntley saw a lever. An agent runs, drifts, needs nudging. The fix already existed in shell:

```bash
while :; do cat PROMPT.md | claude-code; done
```

He called it Ralph, after the Simpsons. One line, no scaffolding. Hacky, simple, powerful. Ralph re-feed entered the practitioner vocabulary as one of the named verifier shapes when a multi-hour task wants a stop-and-check.

Months later, Claude Code shipped `/goal`. The runtime version of the same move. A condition, a check each turn. The shell hack is now a slash command.

Practitioners see levers first. The lever was sitting there in plain shell. Huntley reached for it. The platform watched, and shipped the move native.

That's the M6 leap. The next Ralph is yours.

## Where the loop ends

There is no last turn. Each run surfaces the next gap. Each gap proposes the next move. Each move makes the next run cheaper. The kit grows, the rules sharpen, the skills accumulate, and the model underneath gets replaced every few months without changing the move.

The training closes. The flywheel does not.

