---
key: audit-your-agent-3
dest: Claude Code
runtime: any
---
Mitigate the risk I name below. Pick the shape that fits it (scope, split, filter, gate or review), make the changes, and tell me what you did and why.

Then run the same check again for this one risk and tell me the new verdict: is the risk reduced, gone, or moved somewhere else?

Add a section "Mitigation applied and residual" to the end of outputs/security-report.md: what changed, the new verdict, and what is still at risk.

The risk:
