# Lecture: Grounded, and five candidates to measure

There is truth out there. Your sources carry shards of it. Your agent, left to itself, has no model of truth, only a model of what usually comes next in language that looks like yours.

When you ask it for something your sources support, it produces grounded output. When you ask it for something your sources don't support, it still produces something. The difference between those two states is invisible in the tone of the output. That's the whole problem.

**Why this happens, in one sentence.**

Large language models generate the next likely word. Not the next true word; the next likely one. They're trained on text where people spoke confidently, cited specifically, wrote fluently, and the models learned to produce language that looks like all of that, whether the underlying material supports it or not. Fluency is not evidence. Confidence is not correctness. The model has no way to tell you which parts of its output are grounded and which are plausible-sounding fill.

This isn't a bug that gets patched in the next release. It's the shape of the technology. Later models will fabricate less; they won't stop.

**The compound reliability math.**

If an agent is 85% correct on a single step (an illustrative number, picked because it sounds forgivable), that's not bad. Eighty-five out of a hundred. You'd forgive that in an intern.

Now run ten steps. Retrieval, synthesis, formatting, writing, checking, rewriting, summarising, publishing. Ten is not a lot. 85% per step, ten steps: 0.85^10 = about **20%.** One in five runs is end-to-end correct. Four in five have a defect somewhere, usually somewhere you won't see.

This is why agentic customer service works (2–3 steps: look up the order, check the policy, draft the reply, at 95% each = 86% end-to-end). This is why "let the agent handle the full workflow" doesn't (10 steps, 85% each = 20%). The math is the difference between a demo that delights and a production system that leaks.

The number doesn't tell you *what* will go wrong. It tells you that something will. Your job is to design for that, not against it.

**Now flip the math.**

Say your briefing has a 10% fabrication rate: ten ungrounded claims in every hundred. You test. A decent detector catches 90% of them; it's that easy, because fabrication leaves fingerprints. You fix what the detector flagged. Test again. The detector catches 90% of what's left. Fix again.

Round 1: 10% fabricated → 1% after fix.
Round 2: 1% → 0.1% after fix.
Round 3: 0.1% → 0.01%.

The same compounding that destroys single-pass reliability *builds* loop-based reliability. One generation pass is a trap; a test-and-fix loop is the escape. Three rounds and you're at parts-per-ten-thousand, a place single-pass generation cannot reach, no matter how good the model gets.

This is the shape of the rest of the training. Now you'll run the test side: a benchmark to find the detector that works on *your* output. Module 6 puts that detector in a loop that runs the full test-fix-test cycle without you. That's evals. The 85%-to-20% math is the problem; the 10%-to-0.01% math is the answer.

**The word is grounded.**

Every output your agent produces is either connected to truth (to specific files, specific numbers, specific quotes in specific sources) or it isn't. Connected to truth is grounded. Approximating truth without being tied to it is ungrounded.

The positive discipline is grounding. The failure mode is fabrication. The failure mode is what makes headlines: the lawyer citing invented case law, the medical chatbot inventing medications, the finance memo with confident numbers nobody can source. But the discipline is what keeps you out of those headlines, and the discipline is grounded.

Grounded isn't "accurate." A grounded claim can still be wrong, if the source it's tied to is wrong. Grounded means *traceable to a real piece of evidence*. Accuracy is a harder question, and an agent alone can't answer it. Traceability is a mechanical discipline, and an agent CAN be forced into it. Start with grounded.

**Don't pick a method. Run the candidates.**

Somebody tells you *"just have the agent read your files before it answers,"* or *"do a consistency check,"* or *"prompt it to cite sources."* A single method, presented as the answer. You try it, catch some things, miss others, never know what you missed, and move on feeling vaguely better.

That's intuition. The move is empirical.

You have a briefing. You don't know which detection method will catch what matters on *your* output, with *your* sources, on *your* strategic question. Nobody does. Not the vendors, not the frameworks, not the blog posts. The only plain answer is to run several candidate methods in parallel and measure which one catches what your benchmark says should have been caught.

Five candidates, chosen because they fail in different directions, so the scoreboard gives you real spread:

**1. Source triangulation.** For every specific claim, does it appear in at least one file on disk? Catches *invention*: claims with no source behind them at all.

**2. Entailment.** Does the briefing say more than the sources actually support? A source that says "one customer complained" doesn't support "the market is unhappy." Catches *overreach*: where the claim stretches past what the evidence carries.

**3. Citation integrity.** When the briefing cites a source, does the source actually contain the claim? A citation that doesn't hold is worse than no citation; it manufactures false authority. Catches *citation cargo-cult*: citations that look load-bearing but aren't.

**4. Self-consistency.** Regenerate the briefing and diff the versions. Claims that hold steady across regenerations are defended by the sources; claims that drift or disappear are fabrications the model couldn't stand behind twice. Catches *unstable invention*: output the model couldn't defend on a second try.

**5. Counter-evidence search.** Instead of looking for sources that support each claim, look for sources that contradict it. One contradiction kills the claim; a hundred supporting files don't prove it. Catches claims that *look* grounded under confirmation but crumble under disconfirmation.

Five candidates, five different failure modes. In the exercise, they run as five parallel agents on your briefing, each writing findings to its own file. A scorer measures them against a five-claim benchmark you write yourself: precision, recall, coverage. The scoreboard is the mechanism. You don't argue with it; you read it.

The winner (or an ensemble of the top two) becomes a judge file you carry into Module 6, where the judge stops being something you run and becomes something that runs itself.

**What this buys you.**

Not certainty. Certainty isn't available. What you buy is a *grounded choice about grounding*: you know which detector won on your material, you know why, you know what it misses, and the judge file you save plainly names its own blind spot.

That last clause is the one that matters. Grounded output names what it doesn't know. A grounded judge names what it can't catch. Ungrounded output pretends to know everything; a cargo-cult judge pretends to catch everything. The difference looks small on the page. In a decision room, it's the difference between a memo that holds up and a memo that detonates.

Now you run the benchmark by hand. Well, not by hand. You set up five detectors, a scorer, and a five-claim benchmark. The agents do the work. You watch the scoreboard fill in. At M6 the winner goes inside a loop that runs and improves itself.

**Time:** 10–12 minutes.

