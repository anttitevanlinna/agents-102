# The wizard move

## Who this is for

You've already done the hard part. You found this training because you use Claude Code regularly and you want to get further with it. That's who this training is for.

Nobody here needs the "agents can write code" setup. So this training won't run one.

You'll watch what's possible, not what's missing. That's the posture of the whole training.

## Context is King

The same question, two answers. Two Claude chat windows. In one, the first prompt is *"What is the capital of Italy?"* Claude answers *Rome.* Then the second prompt: *"What should we have for dinner?"* Claude suggests something Italian: pasta, osso buco, risotto.

Same words, different window. In the other window, the first prompt is *"What is the largest lake in Finland?"* Claude answers *Saimaa.* Then the same second prompt: dinner. Take a guess before it runs. What does Claude suggest now?

Something Finnish: salmon, rye bread, meatballs. But not as reliably. The first exchange became context, and the context colored everything after.

## You steer the answer by loading context

A role colors answers the same way a fact does. One more window. The first prompt: *"I'm a cardiologist preparing dinner for my patients."* Then the same second prompt about dinner. The suggestion shifts again: heart-healthy, low-sodium, vegetable-forward. Not because Claude knows medicine better than Italian cooking. You told it who you are, and every answer after took that into account.

Context is whatever you tell it. A fact. A role. A preference. A constraint. All of it colors what comes next. You, in a way, compel the right output by having the right stuff in the context.

That's the move. The move is loading the right context before the question, not a clever prompt or a slash command you didn't know. Everything else in this training is about how to earn that kind of primed window on any codebase, any Monday.

## Everyone arrives partial, trainers included

You found your way to Claude Code by yourself. Maybe a colleague pointed you at it. Maybe you watched a video. Mostly you just typed something, watched what came back, and kept the prompts that worked. You picked up tricks nobody taught you. The slash command that saves keystrokes. The `CLAUDE.md` shape that produced output you liked. The weird thing you tell Claude at the start of every session.

Every engineer who sat down with this tool did some version of that. The trick you named at the opening trick-exchange is your slice of partial; everyone else's slice is different.

This training pools partial into a shared floor, then raises the ceiling. The people building this are partial too. Six months ahead of you on some moves, six months behind on others.

## The loop is what you repeat, not the fix

Fix one trivial bug from your own backlog, end-to-end. Log one decision. Seed a rules file your next session reads first.

The fix happens once. The loop is what you repeat: a way of working, not one bug closed. You become the Claude wizard by running the loop on real work and letting the habit sharpen. Not by reading about it.

