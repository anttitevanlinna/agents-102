# Painting the picture with the LLM

## The LLM mirrors your stance

The wizard typing in neat Perl syntax is dead. Auto-complete was a thing. Auto-complete is no longer a thing. The LLM has taken on a part of high-end engineering skill.

The LLM can do good work and bad work. It will be what fits the session. The LLM mirrors your stance.

The tool is not the thing; the taste behind the tool is the thing. Seth Godin has been making that argument about tools for decades. The LLM is the infinite version of it: your stance as input to the session is mirrored in the output.

It was trained to match you. Your stance is the ceiling.

## You prime, the LLM scales
<!--tier:3-->

Stance and approach matter more now, not less. The session bends to what sits in the context window. You prime the context. The LLM scales it.

Whatever you put in front of the LLM is what the LLM scales. The rules file. The prompt. What sits on disk for the agent to read.

If you want a shotgun, you have a shotgun. If you want a cannon, you have that too. The sharp engineers stay sharp.

## Two frontiers: how fast, and the right things

Your setup is the rules and context you put in front of the LLM. The first frontier: can that setup learn faster than you can write things down?

The second frontier: once your setup learns fast, does it learn the right things, and not just any things?

Let's go.

