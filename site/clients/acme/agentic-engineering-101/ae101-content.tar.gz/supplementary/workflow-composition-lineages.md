# Workflow composition lineages

A walk through composition shapes surfaced from named practitioners' own published work. One named framework, three architectural stances, one move-catalogue, one counter-position. Six entries; not a closed set. The field is moving and the curation is partial.

## What this walk covers (and doesn't)

Three reading rules for this supplementary:

1. **One published framework lives in this set: Klaassen's Compound Engineering.** Plugin shipped, framework named, repo active. Other entries publish architectural stances, named methodologies, or scattered moves without putting a framework label on them. Each entry is honest about which it is.

2. **There are almost certainly other named frameworks the walk hasn't surfaced.** This supplementary is a starting map drawn from a small sample of practitioners the AE101 research surfaced through OODA cycles in May 2026. New frameworks ship monthly. Treat the walk as a way to read the field, not as an exhaustive index of what exists.

3. **Quote with care.** Synthetic framings ("phase pipeline", "rails not chains", "vendor-shipped composition primitives") that have circulated on third-party write-ups have been removed where the original practitioner did not publish them. The cost: less aphoristic body prose. The benefit: a student or trainer who looks up a quote will actually find it where the supplementary says it lives.

## Compound Engineering, Kieran Klaassen

The one named, published framework in this set. Klaassen ships a Claude Code plugin (`EveryInc/compound-engineering-plugin`) that names the four-step loop directly: **Plan → Work → Assess → Compound**. The plugin's slash commands include `/ce-plan`, `/ce-work`, `/ce-code-review`, `/ce-compound`, with dozens more skills and review agents. The composite chains these by file path, not by in-context handoff. `ce-plan` writes `docs/plans/<slug>.md`; the next step takes that path as a literal argument. Progress lives in git, never in the plan body. Every seam between steps carries a hard gate — file-existence or `git status` checks — that the next step refuses to start without.

The closure step is explicit. `ce-compound` writes structured docs with YAML frontmatter validated against a schema. Klaassen's framing of `ce-compound`'s job: record the lesson so the next agent uses it, not re-derives it. Lessons land on disk where the next fresh agent finds them by convention.

What's missing or contested: Klaassen's own byline is thin in the freshness window (his last own Every.to post is just outside). Current Klaassen material is mostly third-party write-ups plus the plugin itself, which is actively committed-to.

**Read:**
- [Compound Engineering plugin (`EveryInc/compound-engineering-plugin`)](https://github.com/EveryInc/compound-engineering-plugin) — start with the README's named slash commands, then walk the corresponding skill files. The plugin ships dozens of skills and review agents; the wiring shape repeats.

## Composition by invocation, Matt Pocock

Pocock ships a public kit of small named skills at `mattpocock/skills` (active, widely forked). Skill names visible at last read: `to-prd`, `to-issues`, `handoff`, `prototype`, `write-a-skill`, `diagnose`, `triage`, `tdd`, `improve-codebase-architecture`, `grill-me`, `grill-with-docs`, `zoom-out`, `caveman`, `git-guardrails-claude-code`, more. Each skill is small (50 to 200 lines of plain English), standalone, and works copy-pasted into a different agent.

The composition pattern is runtime, not authored. There is no `compose` skill, no orchestrator, no master entry point in the repo. The human invokes the skill the task calls for: `/prototype` when prototyping; `/to-prd` when shaping a product brief; `/handoff` when context needs to move to a new thread. Composition happens in the chat, by hand, one skill at a time.

Pocock does not publish a named framework over the kit. The composability framing that has circulated on third-party write-ups ("rails not chains", "weakly coupled") is not in his README. The kit itself, and the discipline of invoking individual skills when the task calls for them, IS the practice. The README's opening sentence is the closest to a stance: *"My agent skills that I use every day to do real engineering, not vibe coding."*

**Read:**
- [mattpocock/skills](https://github.com/mattpocock/skills) — read `to-prd`, `to-issues`, `handoff`, `prototype`, `write-a-skill`. Notice what is missing: no `compose` skill, no orchestrator, no main entry point.
- [setup-matt-pocock-skills](https://github.com/mattpocock/skills/blob/main/skills/engineering/setup-matt-pocock-skills/SKILL.md) — the per-repo config scaffolder; other skills read what this writes.

## Single writer with advisor agents, Walden Yan and Cognition

Cognition's evolved 2026 position on multi-agent architecture, published as *Multi-Agents: What's Actually Working* (Walden Yan, 2026-04-22). The architectural claim is verbatim: *"multi-agent systems work best today when writes stay single-threaded and the additional agents contribute intelligence rather than actions."*

This is a hard evolution from Cognition's 2025 *Don't Build Multi-Agents* stance. They tried parallel writers; conflicting implicit choices (style, edge cases) broke the work. Parallel reviewers feeding a single writer did not.

The shape: one writer agent does the actual code-writing. Other agents advise. Yan's published metric: *"Devin Review catches an average of 2 bugs per PR, of which roughly 58% are severe (logic errors, missing edge cases, security vulnerabilities)."* Closure happens in the writer's working memory; advisors return intelligence contributions, not actions. No separate compound skill.

Cognition does not put a framework label on the shape itself. The "single writer with advisors" framing in this supplementary is the curriculum's shorthand; the operational claim and the metric are Yan's.

**Read:**
- [Multi-Agents: What's Actually Working](https://cognition.ai/blog/multi-agents-working) — Yan's evolved 2026 position; the verbatim *writes-stay-single-threaded* line lives here.
- [Don't Build Multi-Agents](https://cognition.ai/blog/dont-build-multi-agents) — Cognition's original 2025 stance; pair with the evolved post for the trajectory.

## Feedback-loopable methodology and shipped primitives, Sourcegraph Amp

Two artefacts in the Amp surface, with different bylines and different shapes.

**Feedback Loopable**, by Lewis Metcalf at Sourcegraph (2026-02-05), is a named methodology Metcalf calls *"making it feedback loopable"* — building things for humans using methods built for agents. His three components, verbatim from the post: *"1. Built a playground. 2. Set up Experiments. 3. Made the inner loop fast."* The playground is a shared agent-human environment. Experiments use URL-driven query parameters for reproducibility. The inner loop is sped up by emitting CLI text output rather than screenshots so the agent can iterate faster. This is Metcalf's coined methodology, not an industry-standard framework.

**Handoff**, anonymous team byline at Amp (2025-10-23), is a vendor feature, not a framework. The published description: *"Handoff lets you specify your goal for the new thread. Amp then analyzes the current thread and generates a prompt to start the new thread, along with a list of relevant files."* The argument for handoff over compaction: *"It's lossy, for one. Every time you compact a thread, what's in the context window gets replaced with a summary."* Handoff is a single composition seam Amp ships; it does not arrive as part of a broader framework Amp has named.

What's distinctive about the Amp surface: composition seams are vendor-shipped and vendor-maintained. If Amp ships a better `/handoff` next month, the user gets the upgrade without rewriting any skill files. Klaassen and Pocock keep their composition primitives in their own Git repos; Amp asks the user not to.

What's contested: most of Amp's specific primitives are platform-specific. Read the posts for the architectural shape and the methodology framing; do not expect the verbatim primitives to translate to Claude Code or Cursor.

**Read:**
- [Feedback Loopable](https://ampcode.com/notes/feedback-loopable) — Metcalf's named methodology, three components in his own words.
- [Handoff](https://ampcode.com/news/handoff) — the canonical Amp post on the handoff feature; explains why compaction is lossy.

## Practitioner moves without a published framework, Boris Cherny

Cherny ships composition moves publicly on X (the 2026-01-02 thread is the canonical recent run-down). What he names directly:

- Slash commands for every "inner loop" workflow, checked into git in `.claude/commands/`, used many times a day.
- Subagents that automate common workflows. He names two by example, `code-simplifier` and `verify-app`, then "and so on." The other subagent names that circulate in third-party digests (`code-architect`, `build-validator`, `oncall-guide`, others) come from scattered tips, not from this one thread.
- A PostToolUse hook for formatting code: *"Claude usually generates well-formatted code out of the box, and the hook handles the last 10% to avoid formatting errors in CI later."*
- `/permissions` over `--dangerously-skip-permissions`, checked into `.claude/settings.json` and shared with the team.
- MCP for tools (Slack, BigQuery, Sentry) — agent picks up the human's existing tool surface.
- For long-running tasks, three options: prompt Claude to verify its work with a background agent when it's done; an agent Stop hook for determinism; or the `ralph-wiggum` plugin (originally from @GeoffreyHuntley).
- The single tip Cherny names as most important: *"give Claude a way to verify its work. If Claude has that feedback loop, it will 2-3x the quality of the final result."*

Cherny does not publish a unified framework over these moves. There is no Cherny-bylined post that names a "phase pipeline" architecture or a `/go` composite skill that orchestrates the named subagents. Synthetic write-ups exist (e.g., the fan-curated `howborisusesclaudecode.com` aggregator by @CarolinaCherry collects scattered tips into a unified-looking page); those are third-party distillations, not Cherny's publications.

The honest shape: Cherny ships composition primitives a practitioner can adopt one at a time. The unification is in the reader's head, not in his published artefacts.

**Read:**
- Cherny's [X thread starting 2026-01-02](https://x.com/bcherny/status/2007179832300581177) — the canonical recent run-down of his composition moves in his own words. The thread carries the moves listed above; treat any further unification as third-party synthesis.
- [@CarolinaCherry's fan-curated digest, *How Boris Uses Claude Code*](https://howborisusesclaudecode.com/) — useful as an aggregator across Cherny's scattered tips; not Cherny's own writing, attributable as *CarolinaCherry on Cherny*.

## Counter-position, Armin Ronacher

Ronacher is not running a composition lineage. He's arguing against treating composition as a multiplier. His core claim in *The Final Bottleneck*: *"If the machine writes the code, the machine better review the code at the same time."* Code generation accelerated; the pull-request review now turns into the constraint. Composing more primitives upstream does not relax that constraint. The throttle on agent throughput is the human review, not the prompt.

Ronacher's posture on skills is disposable. From *Pi: The Minimal Agent Within OpenClaw*: *"My agent has quite a few skills and crucially I throw skills away if I don't need them."* No marketplace, no Git-checked-in kit, no orchestrator over the skills. The artefact of his work is the shipped code, not the rules that produced it. *Agent Psychosis: Are We Going Insane?* extends the argument to unstructured composition loops: dopamine-driven workflows with no critical thinking trade short-term satisfaction for long-term review debt.

The reason Ronacher matters in this walk: any teaching of composition that does not carry his argument alongside teaches the move and silently teaches its decay. Composition fluency erodes the review discipline that originally justified composition. Willison has flagged the same pattern from a different angle, calling it *normalization of deviance*. If you are going to compose, the question Ronacher forces is *what is your review bandwidth?* If the answer is the same as last year, composition is not yet a multiplier.

**Read:**
- [The Final Bottleneck](https://lucumr.pocoo.org/2026/2/13/the-final-bottleneck/) — review bandwidth as the constraint composition cannot relax.
- [Agent Psychosis: Are We Going Insane?](https://lucumr.pocoo.org/2026/1/18/agent-psychosis/) — Ronacher's stance on unstructured composition loops.
- [Pi: The Minimal Agent Within OpenClaw](https://lucumr.pocoo.org/2026/1/31/pi/) — where the disposable-skills posture is named directly.

## How to pick what to study

Three filters that work better than ranking:

1. **What shape is your real work?** If you're shipping multi-file engineering changes with clear phases and want a published framework you can install today, Klaassen. If you're already shipping things one skill at a time and want a model for runtime composition, Pocock. If your team is wrestling with parallel-writer chaos, Yan/Cognition. If your team has standardised on Amp's runtime, Metcalf and the Amp surface by default.

2. **How much orchestration do you want to author?** Klaassen is heavy on orchestration (gates, schemas, composite skills). Pocock is light (human picks the chain). Cognition is somewhere in between. Cherny's published moves are the lightest published assembly, individual primitives the human composes mentally. Pick the load you will actually maintain.

3. **What review bandwidth do you have?** Read Ronacher first if the answer is *not much*. Composition without review is the failure mode he names.

Two or three practitioners is enough to track. Watch what they ship in their own venues, not what third-party write-ups distill from them. The composition conversation will keep moving. The shape of work each practitioner handles is the slower-moving signal. And keep an eye out for named frameworks this walk does not yet cover; the curation is partial by design.

