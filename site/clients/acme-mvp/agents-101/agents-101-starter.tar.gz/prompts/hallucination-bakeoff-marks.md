---
key: hallucination-bakeoff-marks
dest: Claude Code
runtime: any
---
Show me five claims from `module-5/claim-pool.md` with their numbers: a mix of shapes, at least one you would expect to be hard. Do not tell me your view of any of them.

For each, I answer grounded or not grounded, with one line on why. Write my answers to `module-5/my-marks.md`, one line per claim, in this form with my words kept:

- module-5 #N | grounded or not grounded | why | judge: -
