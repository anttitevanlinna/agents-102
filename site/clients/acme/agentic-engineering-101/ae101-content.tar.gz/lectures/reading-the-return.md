# Reading the return

## What would have caught this earlier?

- Whatever came back is the artefact. You stepped away with the agent working. The run finished, hit its budget, or was stopped because enough was seen. All three are readable results, and the read is the same.
- The question that drives the read: *what would have caught this earlier in the run?* Not *did the run succeed*. Not *should I have spec'd it tighter*. A diagnostic: you read the artefact, you find what went wrong, and for each thing you ask this one question.
- The clock scales with the run. Practitioners running these for hours sharpen the question as *at hour two, not hour six*. On a short run it is *at minute ten, not minute twenty-five*. Same diagnostic, different clock.

## Three failure modes you'll use to read

- Practitioners name the same three, in roughly the same order. Engineers running multi-hour coding agents converge on this vocabulary. Use the three as the lens for the read.
- **Goal drift.** The instructions get buried as the conversation grows, and by hour one the agent is solving an adjacent problem with confidence. The LLM reasons from what fills the window now, and the original ask competes with everything generated since. Starts early. Hard to spot until you compare what was asked against what was done.
- **Context rot.** Signal-to-noise drops as the working window fills. The agent rehashes approaches it already ruled out two hours ago, because "ruled out two hours ago" no longer fits in the working window. Practitioners hit this around hour one to two.
- **Plausible-but-wrong.** Outputs look reasonable in isolation and don't match the original spec. The LLM produces the next likely word, not the next true one, so fluent and confident is its default finish whether the work is right or not. The most expensive failure to find, because it doesn't trigger an obvious tell. Hour two onward.

## Why these three, every run

- The three are consequences, not bad luck. The LLM is a statistical machine with a finite window: it predicts what is likely, and it holds only so much. Run it long enough and all three failures follow, whoever wrote the prompt.
- Predictable failures are readable failures. Because the three come from the machine, the same three turn up in every practitioner's long run. That is why three lenses are enough to read whatever comes back.
- On the map, they live in the Work phase. The failure happens where the work happens. Reading for them is the far half's first verification move.
- One question per finding: which of the three is this? A finding counts when it carries a lens and a quoted moment from the artefact. Two modes tangled in one finding means the read is not done; pull them apart.

## Ronacher's ten-hour port surfaced all three

- Armin Ronacher ran a port between two languages in roughly ten hours of agent time. Two and a bit million tokens. Long enough for all three failure modes to show up.
- The run held together anyway. He had something specific in place that catches the failure modes above. What that was is where your own read leads.
- The read starts with the artefact on screen and the three lenses in hand. A stopped run counts; the trace is the data.

