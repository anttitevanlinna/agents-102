# Composing the workflow

You have a kit now: a test-strategy skill, a verifier, and a freshly drawn map of the moves worth packaging next. A workflow is those moves in the right order around one passage. Before you read how the field argues about composition, look at what composition actually is, on the passage you already sailed.

## A skill's footprint is where its job lands
<!--tier:2-->

{{figure:skill-sea-passage}}

- A **skill** is a named move you reach for. Single purpose, reusable, invoked by name. Your test-strategy and your verifier are moves you already own; your stack-map names the ones worth building next. You reach for one where the passage needs it, not rebuild it each session.
- Its **footprint** is wherever the job lands. One move takes a single fix at a turning point. Another carries a whole leg. A third runs at the pier, before the first leg. You never size a skill in advance. The job sizes it.
- Nothing here is new except the placing. A move now stands at each point you used to steer by hand. Where no move stands, you sail that stretch yourself.

## From skills to a workflow
<!--tier:2-->

- A session passes through phases: context, plan, build, verify, ship. A skill sits where its job sits. Its footprint is set by the job, not by the phase line.
- The field wires kits more ways than one; no way has won. Pocock ships a public kit with no orchestrator: you call each skill by hand. Klaassen chains steps through files on disk, a gate at every seam. Some workflows have a pilot; many do not.
- One documented kit wires skills. One skill names another as a precondition: **an explicit load**. One sequences and gates a chain: **an orchestrator**, the pilot. A rule in `./CLAUDE.md` matches a file or phrase: **routing**. One hands its output to the next: **a hand-off**. A skill that does one job and calls nothing is a **leaf**.
- A workflow is not only steps in order. At a seam, a check or stop condition decides whether the next step may begin.
- Chaining generation without checks only moves work into the review queue faster.
- Your job moves from reading every intermediate output to designing the checks, routes, and exceptions that deserve your judgment.

## Composition is a live argument, so you read
<!--tier:3-->

How the field composes kits like this is a live argument with no settled answer, so there is no prompt to drill here. The move is to read: one engineer's whole worked stack, then the wider field.

[Dino's skill stacking system](trainings/agentic-engineering-101/supplementary/skill-stacking.md)

[Workflow composition lineages](trainings/agentic-engineering-101/supplementary/workflow-composition-lineages.md)

Pick the shape that resembles your day.

