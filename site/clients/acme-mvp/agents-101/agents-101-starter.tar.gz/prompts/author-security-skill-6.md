---
key: author-security-skill-6
dest: Claude Code
runtime: cowork
---
Use your skill-creator skill to turn the authored source at module-4/skills/agent-audit/ into a personal skill named agent-audit. Draft it, then surface the save action so I can save it.
