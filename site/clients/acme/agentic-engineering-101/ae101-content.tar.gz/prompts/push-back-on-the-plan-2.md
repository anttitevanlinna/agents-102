---
key: push-back-on-the-plan-2
dest: Claude Code
permission-mode: plan
runtime: any
origin: exercises/push-back-on-the-plan
requires:
  - id: initial-plan
    source: prompt:push-back-on-the-plan-1
produces:
  - id: revised-plan
    location: plan file (in-place edit after 'lock it in')
    consumed-by:
      - prompt:push-back-on-the-plan-3
---
Do a second-pass read of the current plan. Walk down every unresolved branch of the design tree three at a time: dependencies, decisions, side-effects I haven't named.

Answer me in prose. Don't touch the plan file until I say 'lock it in.' When you do edit the plan, use Edit on the changed section, not Write on the whole file.

Ask me three questions at a time. For each question, recommend an answer. If a question can be answered by reading the codebase, read the codebase instead of asking me. I'll confirm or correct three at a time.
