---
key: hallucination-bakeoff-2
dest: Claude Code
runtime: any
---
Open `module-5/briefing.md`. Extract 30 varied claims from the briefing, or every claim if it holds fewer.

Use short verbatim excerpts from the briefing wherever possible, so later detector findings can be matched back to the briefing. Include a mix of claim shapes:
- numbers or measurable outcomes
- named-entity claims
- quotes or paraphrases attributed to sources
- causal claims
- comparison claims
- recommendation or next-action claims
- claims that seem obviously grounded
- claims that smell like overreach

Do not judge whether the claims are grounded yet. Do not ask me questions. Save the claim pool to `module-5/claim-pool.md`.
