# Quality is grounding


---

The quality arc started at M1 with tests-first. M2 added plan push-back, quality applied to the agent's intent before any code runs. By M3 you'd authored the test-strategy skill from this codebase's conventions. At M5 you built the verifier, shaped against the failures the un-packaged run actually showed. Today you add the next artefact: a second skill packaged from what two runs taught, in the shape the dominant gap calls for. Five moves, one arc: tests-first, plan-pushback, skill, verifier, loop. That's the quality kit you walk out with. Not one move learned in one module. The discipline, threaded through the whole training.

Some of the early agentic engineering demos were single devs shipping 500K lines of code in weeks. The first Agentics Helsinki meetup, fall 2025, had a few of them. The recurring theme: every generated line had to correspond to a spec, every feature had to be tested. Without that, no way to know the system works. Nobody reviews 500K lines by hand. The discipline has gone deeper since. Beyond spec-and-tests, toward grounding. Toward human signal. Every push-back, every correction, every *"no, like this"* is signal of something: what's true, what's valuable, what works, what's broken. The agentic engineer maxes that signal out. You ship a million lines of new stuff. How do you know it's right?

