# Why a Personal Agent Is So Hard to Turn Into a Company Agent

The personal agent you built in Module 2 works because a thousand small tacit choices you made during the build are quietly holding it together: which sources to trust, which outputs smell wrong, what the edge cases look like, when to re-run, when to override. None of that is written down. It doesn't need to be — you know it because you did it.

A company agent is the same machine with the tacit layer removed. And the tacit layer was doing most of the work.

This is the hardest conceptual leap in the training. It's also the gap where most "AI rollouts" die — the pilot worked; the rollout didn't; nobody can explain why. This supplementary names the reasons so the student sees the leap coming and picks a sharing strategy that *designs around* the asymmetry instead of pretending it isn't there.

