---
key: author-test-strategy-skill-2
dest: Claude Code
runtime: any
---
Invoke the `test-strategy` skill on this codebase and repository, on the code as it stands in this worktree. Produce the test strategy the skill asks you to produce.

Then, in the same response, read the strategy you just produced and answer: is it good? Does it reflect how testing actually works on this codebase, or does it read generic? Does it name the load-bearing tests and the real integration boundary, not a textbook pyramid? Would a teammate opening a PR on this codebase feel the strategy covers what matters, or would they ask for more?
