# Reading the return

*~5 min pre-read for M5. Lands at the close of M4's Debrief, while your run is going. Names the M5 question and the three failure modes you'll use to read the return. Doesn't name the fixes. Those earn their names in the exercise.*

---

The laptop closed at the end of M4 with the agent working. By the time this lands, the run has either finished, hit its budget, or been stopped because enough was seen. Whatever came back is the artefact M5 starts from.

Here is the question that drives M5.

**What would have caught this at hour 2, not hour 6?**

Not "did the run succeed." Not "should I have spec'd it tighter." A diagnostic question. You read the artefact, you find what went wrong, and for each thing you ask: what would have caught this earlier?

## Three failure modes you'll use to read

Practitioners running multi-hour coding agents in the last six months name the same three failure modes, in roughly the same order. Use them as the lens for the M5 read.

**Goal drift.** The instructions get buried as the conversation grows. By hour one the agent is solving an adjacent problem with confidence. Starts early. Hard to spot until you compare what was asked against what was done.

**Context rot.** Signal-to-noise drops as the working window fills. The agent rehashes approaches it already ruled out two hours ago, because "ruled out two hours ago" no longer fits in the working window. Practitioners hit this around hour one to two.

**Plausible-but-wrong.** Outputs look reasonable in isolation. They don't match the original spec. This is the most expensive failure to find because it doesn't trigger an obvious tell. Hour two onward.

## One practitioner anchor

Armin Ronacher ran a port between two languages in roughly ten hours of agent time, two and a bit million tokens. The run held together because he had something specific in place that catches the failure modes above. M5 diagnoses what.

## What to bring to M5

The artefact (whatever your run produced, including a stopped run). The three failure modes above as your reading lens.

M5 opens with reading it together.

