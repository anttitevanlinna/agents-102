# Orient and *map the window*

**Time:** 15–20 minutes.

**Session** *(new, "Module 1 - Orient and introspect")*

Start a new Claude Code session at your repo root. Optionally rename to `m1-orient`.

```
/rename m1-orient
```

**What you do:** have Claude read your repo, then interrogate what it read.

**What you build:** a picture of what landed in the context window and what didn't: a deliberate read of your repo, the agent's own account of what it skipped, and the context budget that shows the unread slice. Together they map the window you steer for the rest of the training.

**The point:** you can't steer what you can't see. This is the first move of every session after this one. Load deliberately, watch the budget, dig into the self-report.

---

## Read your repo deliberately

- A deliberate read beats a blind one. You decide what Claude loads: the repo's shape, its structure, what's load-bearing, what's gone stale. A cold agent reads whatever it stumbles into; you point it.
- You are not on the hook for reading the repo. The agent does that. Your job is to steer what it loads and keep half an eye on the budget.

> **Big repo? The read can fan out.** If Claude starts reading dozens of files, interrupt with `Esc`, narrow to one feature or directory, and say `continue`.

Ask Claude to read your repo deliberately and report what it finds.

{{prompt:orient-and-introspect-1}}

The agent reports back a map of the repo: shape, structure, what's load-bearing, what's stale. Let the read finish before you interrogate the map.

## Ask what Claude skipped, and why

- Every read has a shadow: the files Claude didn't load. The skipped slice is where the surprises hide.
- Claude can introspect on what it did and why, including what it chose not to read.

Ask Claude to introspect on what it read, what it skipped, and the call it made on each.

{{prompt:orient-and-introspect-2}}

## Read the self-report, then spot-check it

- The account is a reconstruction, not ground truth. The LLM confabulates reasons sometimes. Assume about 10% of what it says or does is misrepresentation. Could be more, could be less.
- You can spot-check it. Quote a specific file or function back and ask Claude to confirm it read what it claims.

## Check how full the window is

- The context window has a ceiling. `/context` is the slash command that shows how full it is: total used, and the breakdown by category (system prompt, messages, memory, skills).

{{prompt:orient-and-introspect-3}}

(`/context` is oldskool; [ccstatusline](https://github.com/sirmalloc/ccstatusline) shows the same thing continuously in your status line.)

## Read the unread slice

- The unread percentage from `/context` is the number that matters. The more the window fills, the less room for new work.
- The slice Claude didn't load stays real. The window holds only so much; going forward, you choose what fills it.
- You now have a map of the window: what loaded, what Claude skipped, and how much room is left. The next exercise fixes the bug you brought from prework, inside the window you just mapped.

