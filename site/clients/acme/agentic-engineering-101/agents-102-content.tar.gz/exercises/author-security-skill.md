# Exercise: *Run and package* a security skill

**Session** *(new, "Module 4 - Security skill")*

<span class="rt-code">Start a new Claude Code session at your training-directory root.</span><span class="rt-cowork">Start a new Cowork task with your training-directory root as the working folder.</span>

```
/rename m4-security-skill
```

**What you do:**

Run the policy files raw against the system you built in modules 2-3. Then package the useful move into reusable expertise: one personal skill with two lenses. Stop when the skill exists.

**Time:** 40 minutes. Phase 1 ~10, Phase 2 ~8, Phase 3 ~22.

Three phases. The raw run proves the policy files are runnable. The package makes the check reusable. The loading and audit come next.

A **skill** packages an expertise (rules, checklists, the moves an agent runs) into something the agent can load and use. Until now you have shaped agents with prompts, files, and rules. This is the next layer up: a reusable "how" the agent loads when the work matches. Module 4 is the canonical place this authoring lands. Taught once, here.

**Phase 1. Run the policies raw (10 min).**

Reference material lives in `module-4/policies/` (your company's distilled policies, or the Nordic-baseline reference for self-study). Start by proving those files are runnable. No skill yet. Just the policy files, pointed at the system.

{{prompt:author-security-skill-1}}

Read the first few rows. The raw run shows which rules can be checked from files and which ones need judgment, context, or a standing evidence check. That is what you package next: not the policy files themselves, but the repeatable way of applying them to this agent system.

**Phase 2. Dictate what matters (8 min).**

Now add judgment. Do not go study the policy files before this step. The reusable check is supposed to carry what matters in your system, not generic GDPR. The way to make that true is to lead with what is in your head, then let Claude read the files and the raw report.

Tell Claude what matters about your company's policies and the agent system you built in modules 2-3. Three to five lines, your own voice.

{{prompt:author-security-skill-2}}

Claude asks. Type three to five lines. Specific. The kind of data your agent touches that would be a problem if it leaked. The rule your legal team cares about most. The customer your CEO would not want named in a transcript. The class of input you would not paste into a public model. Plain language; nothing rehearsed.

When you have typed your lines, Claude reads the raw report and `module-4/policies/`, then proposes the package shape. Read the proposal and push back on anything that sounds like a generic GDPR brochure rather than the agent system you actually built.

**Phase 3. Author both lenses (22 min).**

The reusable check carries two lenses inside one personal skill. One lens checks company policy. One checks agent risk: what the agent can reach, what it might leak, what it might do because a prompt or source misled it. The authored source lives as a `SKILL.md` plus any reference files it needs.

Ask Claude to author both lenses, and to name the risk patterns the agent-security lens covers.

You'll get a lot of questions. The grill is wide on purpose, Claude probes both lenses and won't stop at one round.

{{prompt:author-security-skill-3}}

Claude grills you first. Skim the questions. Answer what you can in one or two lines. When you've answered everything you have a view on, hand the rest back: *"You choose. Optimise for what I can't steer."* Then it saves the files. Before you leave the exercise, check the package-complete list Claude prints. Open the four named risk patterns: if any one is missing from the agent-security lens, ask for it. Sharpen the rule wording so it sounds like your company's policy, not a generic GDPR template. Push back until the report shape is narrow enough that you will actually read it on Monday. Iterate in place.

Before you leave this exercise, save the authored source as a personal skill. The save mechanic differs by runtime.

<div class="rt-cli">

Ask Claude to install the authored source.

{{prompt:author-security-skill-4}}

Run `ls ~/.claude/skills/security-audit/` to confirm. The skill autoloads in your next session in this training directory.

</div>

<div class="rt-desktop">

Ask Claude to install the authored source.

{{prompt:author-security-skill-5}}

The skill autoloads in your next session in this training directory.

</div>

<div class="rt-cowork">

One place skill-creation lives in Claude Desktop is *Customize* → *Skills* → *New* → *Create with Claude*, useful to know exists. You don't need it here. The work session you've been in already has the authored source on disk; the skill-creator skill can draft the personal skill from this session.

Cowork can't write into your personal Claude directories. When skill-creator finishes drafting, it surfaces a Save button. You press Save, that's the moment the personal skill lands.

{{prompt:author-security-skill-6}}

Press Save when skill-creator surfaces it.

</div>

The personal skill autoloads when you start the next session for Exercise 2.

**What happened:**

The reusable check exists now, with two lenses and four named risk patterns covered. You authored it on disk and saved it as a personal skill. Module 4's audit exercise loads it and runs it against the same system.

**The point:**

The policy files are source material. The reusable check is the expert in the room. Eyeballing every file by hand is not. The check carries judgment about what matters in this system, with the four named risk patterns as the forcing function. Agent mitigations sit on top of normal company controls, not in place of them. The package is ready; the first loaded use should be the real audit.

