# Name the rules, place the file

**Time:** 12 minutes.

**What you do:** read back over the plan-mode session you just ran. Ask Claude to surface three to five rules about what made *this* task plan-mode-able, what kind of multi-file work wants this treatment, what a good factoring looks like before plan mode runs on it. Save those rules to a `.md` file at a location you choose. Then ask Claude how the file could drive automated task-splitting in the future.

**What you build:** a rules file that carries how you factored this task on this codebase. Three to five task-shaping rules, surfaced from your own session and sharpened in your own words, saved at a location you chose so it fires when you want it. The automation read stays a read: you name the shapes, you don't build them today.

**The point:** the file is the artifact. You captured how *you* factored *this* task on *this* codebase. Templates stay generic; this file carries your rules. The next small lecture names three places this kind of file ends up.

---

## Phase 1: Name the rules from this session

- You already did the work; now name the rules inside it. You ran a plan, two push-backs, a second-pass walk-down, and an approval. Each decision along the way carried a task-shaping rule about what made this task plan-mode-able.
- You are not on the hook for remembering it. The agent reads the scrollback; you react to what it proposes.

Ask Claude to read the scrollback, propose rules, and pause for your push-back before going further.

{{prompt:extract-the-task-shaping-rule-1}}


## Reject or rewrite the generic rule

- When Claude pauses for the rewrite-and-reject pass, that is where your hand goes on the work.
- The generic rule is the tell. The rule that arrives generic, like "pick tasks that span multiple files," is the one that needs rewriting into your words, or rejecting.

## Phase 2: Pick where the file fires

- The choice is when the rules fire, not where the bytes sit. Anywhere on this laptop (user-level), or only when this repo is open (repo-personal).
- Claude carries the path taxonomy; you carry the choice.

Decide the location with Claude.

{{prompt:extract-the-task-shaping-rule-2}}


## Wire the file in, check the wording

- A rule off the auto-load path needs a wire. If the agent proposes a path other than `./CLAUDE.local.md`, `./CLAUDE.md`, or `~/.claude/CLAUDE.md`, ask Claude to also propose the `@import` line that wires the file in. A rule at `~/.claude/memory/task-shaping.md` (or any notes folder) sits silently on disk until something reads it; adding `@~/.claude/memory/task-shaping.md` to `~/.claude/CLAUDE.md` is what makes "fires anywhere on this laptop" actually fire.
- Read the three rules back. If any drifted from your wording, push back and have Claude rewrite.

## Phase 3: Name the automation shapes, don't build them

- **Refinement** is the backlog-grooming loop. Sizing, splitting, and sharpening tickets before they're worked.
- The prompt asks for shapes, not code. "This rules file" means the `.md` file you saved in Phase 2. The first automation attempt points an agent at that file and one input stream: a Slack channel, an issue queue, or a backlog export.

{{prompt:extract-the-task-shaping-rule-3}}


## Read the shapes, hold the build

- Read the answer as a map, not a mandate. The next small lecture walks the same shapes with the trigger and runtime for each.

## What happened

Claude read the scrollback and proposed the rules. You rewrote or rejected at least one. You named the file and the path. Claude wrote it. You asked one open question about where the file could go next. Claude proposed shapes. You read.

