# No repo to bring? Build one.

The training runs on a repo you already ship to. No such repo you can use here? Build one. A repo you grow from zero is a clean instrument. Every decision is yours, every bug is legibly your own, and nothing inherited needs explaining away.

You'll build a small Lemmings game in the browser (the 1991 classic: little creatures you guide across a level). By the end of the first session it runs, it has a test or two, and it has real commit history. That's a project.

## Get to a running game

- Set the model to Sonnet first with `/model sonnet`. Sonnet builds a clean first version, so the bugs you do hit are small and few. That's the point: a couple of them become your Module 1 material.
- Ask Claude to create a new folder for the game and start a git repo in it.
- Open a Claude Code session in that folder.
- Ask Claude to build a first playable Lemmings game as a single browser page: a canvas, two levels, and three lemming actions you can trigger (walk plus two you pick, say dig and block). Enough code to have surface area, and an obvious backlog of more levels and more actions to grow into. Small enough to run when you open the `.html`.
- Open the page and play. The first thing that looks wrong or feels missing is your Module 1 bug.

## Leave it with tests and a data surface

- Ask Claude to add a small test suite so the game has real tests to break and guard.
- Ask Claude to commit at each working step, so the repo grows real history instead of one big drop.
- Before you close the session, ask Claude to add one feature that touches data or other players: a shareable level via a URL, a score you submit, or saved progress. A toy game with no data has nothing to threat-model.

## Where the four task sizes come from

Same sizes as the [prework](../prework.md), now sourced from the game's own backlog:

- **Trivial bug:** a rendering glitch, a lemming clipping through a wall, an off-by-one in the survivor count.
- **Small multi-file task:** a new ability like a digger or a blocker that touches input, the game loop, and rendering.
- **Small feature:** a user-facing surface like a level-select screen or a win/lose panel, or harden the data feature you seeded at the end of the first session.
- **A bigger piece:** multiple levels, a level editor, or a physics refactor you'd rather hand off than steer one small step at a time.

## Bring to Module 1

The running game, the test suite, the commit history, and the one bug you spotted while playing.

