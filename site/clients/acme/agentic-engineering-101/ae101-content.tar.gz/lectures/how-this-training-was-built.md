# How this training was built

At start, this training was bulletpoints. A strategy doc, seven headings, thirty bullets: the sort of list that makes you feel like you understand something and then realise you don't.

## Wrong is how steering gets in

- **The thirty bulletpoints became module prototypes, and all of them were wrong.** Not wrong the way a bad draft is wrong, where someone missed the point. Wrong the way any first version is wrong: plausible, coherent, reading fine until you hold it next to what the training was actually for. Then the gap showed up. Every time.
- **The gap turned out to be the valuable part.** If the first draft had been right, there would have been nothing to push on.
- **Each wrongness was specific and namable.** A phrase that smuggled consultancy-voice into an engineering lecture. An exercise that asked a real engineer to do something insulting. A module that wanted to feel tidy where the feeling should have been unease.
- **Each thing pointed at turned into a rule.** *"Don't end a module with three scripted questions."* *"Every prompt block gets a one-sentence lead-in with a command verb."* *"Every claim about Claude Code must have been verified within the last month."*
- **The rules were not right the first time either.** Some were overscoped. Some fired on the wrong surface. Some held for one kind of content and broke for another. They got sharpened the same way the drafts did: used, corrected, rewritten.

## The rules started doing the work

- **Rules in a file Claude Code could read stopped being reminders and became load-bearing.** Claude Code opens a session, loads the rules, plans inside them. A subagent dispatched to check a draft is handed them in its brief by the session that dispatched it. Load-bearing, not leak-proof: a loaded rule still slips out of the output sometimes, and the checking that follows exists because it does.
- **This is the move.** A rule written down is a thing one person knows. A rule in `./CLAUDE.md` is a thing every session inherits. A rule in a shared checklist is a thing every dispatched subagent is handed before it writes a word.
- **The rules compounded.** Learning compounded to make better rules. More rules, more pointed. The strategy doc that started as bulletpoints grew a companion checklist for every kind of writing it produced (lectures, exercises, sales pages), each loaded at the moment it matters and no other moment.

## Then the agents started checking the agents

- **The edits to the training got bigger.** One person fixing one line became plan mode reshaping a whole file, then a subagent auditing that file against a checklist in the background, then four agents in parallel auditing a file against four checklists while a fifth checked the neighbouring files.
- **Work-per-session went up, and care-per-line went up with it.** Sweeping changes that would have taken a week got made in an afternoon, because the rules were tight enough to hand off.
- **Every session inherited what the last one figured out.** Every session got better, and each one could take on bigger work than the last.

## You just ran the compound loop

- **The story of building this training is the shape you just ran on your own repo.** Over ninety minutes, not a year. On a trivial bug, not a whole training.
- **The first read was partly wrong, and the wrongness was the way in.** You let Claude read your repo, saw the wrongness, named it, corrected it. That correction turned into a rule.
- **The rule sits in `./CLAUDE.local.md`, which is yours.** Gitignored, alongside you, read by every future session in this repo. By the end of the training it grows into a rules file shaped by how you actually worked: grown from evidence, not from a blank page or a trainer's template.
- **The pattern has a name.** Kieran Klaassen at Every calls it *compound engineering*. The retro you just ran was step four of his loop: plan, work, review, compound. That is the orient, fix, compound, close loop cut at different joints; the names differ, the loop doesn't.
- **Mental models only come from doing.** You just did. Compound engineering an hour ago was a name. Now it's a loop you ran on your own repo.

The loop is the shape. The bug today was the excuse.

