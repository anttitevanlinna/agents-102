---
key: a101-m3-homework-memory-health
dest: Claude Code
runtime: any
---
Look at `memory/` and `sources/` against this module's fresh retrievals.

Check overall health:
- coverage gaps the retrievers exposed
- pages now stale
- whether the structure still serves the challenge

Name what you would drop. If nothing should go, say so.

If restructuring is needed, propose the renames, merges, splits, or drops. Show me the plan before changing any files.
