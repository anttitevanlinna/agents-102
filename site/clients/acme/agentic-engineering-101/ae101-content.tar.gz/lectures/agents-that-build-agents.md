# There is no last turn

## The agent stops where your judgement begins
<!--tier:2-->

- The agent cannot read your mind. It runs on what you have expressed: the spec, the rules, the checks, the plan. What is written down, it can act on. What is still in your head, it cannot.
- That is the frontier, and you set it. Not the model. What you can express is how far the agent runs. It stops exactly where the writing stops and your judgement takes over.
- Judgement becomes expression one piece at a time. A push-back becomes a rule. A "not like that" becomes a check. Each one moves the line, and the agent runs one step further on its own. The line never goes away. You keep finding the next thing you know and have not yet said.

## The right information grounds and makes quality

Nobody reviews 500K lines by hand. Some of the early agentic engineering demos were single devs shipping 500K lines of code in weeks; the first Agentics Helsinki meetup, fall 2025, had two of them. The recurring theme: every generated line had to correspond to a spec, every feature had to be tested. Without that, no way to know the system works.

Spec and tests were the first things those engineers wrote down. Writing things down is not the whole of it. The goal is giving the system the right information, and nobody has that part figured out yet.

Nobody can hand you the right information about your customers, your direction, your domain. You find it one session at a time.

## You make agentic happen
<!--tier:2-->

- **Act under uncertainty.** The right way moves every day; there is no time to test everything. Acting is the move from *possibly* to *I have something*.
- **Competence sets the ceiling.** Your brain needs the reps to think different. The pathways you build show you the next level.
- **Cross personal → team.** Personal mastery is nice. But it will never be enough. Share and learn together.

## There is no last turn

- There is no last turn. Each session surfaces the next gap. Each gap proposes the next move. Each move makes the next session cheaper.
- The kit compounds; the model rotates.

The training closes.

