---
key: personal-site-with-guardrails-6
dest: Claude Code
runtime: any
---
Write a generation rules file at `module-1/personal-brand-generation.md` — a portable agent guideline I could invoke on the next personal-brand task (a colleague's bio, a team page, a client one-pager). Structure it: what this is for, the core rule (distinctive not descriptive), what never to generate, what always to do, the framework moves to apply (StoryBrand-tuned for the help section, anti-branding for voice, visual-steal for chrome), voice rules. Pull from what we just did — the actual decisions, the actual flips, the actual chrome — not from generic guidance. Keep the edge — distinctive over diplomatic. No CTA theatre.

When you're done, summarize in 4–6 lines what's in the file: the structure you used, the strongest 2–3 rules, and anything you weren't sure about. Then tell me to open `module-1/personal-brand-generation.md` and inspect the first two or three rules before I accept it.

When this request is complete, update `prework/learning-position.md` with these workbook links. Preserve any unfinished work and revision notes in that file.
Current: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#phase-7-close-package-what-you-learned
Next: https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#see-the-mechanism-repeat-in-every-phase

End your reply with [See the mechanism repeat in every phase](https://agents102.bosser.consulting/clients/acme-mvp/agents-101/#see-the-mechanism-repeat-in-every-phase). Keep working here if I ask for revisions. Wait for me to choose the next activity; do not start it automatically.
