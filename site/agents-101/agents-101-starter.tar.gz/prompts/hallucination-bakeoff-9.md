---
key: hallucination-bakeoff-9
dest: Claude Code
runtime: any
---
Run `judges/groundedness-judge.md` on `module-5/briefing.md` with the files in `module-5/evidence-roster.md`. Write `module-5/baseline-score.md` with a section `## Module 3 briefing`: how many claims in `module-5/adjudicated-claims.md` are GROUNDED, PARTLY GROUNDED and UNGROUNDED, out of how many. Add a section `## Judge on the Module 3 briefing` with the number of claims judged and the number flagged.

Then open `module-3/briefing-baseline.md` and show me the line under `## Doubted line`. Let me say if I still doubt it, then show me the judge's verdict on it, and the evidence lines from `module-5/adjudicated-claims.md` that bear on it, or "no support in the roster". Do not tell me whether my doubt was right.

Append a section `## Doubted line` to `module-5/baseline-score.md` with the line, the judge's verdict, and my answer word for word.
