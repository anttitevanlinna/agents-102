---
key: extract-the-task-shaping-rule-4
dest: Claude Code
runtime: any
---
Reverse-engineer how this team writes stories from one story ticket. Infer basic rules from the fields and wording: status, labels, priority, component, estimate, owner, epic, acceptance criteria, comments, and links.

If you cannot open the ticket, say so and ask me to paste the fields. Don't infer conventions from the URL.

Separate strong signals, guesses that need more tickets, and things you cannot tell.

Then propose three basic rules an agent could follow when shaping the next story in this tracker. Keep them in chat beside the rules we just named. We pick where the file lives next, so don't write one yet.

Story ticket:
