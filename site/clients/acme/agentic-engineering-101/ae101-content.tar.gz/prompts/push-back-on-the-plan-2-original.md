---
key: push-back-on-the-plan-2-original
dest: Claude Code
permission-mode: plan
runtime: any
origin: exercises/push-back-on-the-plan
---
Interview me relentlessly about every aspect of this plan until we reach a shared understanding. Walk down each branch of the design tree, resolving dependencies between decisions one-by-one. For each question, provide your recommended answer.

Ask the questions one at a time.

If a question can be answered by exploring the codebase, explore the codebase instead.
