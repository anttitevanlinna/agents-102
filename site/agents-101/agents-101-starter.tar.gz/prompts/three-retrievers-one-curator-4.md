---
key: three-retrievers-one-curator-4
dest: Claude Code
context: reusable across all three retriever sessions
runtime: any
---
Push another round. What did the first pass miss? Different angles, related sources, the citations inside what you already opened. Keep going until the file feels complete or you genuinely don't find new material. Append; don't rewrite.
