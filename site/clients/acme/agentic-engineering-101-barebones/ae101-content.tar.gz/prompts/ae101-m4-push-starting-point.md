---
key: ae101-m4-push-starting-point
dest: Claude Code
context: optional
runtime: any
---
Push the current branch and set its upstream.
