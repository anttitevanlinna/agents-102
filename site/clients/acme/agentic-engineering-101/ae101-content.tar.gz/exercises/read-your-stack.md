# Read your stack, *draw what recurs*

**Time:** 15 minutes.

**Session** *(continue, "Module 6 worktree session")*

Same session as the gap map. The ranked gaps and the rule you cut are in scrollback; the stack scan reads wider from there.

**What you do:** read your history for the work you repeat.

**What you build:** a diagram of the work that recurs across your stack.

**The point:** recurring work has a shape, and drawn, the shape is easier to recognise than described.

---

## Find the work you repeat across your stack

- Look wider than the two sessions. The dominant gap came from one task. The kinds of work you repeat run across everything you do, and most of them never get looked at directly. How wide you look, and what you choose to map, is yours.
- Read your own history first. Your Claude Code sessions from every project are sitting on disk, and few engineers ever read them back.

## Scan your history for the work that recurs

> **Fast operator?** Lump the next two prompts into one go. Paste them one after another in the same conversation, study the shapes, and let the answers land together. The two moves don't change.

> **Cut the scan** when the top patterns are clear enough to use. The prompt keeps looking because that is its job. Narrow it whenever you like, or say *tell me what you've found so far*. If it comes back thin instead, or everything traces to one repo, a *there is more than this, keep going* prompt sends it back out. Once two or three recurring kinds of work are clear enough to draw and compare, move on. You do not need a complete inventory.

Ask Claude to scan your sessions across every project and group the kinds of work that recur.

{{prompt:spot-gaps-build-the-loop-study}}

## Draw your top work-shapes as diagrams

- What comes back is the work you do over and over, grouped and ranked. Read for the few at the top you actually repeat.
- A recurring kind of work has a shape: steps in order, a branch, a loop back.

Ask Claude to draw your top few work-shapes as simple diagrams.

{{prompt:spot-gaps-build-the-loop-shapes}}

> **Want to see the shapes**, not read them? Mermaid comes back as text. Say *give me this in HTML* to open them in a browser.

## Sidestep: check your menu against the field's

Optional. Your shapes are drawn and the gaps are ranked. This one widens the menu you pick checks from.

- Where a primitive lines up with a shape you repeat, that pairing is a skill candidate for the kit you grow later.

Ask Claude to name the checking primitives the field already runs and rank the ones that fit your gap.

{{prompt:spot-gaps-build-the-loop-primitives}}

Expect the list to look familiar: test-writing, browser-testing, PR-building, lint and typecheck gates, compile and build, smoke-test on a real path, code-review, git-diff inspection, schema validation, eval suites for agent outputs. Your list won't be exact. The primitives Claude names are the ones your codebase already runs.

**What happened:** A diagrammed map of the work that recurs across your stack. The shapes stay in this session's scrollback; you build the handoff prompt from them.

## Decide what crosses back to your main repo

**Note** The M5 worktree holds this module's work: `./CLAUDE.local.md` with the rule you cut, `observations/`, and M5's packaging. Your main repo's copies stopped at the fork, stale rule and all. What crosses back is yours: copy the worktree's versions over, take the parts you want, or leave them where they are.

