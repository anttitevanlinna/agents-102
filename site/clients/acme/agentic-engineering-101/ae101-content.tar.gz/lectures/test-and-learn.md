# Test and learn

## Every send-off is an experiment

You are testing, and you are learning. Every send-off from here on is an experiment. The agent is the apparatus, your rules and context are the setup, and the result is data.

You don't need to get it right first time. Read the result and decide what to change next.

You're new to this country. A tourist runs an agent and hopes; a practitioner runs a test and reads the data.

## The two-session arc

- Same task, two sessions. Session one goes now, un-packaged: no plan.md, no verifier, no reference artifact. Just *"here's my system, go do X."*
- Session two goes packaged, after you've read the return. You find what went wrong, watch each packaging piece close a specific gap you just saw, and send the same task again.

## Cancel is legitimate; traces are data

- If twenty minutes in you can see Claude hallucinating file paths, contradicting its own earlier steps, or missing a requirement that wasn't in the prompt, stop it. You have the data you came for.
- A short session with useful observations beats hours of trace you can't read.
- For this first session, fifteen to thirty minutes is enough. Session length follows the task and how well your checks guide it.

