---
key: map-the-access-surface-1
dest: Claude Code
runtime: any
---
List my installed skills. Tell me also their storage location and whether or not they are loaded onto context.
