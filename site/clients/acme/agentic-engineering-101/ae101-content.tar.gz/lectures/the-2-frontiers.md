# The 2 frontiers

We have come a long way. Our agent is building the agentic loop. Agents building agents.

The 2 frontiers that still need a better answer:

How can a system like this learn faster than a human practitioner can write things down?

And once it can learn fast, how does it learn the right things, and not just any things?

