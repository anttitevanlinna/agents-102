---
key: personal-site-with-guardrails-3
dest: Claude Code
runtime: any
---
Here are my strengths. Let them change what the site claims about me and how it sounds; don't add them as a list. The page stays about me, and the section on how I help colleagues stays as it is. Keep the strengths as blunt as I wrote them.

Then regenerate `module-1/site.html`.

My 3-5 strengths are:
