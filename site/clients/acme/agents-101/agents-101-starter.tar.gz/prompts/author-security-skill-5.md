---
key: author-security-skill-5
dest: Claude Code
runtime: any
---
Install the authored skill at module-4/skills/security-audit/ as a personal Claude skill. Confirm the installed path so I can verify with ls.
